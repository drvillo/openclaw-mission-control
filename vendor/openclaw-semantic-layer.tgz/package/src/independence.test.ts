import test from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

function sourceFiles(root: string): string[] {
  return readdirSync(root).flatMap((entry) => {
    const fullPath = path.join(root, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) return sourceFiles(fullPath);
    return fullPath.endsWith(".ts") && !fullPath.endsWith(".test.ts") ? [fullPath] : [];
  });
}

test("semantic package stays independent from Mission Control DB/web/worker/shared imports", () => {
  const forbidden = ["@ocmc/db", "@ocmc/shared", "apps/web", "apps/worker", "packages/db", "packages/shared"];
  const offenders = sourceFiles(path.resolve("src")).filter((file) => {
    const text = readFileSync(file, "utf8");
    return forbidden.some((needle) => text.includes(needle));
  });

  assert.deepEqual(offenders, []);
});
