import type { DatabaseSync } from "node:sqlite";
import {
  SEMANTIC_CONTRACT_VERSION,
  semanticEvidencePacketId,
  stableSemanticId,
  type ConceptRegistrySnapshot,
  type SemanticCitationRef,
  type SemanticEvidencePacket,
  type SemanticRetrievalScore,
  type SemanticSourceRef,
} from "./contracts.js";
import type { SemanticAssertionCandidate, SemanticEvidenceWindow, SemanticExtractionBundle, SemanticPersonEntity } from "./extraction.js";
import { retrieveSemanticNeighbors, type EmbeddingProvider, type RetrievalResult } from "./store.js";

export type EvidencePacketSeed = {
  reason: string;
  text?: string | null;
  seedRefs?: SemanticCitationRef[];
  candidateIds?: string[];
  meetingIds?: string[];
};

export type EvidencePacketBuildOptions = {
  indexVersion: string;
  generatedAt?: string;
  limit?: number;
  provider?: EmbeddingProvider;
  registrySnapshot?: ConceptRegistrySnapshot;
  includeRegistryContext?: boolean;
  maxActions?: number;
  maxDecisions?: number;
  maxEvidenceWindows?: number;
  maxMeetings?: number;
  maxEvidenceCharacters?: number;
};

const DEFAULT_PACKET_CAPS = {
  maxActions: 8,
  maxDecisions: 8,
  maxEvidenceWindows: 12,
  maxMeetings: 4,
  maxEvidenceCharacters: 6_000,
} as const;

type PacketBuildState = {
  actionIds: Set<string>;
  decisionIds: Set<string>;
  evidenceIds: Set<string>;
  meetingIds: Set<string>;
  peopleIds: Set<string>;
  candidateScores: Map<string, number>;
  evidenceScores: Map<string, number>;
  meetingScores: Map<string, number>;
};

type BundleLookup = {
  candidates: Map<string, SemanticAssertionCandidate>;
  evidence: Map<string, SemanticEvidenceWindow>;
  peopleByNote: Map<string, SemanticPersonEntity[]>;
  notes: Map<string, SemanticExtractionBundle["note"]>;
};

function buildLookup(bundles: SemanticExtractionBundle[]): BundleLookup {
  const candidates = new Map<string, SemanticAssertionCandidate>();
  const evidence = new Map<string, SemanticEvidenceWindow>();
  const peopleByNote = new Map<string, SemanticPersonEntity[]>();
  const notes = new Map<string, SemanticExtractionBundle["note"]>();
  for (const bundle of bundles) {
    notes.set(bundle.note.semanticNoteId, bundle.note);
    peopleByNote.set(bundle.note.semanticNoteId, bundle.personEntities);
    for (const candidate of bundle.assertionCandidates) candidates.set(candidate.candidateId, candidate);
    for (const window of bundle.evidenceWindows) evidence.set(window.evidenceWindowId, window);
  }
  return { candidates, evidence, peopleByNote, notes };
}

function candidateRef(candidate: SemanticAssertionCandidate): SemanticCitationRef {
  if (candidate.kind === "decision") {
    return { refType: "decision", decisionId: candidate.candidateId, sourceRef: candidate.sourceRef, candidateId: candidate.candidateId };
  }
  return { refType: "action", actionId: candidate.candidateId, sourceRef: candidate.sourceRef, candidateId: candidate.candidateId };
}

function noteRefsFor(noteIds: Set<string>, lookup: BundleLookup): SemanticSourceRef[] {
  return [...noteIds].map((noteId) => lookup.notes.get(noteId)?.sourceRef).filter((ref): ref is SemanticSourceRef => Boolean(ref));
}

function bumpScore(scores: Map<string, number>, id: string, score: number) {
  scores.set(id, Math.max(scores.get(id) ?? 0, score));
}

function collectFromCandidate(candidate: SemanticAssertionCandidate, state: PacketBuildState, score = 1) {
  if (candidate.kind === "decision") state.decisionIds.add(candidate.candidateId);
  else state.actionIds.add(candidate.candidateId);
  state.meetingIds.add(candidate.noteId);
  bumpScore(state.candidateScores, candidate.candidateId, score);
  bumpScore(state.meetingScores, candidate.noteId, score);
  for (const evidenceWindowId of candidate.evidenceWindowIds) state.evidenceIds.add(evidenceWindowId);
  for (const personId of candidate.participantEntityIds) state.peopleIds.add(personId);
}

function collectFromEvidence(window: SemanticEvidenceWindow, lookup: BundleLookup, state: PacketBuildState, score = 1) {
  state.evidenceIds.add(window.evidenceWindowId);
  state.meetingIds.add(window.noteId);
  bumpScore(state.evidenceScores, window.evidenceWindowId, score);
  bumpScore(state.meetingScores, window.noteId, score);
  for (const candidateId of window.supportsCandidateIds) {
    const candidate = lookup.candidates.get(candidateId);
    if (candidate) collectFromCandidate(candidate, state, score);
  }
}

function scoreFromResult(result: RetrievalResult, rank: number): SemanticRetrievalScore {
  const sourceKind = result.chunk.sourceKind === "assertion_candidate"
    ? String(result.chunk.metadata.kind ?? "assertion")
    : result.chunk.sourceKind;
  return {
    sourceId: result.chunk.sourceId,
    sourceKind,
    score: result.score,
    rank,
    lexicalScore: result.lexicalScore,
    vectorScore: result.vectorScore,
    combinedScore: result.combinedScore,
    textLength: result.chunk.text.length,
    sectionName: typeof result.chunk.metadata.sectionName === "string" ? result.chunk.metadata.sectionName : null,
    sourceKindWeight: result.sourceKindWeight,
    diagnostics: result.diagnostics,
    exclusionReason: result.exclusionReason ?? null,
    downrankReason: result.downrankReason ?? null,
  };
}

function registryText(snapshot: ConceptRegistrySnapshot | undefined) {
  if (!snapshot?.entries.length) return "";
  return snapshot.entries
    .filter((entry) => entry.status === "accepted" || entry.status === "candidate")
    .map((entry) => `${entry.canonicalLabel}: ${entry.definition}. Aliases: ${entry.aliases.join(", ")}`)
    .join("\n");
}

function sortedByScore(ids: Iterable<string>, scores: Map<string, number>) {
  return [...ids].sort((left, right) => (scores.get(right) ?? 0) - (scores.get(left) ?? 0) || left.localeCompare(right));
}

function capSet(ids: Set<string>, scores: Map<string, number>, max: number, label: string, diagnostics: string[]) {
  const ordered = sortedByScore(ids, scores);
  const kept = new Set(ordered.slice(0, max));
  const dropped = ordered.slice(max);
  if (dropped.length > 0) diagnostics.push(`packet_cap_${label}_dropped:${dropped.join(",")}`);
  return kept;
}

function applyPacketCaps(state: PacketBuildState, lookup: BundleLookup, options: EvidencePacketBuildOptions, diagnostics: string[]) {
  const caps = {
    maxActions: options.maxActions ?? DEFAULT_PACKET_CAPS.maxActions,
    maxDecisions: options.maxDecisions ?? DEFAULT_PACKET_CAPS.maxDecisions,
    maxEvidenceWindows: options.maxEvidenceWindows ?? DEFAULT_PACKET_CAPS.maxEvidenceWindows,
    maxMeetings: options.maxMeetings ?? DEFAULT_PACKET_CAPS.maxMeetings,
    maxEvidenceCharacters: options.maxEvidenceCharacters ?? DEFAULT_PACKET_CAPS.maxEvidenceCharacters,
  };

  state.actionIds = capSet(state.actionIds, state.candidateScores, caps.maxActions, "actions", diagnostics);
  state.decisionIds = capSet(state.decisionIds, state.candidateScores, caps.maxDecisions, "decisions", diagnostics);

  const orderedEvidence = sortedByScore(state.evidenceIds, state.evidenceScores);
  const keptEvidence = new Set<string>();
  let evidenceChars = 0;
  for (const evidenceWindowId of orderedEvidence) {
    const window = lookup.evidence.get(evidenceWindowId);
    const nextChars = window?.text.length ?? 0;
    if (keptEvidence.size >= caps.maxEvidenceWindows) {
      diagnostics.push(`packet_cap_evidence_windows_dropped:${evidenceWindowId}`);
      continue;
    }
    if (evidenceChars + nextChars > caps.maxEvidenceCharacters) {
      diagnostics.push(`packet_cap_evidence_characters_dropped:${evidenceWindowId}:${nextChars}`);
      continue;
    }
    keptEvidence.add(evidenceWindowId);
    evidenceChars += nextChars;
  }
  state.evidenceIds = keptEvidence;

  const meetingIds = new Set<string>();
  for (const candidateId of [...state.actionIds, ...state.decisionIds]) {
    const candidate = lookup.candidates.get(candidateId);
    if (candidate) meetingIds.add(candidate.noteId);
  }
  for (const evidenceWindowId of state.evidenceIds) {
    const window = lookup.evidence.get(evidenceWindowId);
    if (window) meetingIds.add(window.noteId);
  }
  const keptMeetings = capSet(meetingIds, state.meetingScores, caps.maxMeetings, "meetings", diagnostics);
  if (keptMeetings.size !== meetingIds.size) {
    state.actionIds = new Set([...state.actionIds].filter((candidateId) => keptMeetings.has(lookup.candidates.get(candidateId)?.noteId ?? "")));
    state.decisionIds = new Set([...state.decisionIds].filter((candidateId) => keptMeetings.has(lookup.candidates.get(candidateId)?.noteId ?? "")));
    state.evidenceIds = new Set([...state.evidenceIds].filter((evidenceWindowId) => keptMeetings.has(lookup.evidence.get(evidenceWindowId)?.noteId ?? "")));
  }
  state.meetingIds = keptMeetings;

  state.peopleIds = new Set();
  for (const candidateId of [...state.actionIds, ...state.decisionIds]) {
    const candidate = lookup.candidates.get(candidateId);
    if (candidate) for (const personId of candidate.participantEntityIds) state.peopleIds.add(personId);
  }
}

export async function buildSemanticEvidencePacket(
  db: DatabaseSync | null,
  bundles: SemanticExtractionBundle[],
  seed: EvidencePacketSeed,
  options: EvidencePacketBuildOptions,
): Promise<SemanticEvidencePacket> {
  const lookup = buildLookup(bundles);
  const state: PacketBuildState = { actionIds: new Set<string>(), decisionIds: new Set<string>(), evidenceIds: new Set<string>(), meetingIds: new Set<string>(), peopleIds: new Set<string>(), candidateScores: new Map(), evidenceScores: new Map(), meetingScores: new Map() };
  const retrievalScores: SemanticRetrievalScore[] = [];
  const diagnostics: string[] = [];

  for (const candidateId of seed.candidateIds ?? []) {
    const candidate = lookup.candidates.get(candidateId);
    if (candidate) collectFromCandidate(candidate, state, 2);
    else diagnostics.push(`missing_seed_candidate_id:${candidateId}`);
  }
  for (const meetingId of seed.meetingIds ?? []) {
    if (lookup.notes.has(meetingId)) {
      state.meetingIds.add(meetingId);
      bumpScore(state.meetingScores, meetingId, 1.5);
    } else {
      diagnostics.push(`missing_seed_meeting_id:${meetingId}`);
    }
  }

  const queryText = [seed.text ?? "", options.includeRegistryContext ? registryText(options.registrySnapshot) : ""].filter(Boolean).join("\n\nExisting concepts:\n");
  if (db && queryText.trim()) {
    if (!options.provider) throw new Error("buildSemanticEvidencePacket requires an explicit EmbeddingProvider when db retrieval is enabled.");
    const neighbors = await retrieveSemanticNeighbors(db, queryText, { limit: options.limit ?? 12, provider: options.provider });
    neighbors.forEach((result, index) => {
      retrievalScores.push(scoreFromResult(result, index + 1));
      if (result.score <= 0) {
        diagnostics.push(`retrieval_zero_score_ignored:${result.chunk.sourceKind}:${result.chunk.sourceId}`);
        return;
      }
      if (result.chunk.sourceKind === "assertion_candidate") {
        const candidate = lookup.candidates.get(result.chunk.sourceId);
        if (candidate) collectFromCandidate(candidate, state, result.score);
      } else if (result.chunk.sourceKind === "evidence_window") {
        const window = lookup.evidence.get(result.chunk.sourceId);
        if (window) collectFromEvidence(window, lookup, state, result.score);
      } else {
        diagnostics.push(`retrieval_context_only:${result.chunk.sourceKind}:${result.chunk.sourceId}`);
      }
    });
  }

  if (state.actionIds.size + state.decisionIds.size === 0 && seed.text && (seed.meetingIds?.length ?? 0) > 0) {
    const candidates = [...lookup.candidates.values()].filter((candidate) => !seed.meetingIds?.length || seed.meetingIds.includes(candidate.noteId));
    for (const candidate of candidates.slice(0, options.limit ?? 12)) collectFromCandidate(candidate, state, 0.25);
    if (candidates.length > 0) diagnostics.push("explicit_meeting_seed_fallback_used");
  }

  for (const evidenceWindowId of [...state.evidenceIds]) {
    const window = lookup.evidence.get(evidenceWindowId);
    if (window) collectFromEvidence(window, lookup, state, state.evidenceScores.get(evidenceWindowId) ?? 1);
  }

  applyPacketCaps(state, lookup, options, diagnostics);

  const noteRefs = noteRefsFor(state.meetingIds, lookup);
  const base = {
    query: { reason: seed.reason, text: seed.text ?? null, seedRefs: seed.seedRefs },
    includedActionIds: [...state.actionIds].sort(),
    includedDecisionIds: [...state.decisionIds].sort(),
    evidenceWindowIds: [...state.evidenceIds].sort(),
    meetingIds: [...state.meetingIds].sort(),
    indexVersion: options.indexVersion,
  };
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    packetId: semanticEvidencePacketId(base),
    ...base,
    noteRefs,
    peopleEntityRefs: [...state.peopleIds].sort(),
    retrievalScores,
    diagnostics,
    generatedAt: options.generatedAt ?? new Date().toISOString(),
  };
}

export async function buildSemanticEvidencePackets(
  db: DatabaseSync | null,
  bundles: SemanticExtractionBundle[],
  seeds: EvidencePacketSeed[],
  options: EvidencePacketBuildOptions,
): Promise<SemanticEvidencePacket[]> {
  const packets: SemanticEvidencePacket[] = [];
  const seen = new Set<string>();
  for (const seed of seeds) {
    const packet = await buildSemanticEvidencePacket(db, bundles, seed, options);
    if (!seen.has(packet.packetId)) {
      seen.add(packet.packetId);
      packets.push(packet);
    }
  }
  return packets;
}

export function defaultEvidencePacketSeeds(bundles: SemanticExtractionBundle[]): EvidencePacketSeed[] {
  const seeds: EvidencePacketSeed[] = [];
  for (const bundle of bundles) {
    const actions = bundle.assertionCandidates.filter((candidate) => candidate.kind !== "decision");
    const decisions = bundle.assertionCandidates.filter((candidate) => candidate.kind === "decision");
    const actionText = actions.map((candidate) => candidate.text).join("\n");
    const decisionText = decisions.map((candidate) => candidate.text).join("\n");
    if (actionText.trim()) seeds.push({ reason: "meeting_actions", text: actionText, meetingIds: [bundle.note.semanticNoteId], candidateIds: actions.map((candidate) => candidate.candidateId) });
    if (decisionText.trim()) seeds.push({ reason: "meeting_decisions", text: decisionText, meetingIds: [bundle.note.semanticNoteId], candidateIds: decisions.map((candidate) => candidate.candidateId) });
  }
  for (const cluster of recurringAssertionClusters(bundles)) {
    seeds.push({
      reason: "cross_meeting_recurring_assertions",
      text: cluster.map((candidate) => candidate.text).join("\n"),
      candidateIds: cluster.map((candidate) => candidate.candidateId),
      meetingIds: [...new Set(cluster.map((candidate) => candidate.noteId))].sort(),
    });
  }
  if (seeds.length === 0) seeds.push({ reason: "empty_corpus", text: "No action or decision candidates were available." });
  return seeds;
}

const CLUSTER_STOPWORDS = new Set([
  "about",
  "after",
  "alice",
  "available",
  "before",
  "bob",
  "confirmed",
  "decided",
  "discussed",
  "example",
  "keep",
  "needs",
  "review",
  "team",
  "with",
  "without",
  "works",
]);

function clusterTokens(candidate: SemanticAssertionCandidate) {
  return new Set((candidate.normalizedText.match(/[a-z0-9]{3,}/gu) ?? []).filter((token) => !CLUSTER_STOPWORDS.has(token)));
}

function jaccard(left: Set<string>, right: Set<string>) {
  const intersection = [...left].filter((token) => right.has(token)).length;
  const union = new Set([...left, ...right]).size;
  return union > 0 ? intersection / union : 0;
}

function recurringAssertionClusters(bundles: SemanticExtractionBundle[]) {
  const candidates = bundles.flatMap((bundle) => bundle.assertionCandidates);
  const clusters: SemanticAssertionCandidate[][] = [];
  const clusterTokenSets: Set<string>[] = [];
  for (const candidate of candidates) {
    const tokens = clusterTokens(candidate);
    if (tokens.size === 0) continue;
    const index = clusters.findIndex((cluster, clusterIndex) => {
      const sameKind = cluster[0]?.kind === candidate.kind;
      const newMeeting = !cluster.some((item) => item.noteId === candidate.noteId);
      return sameKind && newMeeting && jaccard(clusterTokenSets[clusterIndex], tokens) >= 0.35;
    });
    if (index >= 0) {
      clusters[index].push(candidate);
      clusterTokenSets[index] = new Set([...clusterTokenSets[index], ...tokens]);
    } else {
      clusters.push([candidate]);
      clusterTokenSets.push(tokens);
    }
  }
  return clusters.filter((cluster) => new Set(cluster.map((candidate) => candidate.noteId)).size > 1).slice(0, 20);
}

export function citationRefsForPacket(packet: SemanticEvidencePacket, bundles: SemanticExtractionBundle[]): SemanticCitationRef[] {
  const lookup = buildLookup(bundles);
  const refs: SemanticCitationRef[] = [];
  for (const actionId of packet.includedActionIds) {
    const candidate = lookup.candidates.get(actionId);
    if (candidate) refs.push(candidateRef(candidate));
  }
  for (const decisionId of packet.includedDecisionIds) {
    const candidate = lookup.candidates.get(decisionId);
    if (candidate) refs.push(candidateRef(candidate));
  }
  for (const evidenceWindowId of packet.evidenceWindowIds) {
    const evidence = lookup.evidence.get(evidenceWindowId);
    if (evidence) refs.push({ refType: "evidence_window", evidenceWindowId, sourceRef: evidence.sourceRef, contentHash: stableSemanticId("evidence-content", evidence.text) });
  }
  return refs;
}
