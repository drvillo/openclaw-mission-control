import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { parseExtractionBundlesJsonl, type SemanticAssertionCandidate, type SemanticEvidenceWindow, type SemanticExtractionBundle, type SemanticPersonEntity } from "./extraction.js";
import type { SemanticMeetingNote } from "./note-reader.js";

export type SemanticChunk = {
  chunkId: string;
  noteId: string;
  sourceKind: "note_section" | "assertion_candidate" | "evidence_window" | "person_entity";
  sourceId: string;
  text: string;
  metadata: Record<string, unknown>;
};

export type EmbeddingVector = number[];

export type EmbeddingProvider = {
  provider: string;
  model: string;
  dimensions: number;
  degraded: boolean;
  embed(texts: string[]): Promise<EmbeddingVector[]> | EmbeddingVector[];
};

export type IndexBuildResult = {
  indexVersionId: string;
  chunkCount: number;
  embeddingProvider: string;
  embeddingModel: string;
  dimensions: number;
  degraded: boolean;
  status: "ready" | "degraded";
};

export type RetrievalResult = {
  chunk: SemanticChunk;
  lexicalScore: number;
  vectorScore: number;
  combinedScore: number;
  sourceKindWeight: number;
  diagnostics: string[];
  exclusionReason?: string | null;
  downrankReason?: string | null;
  score: number;
};

export const CONCEPT_RETRIEVAL_CHUNK_STRATEGY = "concept-retrieval-bounded-source-windows/v2";
export const MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS = 2_000;

const EXCLUDED_NOTE_SECTION_NAMES = new Set([
  "frontmatter",
  "metadata",
  "participant",
  "participants",
  "processing-provenance",
  "provenance",
]);

const CONTEXT_ONLY_NOTE_SECTION_NAMES = new Set([
  "transcript",
  "transcripts",
]);

const PROBLEM_NOTE_SECTION_NAMES = new Set([
  ...EXCLUDED_NOTE_SECTION_NAMES,
  ...CONTEXT_ONLY_NOTE_SECTION_NAMES,
]);

const OVERSIZED_NOTE_SECTION_CHARS = MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS;

function sha256Hex(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function stableId(prefix: string, value: string) {
  return `${prefix}:${sha256Hex(value).slice(0, 32)}`;
}

function tokenize(text: string) {
  return text
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/gu, "")
    .match(/[a-z0-9]{3,}/gu) ?? [];
}

export function normalizeVector(vector: number[]) {
  const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
  return magnitude > 0 ? vector.map((value) => value / magnitude) : vector;
}

export function cosineSimilarity(left: number[], right: number[]) {
  const length = Math.min(left.length, right.length);
  let score = 0;
  for (let index = 0; index < length; index += 1) {
    score += left[index] * right[index];
  }
  return score;
}

export function openSemanticStore(dbPath: string) {
  return new DatabaseSync(dbPath);
}

export function initializeSemanticStore(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS semantic_notes (
      note_id TEXT PRIMARY KEY,
      title TEXT,
      meeting_date TEXT,
      content_hash TEXT NOT NULL,
      record_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS assertion_candidates (
      candidate_id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL,
      kind TEXT NOT NULL,
      normalized_text TEXT NOT NULL,
      text TEXT NOT NULL,
      record_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS evidence_windows (
      evidence_window_id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL,
      text TEXT NOT NULL,
      record_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS person_entities (
      person_entity_id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL,
      display_name TEXT NOT NULL,
      record_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS semantic_chunks (
      chunk_id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL,
      source_kind TEXT NOT NULL,
      source_id TEXT NOT NULL,
      text TEXT NOT NULL,
      record_json TEXT NOT NULL
    );
    CREATE VIRTUAL TABLE IF NOT EXISTS semantic_chunks_fts USING fts5(chunk_id UNINDEXED, text);
    CREATE TABLE IF NOT EXISTS semantic_embeddings (
      chunk_id TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      dimensions INTEGER NOT NULL,
      vector_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS semantic_index_versions (
      index_version_id TEXT PRIMARY KEY,
      created_at TEXT NOT NULL,
      chunk_strategy TEXT NOT NULL,
      embedding_provider TEXT NOT NULL,
      embedding_model TEXT NOT NULL,
      dimensions INTEGER NOT NULL,
      degraded INTEGER NOT NULL,
      status TEXT NOT NULL,
      notes_json TEXT NOT NULL
    );
  `);
}

function insertOrReplaceJson(db: DatabaseSync, table: string, idColumn: string, id: string, fields: Record<string, string | null>, record: unknown) {
  const columns = [idColumn, ...Object.keys(fields), "record_json"];
  const values = [id, ...Object.values(fields), JSON.stringify(record)];
  const placeholders = columns.map(() => "?").join(", ");
  db.prepare(`INSERT OR REPLACE INTO ${table} (${columns.join(", ")}) VALUES (${placeholders})`).run(...values);
}

export function importExtractionBundle(db: DatabaseSync, bundle: SemanticExtractionBundle) {
  db.exec("BEGIN");
  try {
    insertNote(db, bundle.note);
    for (const candidate of bundle.assertionCandidates) insertCandidate(db, candidate);
    for (const evidence of bundle.evidenceWindows) insertEvidence(db, evidence);
    for (const person of bundle.personEntities) insertPerson(db, person);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

export function importExtractionBundles(db: DatabaseSync, bundles: SemanticExtractionBundle[]) {
  for (const bundle of bundles) {
    importExtractionBundle(db, bundle);
  }
}

function insertNote(db: DatabaseSync, note: SemanticMeetingNote) {
  insertOrReplaceJson(db, "semantic_notes", "note_id", note.semanticNoteId, { title: note.title, meeting_date: note.meetingDate, content_hash: note.provenance.contentHash }, note);
}

function insertCandidate(db: DatabaseSync, candidate: SemanticAssertionCandidate) {
  insertOrReplaceJson(db, "assertion_candidates", "candidate_id", candidate.candidateId, { note_id: candidate.noteId, kind: candidate.kind, normalized_text: candidate.normalizedText, text: candidate.text }, candidate);
}

function insertEvidence(db: DatabaseSync, evidence: SemanticEvidenceWindow) {
  insertOrReplaceJson(db, "evidence_windows", "evidence_window_id", evidence.evidenceWindowId, { note_id: evidence.noteId, text: evidence.text }, evidence);
}

function insertPerson(db: DatabaseSync, person: SemanticPersonEntity) {
  insertOrReplaceJson(db, "person_entities", "person_entity_id", person.personEntityId, { note_id: person.noteId, display_name: person.displayName }, person);
}

function splitBoundedText(text: string, maxChars = MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS) {
  const normalized = text.replace(/\r\n/gu, "\n").trim();
  if (!normalized) return [];
  const parts = normalized.split(/\n{2,}|(?=\n?\[\d{1,2}:\d{2}(?::\d{2})?\])/u).map((part) => part.trim()).filter(Boolean);
  const windows: string[] = [];
  let current = "";
  const pushCurrent = () => {
    if (current.trim()) windows.push(current.trim());
    current = "";
  };
  for (const part of parts.length ? parts : [normalized]) {
    if (part.length > maxChars) {
      pushCurrent();
      for (let index = 0; index < part.length; index += maxChars) {
        const slice = part.slice(index, index + maxChars).trim();
        if (slice) windows.push(slice);
      }
      continue;
    }
    const next = current ? `${current}\n\n${part}` : part;
    if (next.length > maxChars) {
      pushCurrent();
      current = part;
    } else {
      current = next;
    }
  }
  pushCurrent();
  return windows.filter((window) => window.length <= maxChars);
}

function noteSectionChunks(bundle: SemanticExtractionBundle): SemanticChunk[] {
  const chunks: SemanticChunk[] = [];
  for (const [sectionNameRaw, text] of Object.entries(bundle.note.sections)) {
    const sectionName = sectionNameRaw.toLowerCase().trim();
    if (!text.trim()) continue;
    if (EXCLUDED_NOTE_SECTION_NAMES.has(sectionName)) continue;
    const windows = splitBoundedText(text);
    for (const [index, window] of windows.entries()) {
      chunks.push({
        chunkId: stableId("chunk", `${bundle.note.semanticNoteId}\0section\0${sectionNameRaw}\0window\0${index}`),
        noteId: bundle.note.semanticNoteId,
        sourceKind: "note_section",
        sourceId: windows.length === 1 ? sectionNameRaw : `${sectionNameRaw}#${index + 1}`,
        text: window,
        metadata: {
          sectionName: sectionNameRaw,
          title: bundle.note.title,
          meetingDate: bundle.note.meetingDate,
          chunkIndex: index,
          chunkCount: windows.length,
          chunkStrategy: CONCEPT_RETRIEVAL_CHUNK_STRATEGY,
          retrievalRole: CONTEXT_ONLY_NOTE_SECTION_NAMES.has(sectionName) ? "context_only_timestamp_window" : "bounded_note_context",
        },
      });
    }
  }
  return chunks;
}

export function chunksForBundle(bundle: SemanticExtractionBundle): SemanticChunk[] {
  const chunks: SemanticChunk[] = [];
  chunks.push(...noteSectionChunks(bundle));
  for (const candidate of bundle.assertionCandidates) {
    chunks.push({
      chunkId: stableId("chunk", `${candidate.candidateId}\0candidate`),
      noteId: candidate.noteId,
      sourceKind: "assertion_candidate",
      sourceId: candidate.candidateId,
      text: candidate.text,
      metadata: { kind: candidate.kind, evidenceWindowIds: candidate.evidenceWindowIds },
    });
  }
  for (const evidence of bundle.evidenceWindows) {
    chunks.push({
      chunkId: stableId("chunk", `${evidence.evidenceWindowId}\0evidence`),
      noteId: evidence.noteId,
      sourceKind: "evidence_window",
      sourceId: evidence.evidenceWindowId,
      text: evidence.text,
      metadata: { supportsCandidateIds: evidence.supportsCandidateIds, offsets: evidence.offsets },
    });
  }
  return chunks;
}

export async function buildSemanticIndex(db: DatabaseSync, bundles: SemanticExtractionBundle[], provider: EmbeddingProvider): Promise<IndexBuildResult> {
  initializeSemanticStore(db);
  importExtractionBundles(db, bundles);
  const chunks = bundles.flatMap(chunksForBundle);
  const oversizedChunks = chunks.filter((chunk) => chunk.text.length > MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS);
  if (oversizedChunks.length > 0) {
    throw new Error(`Refusing to embed ${oversizedChunks.length} oversized concept-retrieval chunk(s); max=${MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS}`);
  }
  const vectors = await provider.embed(chunks.map((chunk) => chunk.text));
  const indexVersionId = stableId("index-version", `${CONCEPT_RETRIEVAL_CHUNK_STRATEGY}\0${Date.now()}\0${provider.provider}\0${provider.model}\0${chunks.length}`);
  db.exec("BEGIN");
  try {
    db.exec("DELETE FROM semantic_chunks_fts; DELETE FROM semantic_chunks; DELETE FROM semantic_embeddings;");
    for (const [index, chunk] of chunks.entries()) {
      db.prepare(`INSERT OR REPLACE INTO semantic_chunks (chunk_id, note_id, source_kind, source_id, text, record_json) VALUES (?, ?, ?, ?, ?, ?)`)
        .run(chunk.chunkId, chunk.noteId, chunk.sourceKind, chunk.sourceId, chunk.text, JSON.stringify(chunk));
      db.prepare(`INSERT INTO semantic_chunks_fts (chunk_id, text) VALUES (?, ?)`).run(chunk.chunkId, chunk.text);
      db.prepare(`INSERT OR REPLACE INTO semantic_embeddings (chunk_id, provider, model, dimensions, vector_json) VALUES (?, ?, ?, ?, ?)`)
        .run(chunk.chunkId, provider.provider, provider.model, provider.dimensions, JSON.stringify(vectors[index]));
    }
    db.prepare(`INSERT INTO semantic_index_versions (index_version_id, created_at, chunk_strategy, embedding_provider, embedding_model, dimensions, degraded, status, notes_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(indexVersionId, new Date().toISOString(), CONCEPT_RETRIEVAL_CHUNK_STRATEGY, provider.provider, provider.model, provider.dimensions, provider.degraded ? 1 : 0, provider.degraded ? "degraded" : "ready", JSON.stringify({ vectorFallback: "in-process-cosine", sqliteVec: false, maxConceptRetrievalChunkChars: MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS, excludedNoteSections: [...EXCLUDED_NOTE_SECTION_NAMES], contextOnlyNoteSections: [...CONTEXT_ONLY_NOTE_SECTION_NAMES] }));
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  return { indexVersionId, chunkCount: chunks.length, embeddingProvider: provider.provider, embeddingModel: provider.model, dimensions: provider.dimensions, degraded: provider.degraded, status: provider.degraded ? "degraded" : "ready" };
}

function ftsQuery(text: string) {
  const terms = [...new Set(tokenize(text))].slice(0, 8);
  return terms.length > 0 ? terms.map((term) => `${term}*`).join(" OR ") : "";
}

function loadChunks(db: DatabaseSync) {
  return db.prepare("SELECT chunk_id as chunkId, text, record_json as recordJson FROM semantic_chunks").all() as Array<{ chunkId: string; text: string; recordJson: string }>;
}

function lexicalScores(db: DatabaseSync, query: string) {
  const scores = new Map<string, number>();
  const matchQuery = ftsQuery(query);
  if (!matchQuery) return scores;
  try {
    const rows = db.prepare("SELECT chunk_id as chunkId, bm25(semantic_chunks_fts) as rank FROM semantic_chunks_fts WHERE semantic_chunks_fts MATCH ? LIMIT 100").all(matchQuery) as Array<{ chunkId: string; rank: number }>;
    if (rows.length === 0) return scores;
    const ranks = rows.map((row) => row.rank).filter((rank) => Number.isFinite(rank));
    if (ranks.length === 0) return scores;
    const best = Math.min(...ranks);
    const worst = Math.max(...ranks);
    for (const row of rows) {
      if (!Number.isFinite(row.rank)) continue;
      if (best === worst) {
        scores.set(row.chunkId, 0.5);
      } else {
        scores.set(row.chunkId, Math.max(0, Math.min(1, 1 - ((row.rank - best) / (worst - best)))));
      }
    }
  } catch {
    return scores;
  }
  return scores;
}

function noteSectionName(chunk: SemanticChunk) {
  const raw = chunk.metadata.sectionName ?? chunk.sourceId;
  return typeof raw === "string" ? raw.toLowerCase().trim() : "";
}

function rankingPolicy(chunk: SemanticChunk) {
  const diagnostics: string[] = [];
  let sourceKindWeight = 1;
  let downrankReason: string | null = null;
  let exclusionReason: string | null = null;

  if (chunk.sourceKind === "assertion_candidate") {
    sourceKindWeight = 1.25;
  } else if (chunk.sourceKind === "evidence_window") {
    sourceKindWeight = 1.15;
  } else if (chunk.sourceKind === "person_entity") {
    sourceKindWeight = 0.15;
    downrankReason = "person_entity_low_signal_for_concept_retrieval";
  } else if (chunk.sourceKind === "note_section") {
    sourceKindWeight = 0.25;
    const sectionName = noteSectionName(chunk);
    if (PROBLEM_NOTE_SECTION_NAMES.has(sectionName)) {
      sourceKindWeight = 0.03;
      exclusionReason = `problematic_note_section_${sectionName}`;
    } else if (chunk.text.length > OVERSIZED_NOTE_SECTION_CHARS) {
      sourceKindWeight = 0.05;
      exclusionReason = `oversized_note_section_${chunk.text.length}_chars`;
    } else {
      downrankReason = "note_section_context_only_for_concept_retrieval";
    }
  }

  if (downrankReason) diagnostics.push(`downrank:${downrankReason}`);
  if (exclusionReason) diagnostics.push(`excluded_from_primary_recall:${exclusionReason}`);
  if (chunk.sourceKind === "note_section") diagnostics.push(`section:${noteSectionName(chunk) || "unknown"}`, `text_length:${chunk.text.length}`);
  return { sourceKindWeight, diagnostics, downrankReason, exclusionReason };
}

export async function retrieveSemanticNeighbors(db: DatabaseSync, query: string, options: { limit?: number; provider: EmbeddingProvider }): Promise<RetrievalResult[]> {
  const provider = options.provider;
  const queryVector = (await provider.embed([query]))[0];
  const lexical = lexicalScores(db, query);
  const rows = loadChunks(db);
  const results = rows.map((row) => {
    const embedding = db.prepare("SELECT vector_json as vectorJson FROM semantic_embeddings WHERE chunk_id = ?").get(row.chunkId) as { vectorJson: string } | undefined;
    const vectorScore = embedding ? Math.max(0, cosineSimilarity(queryVector, JSON.parse(embedding.vectorJson) as number[])) : 0;
    const lexicalScore = lexical.get(row.chunkId) ?? 0;
    const chunk = JSON.parse(row.recordJson) as SemanticChunk;
    const combinedScore = lexicalScore * 0.55 + vectorScore * 0.45;
    const policy = rankingPolicy(chunk);
    return { chunk, lexicalScore, vectorScore, combinedScore, ...policy, score: combinedScore * policy.sourceKindWeight };
  });
  return results.sort((a, b) => b.score - a.score).slice(0, options.limit ?? 10);
}

export function semanticIndexStatus(db: DatabaseSync) {
  initializeSemanticStore(db);
  const count = (table: string) => (db.prepare(`SELECT COUNT(*) as count FROM ${table}`).get() as { count: number }).count;
  const latest = db.prepare("SELECT * FROM semantic_index_versions ORDER BY created_at DESC LIMIT 1").get() as Record<string, unknown> | undefined;
  const chunkStats = db.prepare(`
    SELECT COUNT(*) as chunkCount,
           MAX(LENGTH(text)) as maxChunkChars,
           SUM(CASE WHEN LENGTH(text) > ? THEN 1 ELSE 0 END) as oversizedChunkCount
    FROM semantic_chunks;
  `).get(MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS) as { chunkCount: number; maxChunkChars: number | null; oversizedChunkCount: number | null };
  return {
    notes: count("semantic_notes"),
    candidates: count("assertion_candidates"),
    evidenceWindows: count("evidence_windows"),
    personEntities: count("person_entities"),
    chunks: count("semantic_chunks"),
    embeddings: count("semantic_embeddings"),
    latestIndexVersion: latest ?? null,
    conceptRetrieval: {
      expectedChunkStrategy: CONCEPT_RETRIEVAL_CHUNK_STRATEGY,
      maxAllowedChunkChars: MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS,
      maxChunkChars: chunkStats.maxChunkChars ?? 0,
      oversizedChunkCount: Number(chunkStats.oversizedChunkCount ?? 0),
      staleForConceptGeneration: latest?.chunk_strategy !== CONCEPT_RETRIEVAL_CHUNK_STRATEGY || Number(chunkStats.oversizedChunkCount ?? 0) > 0,
    },
  };
}

export function assertConceptRetrievalIndexReady(db: DatabaseSync) {
  const status = semanticIndexStatus(db);
  if (status.conceptRetrieval.staleForConceptGeneration) {
    throw new Error(`Semantic index is stale for concept generation: expected chunk strategy ${CONCEPT_RETRIEVAL_CHUNK_STRATEGY}, latest=${String(status.latestIndexVersion?.chunk_strategy ?? "none")}, oversizedChunks=${status.conceptRetrieval.oversizedChunkCount}, maxChunkChars=${status.conceptRetrieval.maxChunkChars}`);
  }
  return status;
}

export function loadExtractionBundlesFile(path: string) {
  return parseExtractionBundlesJsonl(readFileSync(path, "utf8"));
}
