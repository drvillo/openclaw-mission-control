import test from "node:test";
import assert from "node:assert/strict";
import {
  SEMANTIC_CONTRACT_SCHEMA_IDS,
  SEMANTIC_CONTRACT_VERSION,
  semanticConceptProposalId,
  semanticContentHash,
  semanticEvidencePacketId,
  stableSemanticId,
  validateConceptRegistrySnapshot,
  validateSemanticConceptProposal,
  validateSemanticConceptProposalRun,
  validateSemanticEvidencePacket,
  type ConceptRegistrySnapshot,
  type SemanticConceptProposal,
  type SemanticConceptProposalRun,
  type SemanticEvidencePacket,
  type SemanticPromptVersion,
  type SemanticSourceRef,
} from "./contracts.js";

const sourceRef: SemanticSourceRef = {
  sourceSystem: "obsidian",
  sourceType: "meeting_note",
  sourceId: "semantic-note:abc",
  canonicalSourcePath: "/vault/meeting.md",
  contentHash: "hash-1",
  recordingId: "rec-1",
  meetingAssistantRunId: "ma-1",
  missionControlId: null,
};

const promptVersion: SemanticPromptVersion = {
  promptId: "semantic-concept-synthesis",
  version: "2026-06-18.phase1",
  contractVersion: SEMANTIC_CONTRACT_VERSION,
};

function evidencePacket(): SemanticEvidencePacket {
  const seed = {
    query: { reason: "phase-1-contract-test", text: "semantic layer independence" },
    includedActionIds: ["action:1"],
    includedDecisionIds: ["decision:1"],
    evidenceWindowIds: ["evidence:1"],
    meetingIds: ["meeting:1"],
    indexVersion: "index:v1",
  };
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    packetId: semanticEvidencePacketId(seed),
    ...seed,
    noteRefs: [sourceRef],
    peopleEntityRefs: ["person:alice"],
    retrievalScores: [{ sourceId: "evidence:1", sourceKind: "evidence_window", score: 0.91, rank: 1, lexicalScore: 0.7, vectorScore: 0.95 }],
    generatedAt: "2026-06-18T10:00:00Z",
  };
}

function proposal(packet = evidencePacket()): SemanticConceptProposal {
  const base = {
    proposalRunId: "proposal-run:phase1",
    canonicalLabelSuggestion: "Semantic layer independence",
    scope: "operational_process" as const,
    linkedActionIds: ["action:1"],
    linkedDecisionIds: ["decision:1"],
    linkedEvidenceWindowIds: ["evidence:1"],
  };
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalId: semanticConceptProposalId(base),
    ...base,
    definition: "Mission Control consumes semantic artifacts but does not own semantic extraction internals.",
    whyItMatters: "Keeps product truth separate from retrieval and synthesis implementation details.",
    confidence: 0.87,
    registryAction: "propose_new",
    aliasesSuggested: ["MC semantic independence"],
    supportingQuotes: [{ quote: "semantic contracts stay in the semantic layer", sourceRef, evidenceWindowId: "evidence:1" }],
    prompt: {
      promptVersion,
      model: { provider: "fixture", model: "no-llm-phase-1", temperature: 0 },
      outputSchemaId: SEMANTIC_CONTRACT_SCHEMA_IDS.conceptProposal,
    },
    retrieval: { indexVersion: packet.indexVersion, evidencePacketIds: [packet.packetId] },
    diagnostics: [],
  };
}

test("stable semantic ids and content hashes are deterministic across object key order", () => {
  assert.equal(semanticContentHash({ a: 1, b: ["x", "y"] }), semanticContentHash({ b: ["x", "y"], a: 1 }));
  assert.equal(stableSemanticId("concept", { label: "A", refs: ["r1", "r2"] }), stableSemanticId("concept", { refs: ["r1", "r2"], label: "A" }));
  assert.equal(
    semanticEvidencePacketId({ query: { reason: "x" }, includedActionIds: ["b", "a"], includedDecisionIds: [], evidenceWindowIds: ["e2", "e1"], meetingIds: ["m1"], indexVersion: "i1" }),
    semanticEvidencePacketId({ query: { reason: "x" }, includedActionIds: ["a", "b"], includedDecisionIds: [], evidenceWindowIds: ["e1", "e2"], meetingIds: ["m1"], indexVersion: "i1" }),
  );
});

test("validates evidence packets with provenance and retrieval metadata", () => {
  const result = validateSemanticEvidencePacket(evidencePacket());
  assert.equal(result.ok, true);
  if (result.ok) {
    assert.equal(result.value.contractVersion, SEMANTIC_CONTRACT_VERSION);
    assert.equal(result.value.noteRefs[0].sourceSystem, "obsidian");
  }
});

test("validates proposal runs and rejects unsafe malformed artifacts", () => {
  const packet = evidencePacket();
  const run: SemanticConceptProposalRun = {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalRunId: "proposal-run:phase1",
    sourceWindow: { meetingIds: ["meeting:1"], dateRange: { from: "2026-06-01T00:00:00Z", to: "2026-06-18T00:00:00Z" } },
    indexVersion: packet.indexVersion,
    registrySnapshotVersion: "registry-snapshot:v1",
    promptVersion,
    generatedAt: "2026-06-18T10:00:00Z",
    evidencePackets: [packet],
    proposals: [proposal(packet)],
    diagnostics: [],
  };

  assert.equal(validateSemanticConceptProposalRun(run).ok, true);

  const invalid = { ...proposal(packet), confidence: 1.5, registryAction: "map_existing", existingConceptId: null };
  const result = validateSemanticConceptProposal(invalid);
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.equal(result.issues.some((item) => item.path === "confidence"), true);
    assert.equal(result.issues.some((item) => item.path === "existingConceptId"), true);
  }
});

test("validates registry snapshots and alias mappings", () => {
  const snapshot: ConceptRegistrySnapshot = {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    registrySnapshotVersion: "registry-snapshot:v1",
    generatedAt: "2026-06-18T10:00:00Z",
    entries: [
      {
        contractVersion: SEMANTIC_CONTRACT_VERSION,
        conceptId: "concept:semantic-layer-independence",
        canonicalLabel: "Semantic layer independence",
        definition: "Semantic-layer owns extraction/retrieval/synthesis contracts outside Mission Control.",
        scope: "operational_process",
        aliases: ["MC semantic independence"],
        status: "accepted",
        createdAt: "2026-06-18T10:00:00Z",
        updatedAt: "2026-06-18T10:00:00Z",
        sourceRefs: [sourceRef],
      },
    ],
    aliases: [
      {
        contractVersion: SEMANTIC_CONTRACT_VERSION,
        alias: "MC semantic independence",
        normalizedAlias: "mc semantic independence",
        conceptId: "concept:semantic-layer-independence",
        source: "manual",
        confidence: 1,
      },
    ],
  };

  assert.equal(validateConceptRegistrySnapshot(snapshot).ok, true);
  assert.equal(validateConceptRegistrySnapshot({ ...snapshot, aliases: [{ ...snapshot.aliases[0], confidence: -0.1 }] }).ok, false);
});
