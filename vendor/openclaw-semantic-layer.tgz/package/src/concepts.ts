import { createHash } from "node:crypto";
import type { SemanticAssertionCandidate, SemanticExtractionBundle } from "./extraction.js";

/**
 * Legacy Jaccard concept clustering kept for compatibility with the
 * existing CLI and degraded local experiments. It is not the target product path
 * for Mission Control concept proposals. New RAG + LLM proposal artifacts should
 * use the versioned contracts in contracts.ts and later retrieval/synthesis phases.
 */

export type SemanticConceptCandidate = {
  conceptCandidateId: string;
  proposalRunId: string;
  labelSuggestion: string;
  summarySuggestion: string | null;
  memberAssertionCandidateIds: string[];
  memberCount: number;
  meetingCount: number;
  participantEntityCount: number;
  evidenceWindowCount: number;
  confidence: number;
  rationale: string[];
};

export type SemanticProposalRun = {
  proposalRunId: string;
  generatedAt: string;
  algorithmVersion: string;
  thresholds: ConceptProposalThresholds;
  degraded: boolean;
  candidates: SemanticConceptCandidate[];
  diagnostics: string[];
};

export type ConceptProposalThresholds = {
  minCandidateCount: number;
  minMeetingCount: number;
  similarityThreshold: number;
  minEvidenceWindowCount: number;
  maxProposals: number;
};

const DEFAULT_THRESHOLDS: ConceptProposalThresholds = {
  minCandidateCount: 2,
  minMeetingCount: 2,
  similarityThreshold: 0.34,
  minEvidenceWindowCount: 2,
  maxProposals: 25,
};

const GENERIC_TERMS = new Set([
  "action",
  "actions",
  "add",
  "align",
  "call",
  "check",
  "confirm",
  "discuss",
  "follow",
  "meeting",
  "next",
  "note",
  "notes",
  "review",
  "share",
  "step",
  "steps",
  "team",
  "update",
  "work",
]);

function sha256Hex(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function stableId(prefix: string, value: string) {
  return `${prefix}:${sha256Hex(value).slice(0, 32)}`;
}

function tokens(text: string) {
  return [
    ...new Set(
      text
        .toLowerCase()
        .normalize("NFKD")
        .replace(/[\u0300-\u036f]/gu, "")
        .match(/[a-z0-9]{3,}/gu) ?? [],
    ),
  ].filter((token) => !GENERIC_TERMS.has(token));
}

function jaccard(left: string[], right: string[]) {
  const l = new Set(left);
  const r = new Set(right);
  const intersection = [...l].filter((token) => r.has(token)).length;
  const union = new Set([...l, ...r]).size;
  return union === 0 ? 0 : intersection / union;
}

function labelFor(candidates: SemanticAssertionCandidate[]) {
  const frequencies = new Map<string, number>();
  for (const candidate of candidates) {
    for (const token of tokens(candidate.text)) {
      frequencies.set(token, (frequencies.get(token) ?? 0) + 1);
    }
  }
  const selected = [...frequencies.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, 4)
    .map(([token]) => token);
  if (selected.length === 0) return "Generic recurring assertion";
  return selected.map((token) => token[0].toUpperCase() + token.slice(1)).join(" ");
}

function isGenericLabel(label: string) {
  const labelTokens = tokens(label);
  return labelTokens.length === 0 || label.toLowerCase().includes("generic recurring");
}

class UnionFind {
  parent = new Map<string, string>();

  add(value: string) {
    if (!this.parent.has(value)) this.parent.set(value, value);
  }

  find(value: string): string {
    this.add(value);
    const parent = this.parent.get(value)!;
    if (parent === value) return value;
    const root = this.find(parent);
    this.parent.set(value, root);
    return root;
  }

  union(left: string, right: string) {
    const leftRoot = this.find(left);
    const rightRoot = this.find(right);
    if (leftRoot !== rightRoot) this.parent.set(rightRoot, leftRoot);
  }
}

function allCandidates(bundles: SemanticExtractionBundle[]) {
  return bundles.flatMap((bundle) => bundle.assertionCandidates);
}

export function generateConceptProposalRun(bundles: SemanticExtractionBundle[], options: Partial<ConceptProposalThresholds> = {}): SemanticProposalRun {
  const thresholds = { ...DEFAULT_THRESHOLDS, ...options };
  const candidates = allCandidates(bundles).filter((candidate) => candidate.evidenceWindowIds.length >= 1);
  const tokenCache = new Map(candidates.map((candidate) => [candidate.candidateId, tokens(candidate.text)]));
  const unionFind = new UnionFind();
  for (const candidate of candidates) unionFind.add(candidate.candidateId);

  for (let leftIndex = 0; leftIndex < candidates.length; leftIndex += 1) {
    for (let rightIndex = leftIndex + 1; rightIndex < candidates.length; rightIndex += 1) {
      const left = candidates[leftIndex];
      const right = candidates[rightIndex];
      if (left.noteId === right.noteId) continue;
      const similarity = jaccard(tokenCache.get(left.candidateId) ?? [], tokenCache.get(right.candidateId) ?? []);
      if (similarity >= thresholds.similarityThreshold) {
        unionFind.union(left.candidateId, right.candidateId);
      }
    }
  }

  const clusters = new Map<string, SemanticAssertionCandidate[]>();
  for (const candidate of candidates) {
    const root = unionFind.find(candidate.candidateId);
    clusters.set(root, [...(clusters.get(root) ?? []), candidate]);
  }

  const proposalRunId = stableId("proposal-run", `${new Date().toISOString()}\0${candidates.length}\0${JSON.stringify(thresholds)}`);
  const diagnostics: string[] = [];
  const proposals: SemanticConceptCandidate[] = [];

  for (const cluster of clusters.values()) {
    const meetingCount = new Set(cluster.map((candidate) => candidate.noteId)).size;
    const evidenceWindowCount = new Set(cluster.flatMap((candidate) => candidate.evidenceWindowIds)).size;
    const participantEntityCount = new Set(cluster.flatMap((candidate) => candidate.participantEntityIds)).size;
    const labelSuggestion = labelFor(cluster);

    if (cluster.length < thresholds.minCandidateCount) {
      diagnostics.push(`excluded one-off cluster with ${cluster.length} candidate(s): ${cluster[0]?.text ?? "unknown"}`);
      continue;
    }
    if (meetingCount < thresholds.minMeetingCount) {
      diagnostics.push(`excluded single-meeting cluster '${labelSuggestion}'`);
      continue;
    }
    if (evidenceWindowCount < thresholds.minEvidenceWindowCount) {
      diagnostics.push(`excluded weak-evidence cluster '${labelSuggestion}'`);
      continue;
    }
    if (isGenericLabel(labelSuggestion)) {
      diagnostics.push(`excluded generic cluster '${labelSuggestion}'`);
      continue;
    }

    const confidence = Math.min(0.95, 0.45 + cluster.length * 0.12 + meetingCount * 0.08 + Math.min(participantEntityCount, 4) * 0.03);
    proposals.push({
      conceptCandidateId: stableId("concept", `${proposalRunId}\0${cluster.map((candidate) => candidate.candidateId).sort().join("|")}`),
      proposalRunId,
      labelSuggestion,
      summarySuggestion: cluster[0]?.text ?? null,
      memberAssertionCandidateIds: cluster.map((candidate) => candidate.candidateId).sort(),
      memberCount: cluster.length,
      meetingCount,
      participantEntityCount,
      evidenceWindowCount,
      confidence,
      rationale: [
        `${cluster.length} semantically similar assertion candidates`,
        `${meetingCount} meetings represented`,
        `${evidenceWindowCount} supporting evidence windows`,
      ],
    });
  }

  proposals.sort((a, b) => b.confidence - a.confidence || b.memberCount - a.memberCount || a.labelSuggestion.localeCompare(b.labelSuggestion));

  return {
    proposalRunId,
    generatedAt: new Date().toISOString(),
    algorithmVersion: "semantic-concept-proposals/v1",
    thresholds,
    degraded: true,
    candidates: proposals.slice(0, thresholds.maxProposals),
    diagnostics,
  };
}
