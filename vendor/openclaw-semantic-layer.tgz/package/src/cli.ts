#!/usr/bin/env node
import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { calibrateConceptProposals, type CalibrationSpec } from "./calibration.js";
import { generateConceptProposalRun } from "./concepts.js";
import { evaluateSemanticConceptProposalRun } from "./evaluation.js";
import { extractionBundlesToJsonl, extractSemanticMeetingNote, parseExtractionBundlesJsonl } from "./extraction.js";
import { generateSemanticConceptProposalRun } from "./llm.js";
import { OpenAIConceptSynthesisProvider, OpenAIEmbeddingProvider, type OpenAIProviderOptions } from "./providers.js";
import { buildSemanticIndex, loadExtractionBundlesFile, openSemanticStore, retrieveSemanticNeighbors, semanticIndexStatus } from "./store.js";
import { collectMarkdownInputs, exportSemanticMeetingNotesJsonl, parseSemanticMeetingNoteFile } from "./note-reader.js";

type CommandArgs = Record<string, string[]> & { _: string[] };

function usage() {
  return `Usage: semantic-layer <command> [options]

Commands:
  parse       --root <root> [--out notes.jsonl] <note-or-dir> [...]
  extract     --root <root> [--out extraction.jsonl] <note-or-dir> [...]
  build-index --db semantic.sqlite --fixtures extraction.jsonl [--openai-api-key key]
  query       --db semantic.sqlite --text "semantic calibration" [--limit 5] [--openai-api-key key]
  status      --db semantic.sqlite
  propose     --fixtures extraction.jsonl [--out proposals.json]
  propose-semantic --fixtures extraction.jsonl [--db semantic.sqlite] [--out semantic-proposals.json] [--openai-api-key key]
  evaluate-semantic --fixtures extraction.jsonl [--out semantic-evaluation.json] [--openai-api-key key]
  calibrate   --fixtures extraction.jsonl --golden golden.json [--out calibration.json]

All commands are local-first and do not read or write Mission Control product state.
Provider-backed commands require an explicit OpenAI-compatible provider via --openai-api-key or OPENAI_API_KEY.`;
}

function parseArgs(argv: string[]): { command: string; args: CommandArgs } {
  const [command, ...rest] = argv;
  if (!command || command === "--help" || command === "-h" || rest.includes("--help") || rest.includes("-h")) {
    console.log(usage());
    process.exit(0);
  }
  const args: CommandArgs = { _: [] };
  for (let index = 0; index < rest.length; index += 1) {
    const arg = rest[index];
    if (arg.startsWith("--")) {
      const key = arg.slice(2);
      const value = rest[index + 1];
      if (!value || value.startsWith("--")) throw new Error(`${arg} requires a value`);
      args[key] = [...(args[key] ?? []), value];
      index += 1;
    } else {
      args._.push(arg);
    }
  }
  return { command, args };
}

function requireOne(args: CommandArgs, key: string) {
  const value = args[key]?.[0];
  if (!value) throw new Error(`--${key} is required`);
  return value;
}

function roots(args: CommandArgs) {
  const values = args.root ?? [];
  if (values.length === 0) throw new Error("At least one --root is required");
  return values;
}

function writeOrPrint(value: string, outPath?: string) {
  if (outPath) {
    writeFileSync(outPath, value, "utf8");
  } else {
    process.stdout.write(value);
  }
}

function openAiOptions(args: CommandArgs, kind: "embedding" | "synthesis"): OpenAIProviderOptions {
  const apiKey = args["openai-api-key"]?.[0] ?? process.env.OPENAI_API_KEY ?? process.env.SEMANTIC_OPENAI_API_KEY ?? "";
  if (!apiKey.trim()) throw new Error(`--openai-api-key or OPENAI_API_KEY is required for ${kind}`);
  const baseUrl = args["openai-base-url"]?.[0] ?? process.env.OPENAI_BASE_URL ?? process.env.SEMANTIC_OPENAI_BASE_URL;
  const model = args[`${kind}-model`]?.[0] ?? (kind === "embedding" ? process.env.SEMANTIC_OPENAI_EMBEDDING_MODEL : process.env.SEMANTIC_OPENAI_LLM_MODEL);
  return { apiKey, baseUrl, model };
}

function embeddingProvider(args: CommandArgs) {
  return new OpenAIEmbeddingProvider(openAiOptions(args, "embedding"));
}

function synthesisProvider(args: CommandArgs) {
  return new OpenAIConceptSynthesisProvider(openAiOptions(args, "synthesis"));
}

async function run(command: string, args: CommandArgs) {
  if (command === "parse") {
    const result = exportSemanticMeetingNotesJsonl(args._, { allowedRoots: roots(args), outPath: args.out?.[0] ?? null });
    if (!args.out?.[0]) process.stdout.write(result.jsonl);
    return;
  }

  if (command === "extract") {
    const inputPaths = collectMarkdownInputs(args._, roots(args));
    const bundles = inputPaths.map((inputPath) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(inputPath, { allowedRoots: roots(args) })));
    writeOrPrint(extractionBundlesToJsonl(bundles), args.out?.[0]);
    return;
  }

  if (command === "build-index") {
    const db = openSemanticStore(requireOne(args, "db"));
    const result = await buildSemanticIndex(db, loadExtractionBundlesFile(requireOne(args, "fixtures")), embeddingProvider(args));
    writeOrPrint(`${JSON.stringify(result, null, 2)}\n`, args.out?.[0]);
    db.close();
    return;
  }

  if (command === "query") {
    const db = openSemanticStore(requireOne(args, "db"));
    const results = await retrieveSemanticNeighbors(db, requireOne(args, "text"), { limit: Number(args.limit?.[0] ?? 5), provider: embeddingProvider(args) });
    writeOrPrint(`${JSON.stringify(results, null, 2)}\n`, args.out?.[0]);
    db.close();
    return;
  }

  if (command === "status") {
    const db = openSemanticStore(requireOne(args, "db"));
    writeOrPrint(`${JSON.stringify(semanticIndexStatus(db), null, 2)}\n`, args.out?.[0]);
    db.close();
    return;
  }

  if (command === "propose") {
    const run = generateConceptProposalRun(loadExtractionBundlesFile(requireOne(args, "fixtures")));
    writeOrPrint(`${JSON.stringify(run, null, 2)}\n`, args.out?.[0]);
    return;
  }

  if (command === "propose-semantic") {
    const bundles = loadExtractionBundlesFile(requireOne(args, "fixtures"));
    const db = args.db?.[0] ? openSemanticStore(args.db[0]) : null;
    try {
      const run = await generateSemanticConceptProposalRun(bundles, { db, maxProposals: Number(args.limit?.[0] ?? 12), provider: synthesisProvider(args), embeddingProvider: db ? embeddingProvider(args) : undefined });
      writeOrPrint(`${JSON.stringify(run, null, 2)}\n`, args.out?.[0]);
    } finally {
      db?.close();
    }
    return;
  }

  if (command === "evaluate-semantic") {
    const report = await evaluateSemanticConceptProposalRun({ fixturesJsonl: requireOne(args, "fixtures"), maxMeetings: Number(args.limit?.[0] ?? 10) }, { provider: synthesisProvider(args) });
    writeOrPrint(`${JSON.stringify(report, null, 2)}\n`, args.out?.[0]);
    return;
  }

  if (command === "calibrate") {
    const bundles = loadExtractionBundlesFile(requireOne(args, "fixtures"));
    const golden = JSON.parse(readFileSync(requireOne(args, "golden"), "utf8")) as CalibrationSpec;
    const report = calibrateConceptProposals(bundles, golden);
    writeOrPrint(`${JSON.stringify(report, null, 2)}\n`, args.out?.[0]);
    return;
  }

  throw new Error(`Unknown command: ${command}`);
}

export async function main(argv = process.argv.slice(2)) {
  const { command, args } = parseArgs(argv);
  await run(command, args);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : String(error));
    console.error(usage());
    process.exit(1);
  });
}
