import type { SemanticExtractionBundle, SemanticEvidenceWindow } from "./extraction.js";
import type { SemanticConceptProposal, SemanticEvidencePacket } from "./contracts.js";

export type EvidenceContext = {
  evidenceWindowId: string;
  text: string;
  contextText: string;
  contextLineStart: number;
  contextLineEnd: number;
};

export type PacketDomainSignals = {
  packetId: string;
  salientTerms: string[];
  genericProcessTerms: string[];
  peopleCohorts: string[];
  meetingTitles: string[];
  meetingDates: string[];
  domainFingerprint: string[];
};

export type ProposalDomainCoherence = {
  domainCoherenceScore: number;
  genericProcessScore: number;
  sharedDomainTerms: string[];
  proposalDomainTerms: string[];
  splitRecommended: boolean;
  suppressRecommended: boolean;
  confidencePenalty: number;
  diagnostics: string[];
};

export type SemanticCoverageProbe = {
  probeId: string;
  kind: "domain_term" | "people_cohort";
  label: string;
  terms: string[];
  personEntityIds: string[];
  meetingIds: string[];
  supportCount: number;
  coveredByProposalIds: string[];
  status: "covered" | "missing";
};

type Lookup = {
  evidence: Map<string, SemanticEvidenceWindow>;
  notes: Map<string, SemanticExtractionBundle["note"]>;
  people: Map<string, { displayName: string; noteId: string }>;
};

const TOKEN_STOPWORDS = new Set([
  "about",
  "after",
  "again",
  "also",
  "and",
  "any",
  "are",
  "before",
  "but",
  "can",
  "could",
  "did",
  "does",
  "for",
  "from",
  "had",
  "has",
  "have",
  "into",
  "its",
  "let",
  "not",
  "now",
  "our",
  "out",
  "over",
  "per",
  "she",
  "should",
  "than",
  "that",
  "the",
  "then",
  "there",
  "they",
  "this",
  "through",
  "too",
  "was",
  "were",
  "will",
  "with",
  "would",
  "you",
  "actions",
  "decisions",
  "end",
  "fathom",
  "participants",
  "section",
  "source",
  "start",
  "text",
]);

const GENERIC_PROCESS_TERMS = new Set([
  "action",
  "actions",
  "alignment",
  "artifact",
  "artifacts",
  "call",
  "calls",
  "check",
  "coordination",
  "clearing",
  "dependency",
  "dependencies",
  "discussion",
  "follow",
  "followup",
  "handoff",
  "hygiene",
  "meeting",
  "meetings",
  "narrative",
  "package",
  "process",
  "readiness",
  "review",
  "reviews",
  "stakeholder",
  "stakeholders",
  "status",
  "step",
  "steps",
  "sync",
  "team",
  "traceability",
  "update",
  "updates",
  "workflow",
  "workflows",
]);

const GENERIC_PROCESS_PHRASES = [
  /follow[-\s]?up/iu,
  /stakeholder[-\s]readiness/iu,
  /dependency\s+clearing/iu,
  /next\s+steps?/iu,
  /review\s+hygiene/iu,
  /artifact\s+traceability/iu,
  /external\s+narrative/iu,
];

function unique<T>(values: T[]) {
  return [...new Set(values)];
}

function buildLookup(bundles: SemanticExtractionBundle[]): Lookup {
  const evidence = new Map<string, SemanticEvidenceWindow>();
  const notes = new Map<string, SemanticExtractionBundle["note"]>();
  const people = new Map<string, { displayName: string; noteId: string }>();
  for (const bundle of bundles) {
    notes.set(bundle.note.semanticNoteId, bundle.note);
    for (const window of bundle.evidenceWindows) evidence.set(window.evidenceWindowId, window);
    for (const person of bundle.personEntities) people.set(person.personEntityId, { displayName: person.displayName, noteId: person.noteId });
  }
  return { evidence, notes, people };
}

function normalizeToken(token: string) {
  return token.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/gu, "").replace(/^-+|-+$/gu, "");
}

function tokens(text: string) {
  return (text.match(/[A-Za-z0-9][A-Za-z0-9_-]{2,}/gu) ?? []).map(normalizeToken).filter(Boolean);
}

function domainTokens(text: string) {
  return tokens(text).filter((token) => !TOKEN_STOPWORDS.has(token) && !GENERIC_PROCESS_TERMS.has(token) && !/^\d+$/u.test(token));
}

function genericProcessTokens(text: string) {
  const found = tokens(text).filter((token) => GENERIC_PROCESS_TERMS.has(token));
  for (const phrase of GENERIC_PROCESS_PHRASES) {
    if (phrase.test(text)) found.push(`phrase:${phrase.source}`);
  }
  return unique(found);
}

function topTerms(texts: string[], maxTerms: number) {
  const counts = new Map<string, number>();
  const docCounts = new Map<string, number>();
  for (const text of texts) {
    const seen = new Set<string>();
    for (const token of domainTokens(text)) {
      counts.set(token, (counts.get(token) ?? 0) + 1);
      seen.add(token);
    }
    for (const token of seen) docCounts.set(token, (docCounts.get(token) ?? 0) + 1);
  }
  return [...counts.entries()]
    .filter(([term]) => term.length >= 3)
    .sort((left, right) => (docCounts.get(right[0]) ?? 0) - (docCounts.get(left[0]) ?? 0) || right[1] - left[1] || left[0].localeCompare(right[0]))
    .slice(0, maxTerms)
    .map(([term]) => term);
}

function jaccard(left: string[], right: string[]) {
  const leftSet = new Set(left);
  const rightSet = new Set(right);
  const union = new Set([...leftSet, ...rightSet]);
  if (union.size === 0) return 0;
  const intersection = [...leftSet].filter((value) => rightSet.has(value)).length;
  return intersection / union.size;
}

function overlap(left: string[], right: string[]) {
  const rightSet = new Set(right);
  return unique(left.filter((item) => rightSet.has(item)));
}

function averagePairwiseJaccard(termSets: string[][]) {
  if (termSets.length <= 1) return 1;
  let total = 0;
  let count = 0;
  for (let left = 0; left < termSets.length; left += 1) {
    for (let right = left + 1; right < termSets.length; right += 1) {
      total += jaccard(termSets[left], termSets[right]);
      count += 1;
    }
  }
  return count ? total / count : 1;
}

export function sourceContextForEvidenceWindow(window: SemanticEvidenceWindow, bundles: SemanticExtractionBundle[], radiusLines = 10): EvidenceContext {
  const lookup = buildLookup(bundles);
  const note = lookup.notes.get(window.noteId);
  if (!note) {
    return { evidenceWindowId: window.evidenceWindowId, text: window.text, contextText: window.text, contextLineStart: 1, contextLineEnd: 1 };
  }
  const markdown = note.rawMarkdown;
  const start = typeof window.offsets?.startChar === "number" && window.offsets.startChar >= 0
    ? window.offsets.startChar
    : Math.max(0, markdown.indexOf(window.text));
  const safeStart = start >= 0 ? start : 0;
  const before = markdown.slice(0, safeStart).split(/\r?\n/u);
  const evidenceLineStart = Math.max(1, before.length);
  const evidenceLineEnd = evidenceLineStart + Math.max(0, window.text.split(/\r?\n/u).length - 1);
  const allLines = markdown.split(/\r?\n/u);
  const contextLineStart = Math.max(1, evidenceLineStart - radiusLines);
  const contextLineEnd = Math.min(allLines.length, evidenceLineEnd + radiusLines);
  const contextText = allLines.slice(contextLineStart - 1, contextLineEnd).join("\n").trim() || window.text;
  return { evidenceWindowId: window.evidenceWindowId, text: window.text, contextText, contextLineStart, contextLineEnd };
}

export function packetDomainSignals(packet: SemanticEvidencePacket, packetTexts: { actions: Array<{ text: string }>; decisions: Array<{ text: string }>; evidence: Array<{ text: string; contextText?: string | null }> }, bundles: SemanticExtractionBundle[]): PacketDomainSignals {
  const lookup = buildLookup(bundles);
  const meetingTitles = packet.meetingIds.map((id) => lookup.notes.get(id)?.title).filter((value): value is string => Boolean(value));
  const meetingDates = packet.meetingIds.map((id) => lookup.notes.get(id)?.meetingDate).filter((value): value is string => Boolean(value));
  const peopleCohorts = packet.peopleEntityRefs.map((id) => lookup.people.get(id)?.displayName ?? id).sort();
  const texts = [
    ...packetTexts.actions.map((item) => item.text),
    ...packetTexts.decisions.map((item) => item.text),
    ...packetTexts.evidence.flatMap((item) => [item.text, item.contextText ?? ""]),
    ...meetingTitles,
  ];
  const salientTerms = topTerms(texts, 16);
  const genericCounts = new Map<string, number>();
  for (const term of texts.flatMap((text) => genericProcessTokens(text))) genericCounts.set(term, (genericCounts.get(term) ?? 0) + 1);
  const genericProcessTerms = [...genericCounts.entries()].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0])).slice(0, 8).map(([term]) => term);
  return {
    packetId: packet.packetId,
    salientTerms,
    genericProcessTerms,
    peopleCohorts,
    meetingTitles,
    meetingDates,
    domainFingerprint: salientTerms.slice(0, 8),
  };
}

export function scoreProposalDomainCoherence(input: {
  label: string;
  definition: string;
  whyItMatters: string;
  packetSignals: PacketDomainSignals[];
}): ProposalDomainCoherence {
  const proposalText = `${input.label}\n${input.definition}\n${input.whyItMatters}`;
  const proposalDomainTerms = topTerms([proposalText], 20);
  const proposalGenericTerms = genericProcessTokens(input.label);
  const packetTerms = unique(input.packetSignals.flatMap((signal) => signal.salientTerms));
  const sharedDomainTerms = overlap(proposalDomainTerms, packetTerms);
  const proposalTermCoverage = proposalDomainTerms.length === 0 ? 0 : sharedDomainTerms.length / Math.min(8, proposalDomainTerms.length);
  const packetSharedness = averagePairwiseJaccard(input.packetSignals.map((signal) => signal.domainFingerprint));
  const peopleSharedness = averagePairwiseJaccard(input.packetSignals.map((signal) => signal.peopleCohorts.map(normalizeToken)));
  const titleSharedness = averagePairwiseJaccard(input.packetSignals.map((signal) => domainTokens(signal.meetingTitles.join(" ")).slice(0, 8)));
  const domainCoherenceScore = Math.max(0, Math.min(1, proposalTermCoverage * 0.45 + packetSharedness * 0.25 + peopleSharedness * 0.15 + titleSharedness * 0.15));
  const genericLabelLoad = proposalGenericTerms.length / Math.max(1, labelDomainTokenCount(input.label) + proposalGenericTerms.length);
  const genericPhraseHit = GENERIC_PROCESS_PHRASES.some((phrase) => phrase.test(input.label)) ? 0.35 : 0;
  const genericProcessScore = Math.max(0, Math.min(1, genericLabelLoad + genericPhraseHit));
  const splitRecommended = input.packetSignals.length > 1 && packetSharedness < 0.16 && peopleSharedness < 0.34 && titleSharedness < 0.18 && genericProcessScore >= 0.35;
  const suppressRecommended = (genericProcessScore >= 0.45 && domainCoherenceScore < 0.35) || (splitRecommended && domainCoherenceScore < 0.45);
  const confidencePenalty = suppressRecommended ? 1 : genericProcessScore >= 0.35 && domainCoherenceScore < 0.55 ? 0.18 : splitRecommended ? 0.12 : 0;
  const diagnostics: string[] = [
    `domain_coherence:${domainCoherenceScore.toFixed(2)}`,
    `generic_process_score:${genericProcessScore.toFixed(2)}`,
  ];
  if (sharedDomainTerms.length > 0) diagnostics.push(`domain_terms:${sharedDomainTerms.slice(0, 8).join(",")}`);
  if (confidencePenalty > 0 && !suppressRecommended) diagnostics.push(`generic_process_confidence_penalty:${confidencePenalty.toFixed(2)}`);
  if (splitRecommended) diagnostics.push("split_recommended: selected packets have weak autonomous domain/person/meeting coherence and appear connected mainly by process language");
  if (suppressRecommended) diagnostics.push("suppress_recommended: generic process label lacks sufficient autonomous business-domain coherence");
  return { domainCoherenceScore, genericProcessScore, sharedDomainTerms, proposalDomainTerms, splitRecommended, suppressRecommended, confidencePenalty, diagnostics };
}

function labelDomainTokenCount(label: string) {
  return domainTokens(label).length;
}

export function deriveAutonomousCoverageProbes(bundles: SemanticExtractionBundle[], run: { evidencePackets: SemanticEvidencePacket[]; proposals: SemanticConceptProposal[] }): SemanticCoverageProbe[] {
  const lookup = buildLookup(bundles);
  const evidenceById = lookup.evidence;
  const personTokens = new Set(bundles.flatMap((bundle) => bundle.personEntities.flatMap((person) => domainTokens(person.displayName))));
  const meetingTexts = bundles.map((bundle) => ({
    meetingId: bundle.note.semanticNoteId,
    text: [
      bundle.note.title ?? "",
      ...bundle.assertionCandidates.map((candidate) => candidate.text),
      ...bundle.evidenceWindows.map((window) => sourceContextForEvidenceWindow(window, bundles, 10).contextText),
    ].join("\n"),
  }));
  const termMeetings = new Map<string, Set<string>>();
  const termCounts = new Map<string, number>();
  for (const meeting of meetingTexts) {
    const seen = new Set<string>();
    for (const term of domainTokens(meeting.text)) {
      termCounts.set(term, (termCounts.get(term) ?? 0) + 1);
      seen.add(term);
    }
    for (const term of seen) {
      if (!termMeetings.has(term)) termMeetings.set(term, new Set());
      termMeetings.get(term)!.add(meeting.meetingId);
    }
  }
  const termProbes = [...termMeetings.entries()]
    .filter(([term, meetings]) => meetings.size >= 2 && !personTokens.has(term))
    .sort((left, right) => right[1].size - left[1].size || (termCounts.get(right[0]) ?? 0) - (termCounts.get(left[0]) ?? 0) || left[0].localeCompare(right[0]))
    .slice(0, 12)
    .map(([term, meetings]) => coverageProbeForTerm(term, [...meetings].sort(), run, evidenceById));

  const cohortCounts = new Map<string, { personEntityIds: Set<string>; label: string; meetingIds: Set<string> }>();
  for (const bundle of bundles) {
    const people = bundle.personEntities.map((person) => ({ id: person.personEntityId, label: person.displayName })).sort((a, b) => a.label.localeCompare(b.label));
    if (people.length < 2) continue;
    const key = people.map((person) => normalizeToken(person.label)).join("|");
    const current = cohortCounts.get(key) ?? { personEntityIds: new Set<string>(), label: people.map((person) => person.label).join(" + "), meetingIds: new Set<string>() };
    for (const person of people) current.personEntityIds.add(person.id);
    current.meetingIds.add(bundle.note.semanticNoteId);
    cohortCounts.set(key, current);
  }
  const cohortProbes = [...cohortCounts.values()]
    .filter((cohort) => cohort.meetingIds.size >= 2)
    .sort((left, right) => right.meetingIds.size - left.meetingIds.size || left.label.localeCompare(right.label))
    .slice(0, 8)
    .map((cohort) => coverageProbeForCohort(cohort, run));

  return [...termProbes, ...cohortProbes];
}

function proposalText(proposal: SemanticConceptProposal) {
  return `${proposal.canonicalLabelSuggestion}\n${proposal.definition}\n${proposal.whyItMatters}\n${proposal.supportingQuotes.map((quote) => quote.quote).join("\n")}`;
}

function coverageProbeForTerm(term: string, meetingIds: string[], run: { proposals: SemanticConceptProposal[] }, evidenceById: Map<string, SemanticEvidenceWindow>): SemanticCoverageProbe {
  const coveredByProposalIds = run.proposals
    .filter((proposal) => {
      if (domainTokens(proposalText(proposal)).includes(term)) return true;
      return proposal.linkedEvidenceWindowIds.some((id) => domainTokens(evidenceById.get(id)?.text ?? "").includes(term));
    })
    .map((proposal) => proposal.proposalId)
    .sort();
  return {
    probeId: `coverage-domain:${term}`,
    kind: "domain_term",
    label: term,
    terms: [term],
    personEntityIds: [],
    meetingIds,
    supportCount: meetingIds.length,
    coveredByProposalIds,
    status: coveredByProposalIds.length > 0 ? "covered" : "missing",
  };
}

function coverageProbeForCohort(cohort: { personEntityIds: Set<string>; label: string; meetingIds: Set<string> }, run: { evidencePackets: SemanticEvidencePacket[]; proposals: SemanticConceptProposal[] }): SemanticCoverageProbe {
  const packetById = new Map(run.evidencePackets.map((packet) => [packet.packetId, packet]));
  const cohortIds = [...cohort.personEntityIds];
  const coveredByProposalIds = run.proposals
    .filter((proposal) => {
      const packetPeople = proposal.retrieval.evidencePacketIds.flatMap((id) => packetById.get(id)?.peopleEntityRefs ?? []);
      return packetPeople.filter((personId) => cohortIds.includes(personId)).length >= Math.min(2, cohortIds.length);
    })
    .map((proposal) => proposal.proposalId)
    .sort();
  return {
    probeId: `coverage-people:${cohortIds.join("+")}`,
    kind: "people_cohort",
    label: cohort.label,
    terms: [],
    personEntityIds: cohortIds,
    meetingIds: [...cohort.meetingIds].sort(),
    supportCount: cohort.meetingIds.size,
    coveredByProposalIds,
    status: coveredByProposalIds.length > 0 ? "covered" : "missing",
  };
}
