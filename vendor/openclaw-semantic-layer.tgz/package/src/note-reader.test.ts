import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, realpathSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { collectMarkdownInputs, parseSemanticMeetingNote, parseSemanticMeetingNoteFile, resolveAllowedMarkdownPath } from "./note-reader.js";
import { writeSemanticNoteFixtures } from "./test-support.js";

test("parses meeting note frontmatter, managed sections, stable id, and content hash", () => {
  const { root, files } = writeSemanticNoteFixtures();
  const first = parseSemanticMeetingNoteFile(files[0], { allowedRoots: [root], parsedAt: "2026-06-01T00:00:00Z" });
  const second = parseSemanticMeetingNoteFile(files[0], { allowedRoots: [root], parsedAt: "2026-06-02T00:00:00Z" });

  assert.equal(first.semanticNoteId, second.semanticNoteId);
  assert.equal(first.provenance.contentHash, second.provenance.contentHash);
  assert.equal(first.title, "Semantic Calibration Kickoff");
  assert.equal(first.meetingDate, "2026-06-01T09:00:00Z");
  assert.equal(first.metadata.recordingId, "sem-001");
  assert.match(first.sections.actions, /semantic calibration dashboard/u);
  assert.match(first.sections.transcript, /precision and coverage/u);
  assert.equal(first.sourceRef.sourceSystem, "obsidian");
});

test("rejects markdown reads and directory discovery outside configured roots", () => {
  const root = mkdtempSync(path.join(os.tmpdir(), "semantic-root-"));
  const outsideDir = mkdtempSync(path.join(os.tmpdir(), "semantic-outside-dir-"));
  const outside = path.join(outsideDir, `semantic-outside-${Date.now()}.md`);
  writeFileSync(outside, "# Outside\n", "utf8");

  assert.throws(() => resolveAllowedMarkdownPath(outside, [realpathSync(root)]), /outside the configured semantic note roots/u);
  assert.throws(() => collectMarkdownInputs([outsideDir], [realpathSync(root)]), /outside the configured semantic note roots/u);
});

test("unclosed managed section emits recoverable diagnostic instead of throwing", () => {
  const note = parseSemanticMeetingNote("# Drift\n<!-- FATHOM:SECTION actions:start -->\n## Actions\n### C1\nBody", { canonicalSourcePath: "/tmp/drift.md" });
  assert.equal(note.diagnostics.some((item) => item.code === "managed_section_unclosed"), true);
});
