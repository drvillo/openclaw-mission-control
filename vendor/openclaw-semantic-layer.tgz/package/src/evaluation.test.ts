import test from "node:test";
import assert from "node:assert/strict";
import { unlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  SEMANTIC_CONTRACT_SCHEMA_IDS,
  SEMANTIC_CONTRACT_VERSION,
  type SemanticConceptProposal,
  type SemanticConceptProposalRun,
  type SemanticEvidencePacket,
  type SemanticPromptMetadata,
} from "./contracts.js";
import { evaluateSemanticConceptProposalRun, evaluateSemanticProposalRunQuality } from "./evaluation.js";
import { extractionBundlesToJsonl, extractSemanticMeetingNote } from "./extraction.js";
import type { ConceptSynthesisInput, RawConceptSynthesis } from "./llm.js";
import { parseSemanticMeetingNoteFile } from "./note-reader.js";
import { writeSemanticNoteFixtures } from "./test-support.js";

const prompt: SemanticPromptMetadata = {
  promptVersion: { promptId: "test-prompt", version: "test", contractVersion: SEMANTIC_CONTRACT_VERSION },
  model: { provider: "test-local", model: "quality-gate-test" },
  outputSchemaId: SEMANTIC_CONTRACT_SCHEMA_IDS.conceptSynthesisOutput,
};

function packet(overrides: Partial<SemanticEvidencePacket> = {}): SemanticEvidencePacket {
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    packetId: "packet:quality",
    query: { reason: "quality_fixture" },
    includedActionIds: ["action:quality-review"],
    includedDecisionIds: ["decision:quality-boundary"],
    evidenceWindowIds: ["evidence:quality-quote"],
    meetingIds: ["meeting:quality"],
    noteRefs: [{ sourceSystem: "test", sourceType: "meeting_note", sourceId: "meeting:quality" }],
    peopleEntityRefs: ["person:alice"],
    retrievalScores: [
      { sourceId: "action:quality-review", sourceKind: "assertion_candidate", score: 1, rank: 1 },
      { sourceId: "evidence:quality-quote", sourceKind: "evidence_window", score: 0.9, rank: 2 },
    ],
    generatedAt: "2026-06-20T08:00:00.000Z",
    indexVersion: "index:test",
    ...overrides,
  };
}

function proposal(overrides: Partial<SemanticConceptProposal> = {}): SemanticConceptProposal {
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalRunId: "proposal-run:quality",
    proposalId: "proposal:quality",
    canonicalLabelSuggestion: "Semantic Quality Gate",
    definition: "Review semantic concept quality with evidence gates.",
    whyItMatters: "It keeps Mission Control review focused on auditable operational concepts.",
    scope: "operational_process",
    confidence: 0.82,
    registryAction: "propose_new",
    existingConceptId: null,
    aliasesSuggested: [],
    linkedActionIds: ["action:quality-review"],
    linkedDecisionIds: ["decision:quality-boundary"],
    linkedEvidenceWindowIds: ["evidence:quality-quote"],
    supportingQuotes: [{ quote: "semantic concept quality needs evidence gates", sourceRef: { sourceSystem: "test", sourceType: "evidence_window", sourceId: "evidence:quality-quote" }, evidenceWindowId: "evidence:quality-quote" }],
    prompt,
    retrieval: { indexVersion: "index:test", evidencePacketIds: ["packet:quality"] },
    diagnostics: [],
    rawJson: { providerRow: null },
    ...overrides,
  };
}

function proposalRun(overrides: Partial<SemanticConceptProposalRun> = {}): SemanticConceptProposalRun {
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalRunId: "proposal-run:quality",
    sourceWindow: { meetingIds: ["meeting:quality"] },
    indexVersion: "index:test",
    registrySnapshotVersion: "registry:test",
    promptVersion: prompt.promptVersion,
    generatedAt: "2026-06-20T08:00:00.000Z",
    evidencePackets: [packet()],
    proposals: [proposal()],
    diagnostics: [],
    audit: { droppedProposals: [], provider: null },
    ...overrides,
  };
}

function fixtureBundles() {
  const fixtures = writeSemanticNoteFixtures();
  return fixtures.files.map((file) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(file, { allowedRoots: [fixtures.root] })));
}

class GoodEvaluationProvider {
  metadata = { provider: "test-local", model: "good-evaluation-provider", temperature: 0 };

  synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    const packet = input.packets.find((item) => item.actions.length + item.decisions.length > 0 && item.evidence.length > 0);
    if (!packet) return [];
    return [{
      canonicalLabelSuggestion: "Semantic Quality Gate",
      definition: "Review semantic proposal quality with operational evidence gates.",
      whyItMatters: "It prevents generic concepts from entering Mission Control review.",
      scope: "operational_process",
      confidence: 0.82,
      aliasesSuggested: ["Semantic review quality gate"],
      supportingQuotes: packet.evidence.slice(0, 1).map((item) => ({ quote: item.text.slice(0, 160), evidenceWindowId: item.id })),
      packetIds: [packet.packet.packetId],
    }];
  }
}

class DuplicatePacketProvider extends GoodEvaluationProvider {
  override metadata = { provider: "test-local", model: "duplicate-packet-provider", temperature: 0 };

  override synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    const base = super.synthesize(input)[0];
    if (!base) return [];
    return [
      { ...base, canonicalLabelSuggestion: "Semantic Quality Gate", confidence: 0.81 },
      { ...base, canonicalLabelSuggestion: "Mission Control Review Workflow", confidence: 0.83 },
    ];
  }
}

test("quality gates fail generic and person-name cluster labels", () => {
  const generic = proposal({ proposalId: "proposal:generic", canonicalLabelSuggestion: "Meeting" });
  const personCluster = proposal({ proposalId: "proposal:person", canonicalLabelSuggestion: "Alice Example" });
  const quality = evaluateSemanticProposalRunQuality(proposalRun({ proposals: [generic, personCluster] }));
  assert.equal(quality.qualityGateCounts.specificityFailures, 2);
  assert.match(quality.diagnostics.join("\n"), /specificity gate/u);
});

test("quality gates fail proposals without aligned action or decision plus quote from the same packet", () => {
  const unaligned = proposal({
    proposalId: "proposal:unaligned",
    linkedActionIds: ["action:not-in-packet"],
    linkedDecisionIds: [],
    supportingQuotes: [{ quote: "quote exists but is not chained to packet evidence", sourceRef: { sourceSystem: "test", sourceType: "evidence_window", sourceId: "evidence:missing" }, evidenceWindowId: "evidence:missing" }],
  });
  const quality = evaluateSemanticProposalRunQuality(proposalRun({ proposals: [unaligned] }));
  assert.equal(quality.qualityGateCounts.evidenceAlignmentFailures, 1);
  assert.equal(quality.qualityGateCounts.packetCoherenceFailures, 1);
});

test("quality gates detect duplicate or conflicting labels over identical evidence packets", () => {
  const first = proposal({ proposalId: "proposal:first", canonicalLabelSuggestion: "Semantic Quality Gate" });
  const second = proposal({ proposalId: "proposal:second", canonicalLabelSuggestion: "Mission Control Review Workflow" });
  const quality = evaluateSemanticProposalRunQuality(proposalRun({ proposals: [first, second] }));
  assert.equal(quality.duplicateConflictCount, 1);
  assert.equal(quality.qualityGateCounts.duplicateConflictFailures, 1);
});

test("confidence calibration uses review usefulness and duplicate-risk feedback", () => {
  const run = proposalRun({ proposals: [proposal({ proposalId: "proposal:reviewed", confidence: 0.88 })] });
  const quality = evaluateSemanticProposalRunQuality(run, [{
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalId: "proposal:reviewed",
    reviewedAt: "2026-06-20T08:05:00.000Z",
    decision: "reject",
    usefulnessScore: 0.2,
    evidenceSupportScore: 0.3,
    duplicateRisk: "high",
    reasons: ["vague duplicate"],
  }]);
  assert.equal(quality.qualityGateCounts.confidenceCalibrationFailures, 1);
  assert.equal(quality.reviewFeedback.highConfidenceNegativeReviewCount, 1);
  assert.equal(quality.reviewFeedback.usefulnessByConfidenceBand.veryStrong.averageUsefulness, 0.2);
});

test("evaluation report exposes Phase 3 quality distributions and duplicate suppression diagnostics", async () => {
  const bundles = fixtureBundles();
  const file = path.join(os.tmpdir(), `semantic-phase3-eval-${Date.now()}.jsonl`);
  writeFileSync(file, extractionBundlesToJsonl(bundles), "utf8");
  try {
    const report = await evaluateSemanticConceptProposalRun(
      { fixturesJsonl: file, maxMeetings: 3 },
      { generatedAt: "2026-06-20T08:10:00.000Z", provider: new DuplicatePacketProvider() },
    );
    assert.equal(report.meetingCount, 3);
    assert.equal(report.proposalCount, 1);
    assert.equal(report.citedProposalRatio, 1);
    assert.equal(report.skippedSuppressedCount, 1);
    assert.equal(report.duplicateConflictCount, 1);
    assert.equal(report.qualityGateCounts.duplicateConflictFailures, 1);
    assert.equal(report.confidenceBandDistribution.strong, 1);
    assert.ok(report.packetSizeDistribution.evidenceWindows.max >= 1);
    assert.ok(report.sourceKindDistribution.assertion_candidate >= 1 || report.sourceKindDistribution.evidence_window >= 1);
    assert.match(report.diagnostics.join("\n"), /duplicate packet-set/u);
  } finally {
    try { unlinkSync(file); } catch {}
  }
});

test("evaluation report passes an aligned operational fixture and includes required metrics", async () => {
  const bundles = fixtureBundles();
  const file = path.join(os.tmpdir(), `semantic-phase3-pass-${Date.now()}.jsonl`);
  writeFileSync(file, extractionBundlesToJsonl(bundles), "utf8");
  try {
    const report = await evaluateSemanticConceptProposalRun(
      { fixturesJsonl: file, maxMeetings: 3 },
      { generatedAt: "2026-06-20T08:20:00.000Z", provider: new GoodEvaluationProvider() },
    );
    assert.equal(report.pass, true);
    assert.equal(report.proposalCount, 1);
    assert.equal(report.skippedSuppressedCount, 0);
    assert.equal(report.duplicateConflictCount, 0);
    assert.equal(report.citedProposalRatio, 1);
    assert.deepEqual(Object.keys(report.confidenceBandDistribution).sort(), ["plausible", "strong", "veryStrong", "weak"].sort());
    assert.ok("totalAssertions" in report.packetSizeDistribution);
    assert.ok(Object.keys(report.sourceKindDistribution).length > 0);
  } finally {
    try { unlinkSync(file); } catch {}
  }
});
