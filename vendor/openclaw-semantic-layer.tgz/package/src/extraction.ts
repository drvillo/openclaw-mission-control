import { createHash } from "node:crypto";
import type { SemanticSourceRef } from "./contracts.js";
import type { SemanticMeetingNote } from "./note-reader.js";

export const SEMANTIC_EXTRACTION_VERSION = "semantic-extraction/v1";

export type SemanticAssertionKind = "action" | "decision" | "claim" | "risk" | "open_question" | string;

export type SemanticAssertionCandidate = {
  candidateId: string;
  noteId: string;
  kind: SemanticAssertionKind;
  text: string;
  normalizedText: string;
  source: "meeting_assistant_existing_extraction" | "semantic_extraction" | "manual_fixture" | string;
  sourceRef: SemanticSourceRef;
  evidenceWindowIds: string[];
  participantEntityIds: string[];
  confidence: number;
  extractionVersion: string;
};

export type SemanticEvidenceWindow = {
  evidenceWindowId: string;
  noteId: string;
  text: string;
  sourceRef: SemanticSourceRef;
  offsets?: {
    startChar?: number;
    endChar?: number;
    startTimestamp?: string | null;
    endTimestamp?: string | null;
  };
  supportsCandidateIds: string[];
};

export type SemanticPersonEntity = {
  personEntityId: string;
  noteId: string;
  displayName: string;
  aliases: string[];
  sourceRef: SemanticSourceRef;
  confidence: number;
};

export type SemanticExtractionBundle = {
  note: SemanticMeetingNote;
  assertionCandidates: SemanticAssertionCandidate[];
  evidenceWindows: SemanticEvidenceWindow[];
  personEntities: SemanticPersonEntity[];
  extraction: {
    extractionVersion: string;
    degraded: boolean;
    diagnostics: string[];
  };
};

function sha256Hex(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function stableId(prefix: string, value: string) {
  return `${prefix}:${sha256Hex(value).slice(0, 32)}`;
}

export function normalizeAssertionText(text: string) {
  return text
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/gu, "")
    .replace(/[`*_~[\]().,!?:;'"/\\]+/gu, " ")
    .replace(/\b(the|a|an|to|and|or|of|for|with|on|in|at|by|now)\b/gu, " ")
    .replace(/\s+/gu, " ")
    .trim();
}

function sourceRef(note: SemanticMeetingNote, sourceType: string, sourceId: string): SemanticSourceRef {
  return {
    ...note.sourceRef,
    sourceType,
    sourceId,
    missionControlId: null,
  };
}

function participantLines(note: SemanticMeetingNote) {
  const frontmatterParticipants = note.metadata.frontmatter.participants;
  if (Array.isArray(frontmatterParticipants)) {
    return frontmatterParticipants.filter(Boolean);
  }
  const sectionParticipants = note.sections.participants ?? "";
  return sectionParticipants
    .split(/\r?\n/u)
    .map((line) => line.match(/^-\s*(.+)$/u)?.[1]?.trim())
    .filter((participant): participant is string => Boolean(participant));
}

function aliasesFor(displayName: string) {
  const aliases = new Set<string>([displayName]);
  const parts = displayName.split(/\s+/u).filter(Boolean);
  if (parts.length > 1) {
    aliases.add(parts[0]);
  }
  return [...aliases];
}

export function extractPersonEntities(note: SemanticMeetingNote): SemanticPersonEntity[] {
  return [...new Set(participantLines(note))].map((displayName) => {
    const personEntityId = stableId("person", `${note.semanticNoteId}\0${normalizeAssertionText(displayName)}`);
    return {
      personEntityId,
      noteId: note.semanticNoteId,
      displayName,
      aliases: aliasesFor(displayName),
      sourceRef: sourceRef(note, "person_entity", personEntityId),
      confidence: 0.85,
    };
  });
}

function parseEvidenceTimestamps(evidence: string) {
  return [...evidence.matchAll(/\[(\d{2}:\d{2}:\d{2})\]/gu)].map((match) => match[1]);
}

function parseManagedReviewBlocks(section: string) {
  const headings = [...section.matchAll(/^###\s+(.+?)\s*$/gmu)];
  if (headings.length === 0 && section.trim() && !/none extracted/iu.test(section)) {
    return [{ label: "implicit", block: section }];
  }
  return headings.map((match, index) => {
    const blockStart = match.index;
    const blockEnd = headings[index + 1]?.index ?? section.length;
    return { label: match[1].trim(), block: section.slice(blockStart, blockEnd) };
  });
}

function stripReviewMetadata(block: string) {
  return block
    .replace(/^###\s+.+$/gmu, "")
    .replace(/^-\s*[A-Za-z0-9_ -]+:\s*.*$/gmu, "")
    .replace(/```(?:text)?\s*\n[\s\S]*?\n```/gu, "")
    .trim();
}

function extractEvidenceText(block: string) {
  return block.match(/```(?:text)?\s*\n([\s\S]*?)\n```/u)?.[1]?.trim() ?? "";
}

function participantIdsForText(text: string, people: SemanticPersonEntity[]) {
  const lower = text.toLowerCase();
  return people
    .filter((person) => person.aliases.some((alias) => lower.includes(alias.toLowerCase())))
    .map((person) => person.personEntityId);
}

export function extractSemanticMeetingNote(note: SemanticMeetingNote): SemanticExtractionBundle {
  const personEntities = extractPersonEntities(note);
  const evidenceWindows: SemanticEvidenceWindow[] = [];
  const candidates: SemanticAssertionCandidate[] = [];
  const seenNormalized = new Set<string>();
  const diagnostics: string[] = [];

  for (const [kind, sectionKey] of [
    ["action", "actions"],
    ["decision", "decisions"],
  ] as const) {
    const section = note.sections[sectionKey] ?? "";
    if (!section.trim() || /none extracted/iu.test(section)) {
      continue;
    }

    for (const { label, block } of parseManagedReviewBlocks(section)) {
      const text = stripReviewMetadata(block);
      const normalizedText = normalizeAssertionText(text || label);
      if (!normalizedText || seenNormalized.has(normalizedText)) {
        if (normalizedText) {
          diagnostics.push(`suppressed duplicate ${kind}: ${normalizedText}`);
        }
        continue;
      }
      seenNormalized.add(normalizedText);

      const candidateId = stableId("assertion", `${note.semanticNoteId}\0${kind}\0${normalizedText}`);
      const evidenceText = extractEvidenceText(block);
      const evidenceWindowIds: string[] = [];
      if (evidenceText) {
        const timestamps = parseEvidenceTimestamps(evidenceText);
        const startChar = note.rawMarkdown.indexOf(evidenceText);
        const evidenceWindowId = stableId("evidence", `${candidateId}\0${sha256Hex(evidenceText)}`);
        evidenceWindowIds.push(evidenceWindowId);
        evidenceWindows.push({
          evidenceWindowId,
          noteId: note.semanticNoteId,
          text: evidenceText,
          sourceRef: sourceRef(note, "evidence_window", evidenceWindowId),
          offsets: {
            startChar: startChar >= 0 ? startChar : undefined,
            endChar: startChar >= 0 ? startChar + evidenceText.length : undefined,
            startTimestamp: timestamps[0] ?? null,
            endTimestamp: timestamps.at(-1) ?? null,
          },
          supportsCandidateIds: [candidateId],
        });
      }

      candidates.push({
        candidateId,
        noteId: note.semanticNoteId,
        kind,
        text: text || label,
        normalizedText,
        source: "meeting_assistant_existing_extraction",
        sourceRef: sourceRef(note, "assertion_candidate", candidateId),
        evidenceWindowIds,
        participantEntityIds: participantIdsForText(`${text}\n${evidenceText}`, personEntities),
        confidence: evidenceText ? 0.9 : 0.7,
        extractionVersion: SEMANTIC_EXTRACTION_VERSION,
      });
    }
  }

  if (candidates.length === 0) {
    diagnostics.push("no action/decision candidates extracted from note sections");
  }

  return {
    note,
    assertionCandidates: candidates,
    evidenceWindows,
    personEntities,
    extraction: {
      extractionVersion: SEMANTIC_EXTRACTION_VERSION,
      degraded: false,
      diagnostics,
    },
  };
}

export function extractionBundlesToJsonl(bundles: SemanticExtractionBundle[]) {
  return `${bundles.map((bundle) => JSON.stringify(bundle)).join("\n")}${bundles.length > 0 ? "\n" : ""}`;
}

export function parseExtractionBundlesJsonl(jsonl: string): SemanticExtractionBundle[] {
  return jsonl
    .split(/\r?\n/u)
    .filter((line) => line.trim().length > 0)
    .map((line) => JSON.parse(line) as SemanticExtractionBundle);
}
