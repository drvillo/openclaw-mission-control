import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtempSync, rmSync, unlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { SEMANTIC_CONTRACT_VERSION, type ConceptRegistrySnapshot } from "./contracts.js";
import { evaluateSemanticConceptProposalRun } from "./evaluation.js";
import { extractionBundlesToJsonl, extractSemanticMeetingNote } from "./extraction.js";
import { generateSemanticConceptProposalRun, type ConceptSynthesisInput, type RawConceptSynthesis } from "./llm.js";
import { parseSemanticMeetingNoteFile } from "./note-reader.js";
import { OpenAIConceptSynthesisProvider, parseConceptConfidence, parseOpenAIConceptSynthesisContent } from "./providers.js";
import { buildSemanticEvidencePacket } from "./recall.js";
import { buildConceptRegistrySnapshot, canonicalizeConceptAgainstRegistry } from "./registry.js";
import { buildSemanticIndex, openSemanticStore } from "./store.js";
import { writeSemanticNoteFixtures } from "./test-support.js";

class TestEmbeddingProvider {
  provider = "test-local";
  model = "hash-bow-test";
  dimensions = 64;
  degraded = true;

  embed(texts: string[]) {
    return texts.map((text) => {
      const vector = Array.from({ length: this.dimensions }, () => 0);
      for (const token of text.toLowerCase().match(/[a-z0-9]{3,}/gu) ?? []) {
        const hash = createHash("sha256").update(token).digest();
        const index = hash.readUInt32BE(0) % this.dimensions;
        vector[index] += hash.readUInt8(4) % 2 === 0 ? 1 : -1;
      }
      const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
      return magnitude > 0 ? vector.map((value) => value / magnitude) : vector;
    });
  }
}

class TestConceptSynthesisProvider {
  metadata = { provider: "test-local", model: "concept-synthesis-test", temperature: 0 };

  synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    return input.packets
      .filter((packet) => packet.actions.length + packet.decisions.length > 0)
      .map((packet) => ({
        canonicalLabelSuggestion: "Semantic Calibration Dashboard",
        definition: "Review semantic calibration dashboard precision and coverage.",
        whyItMatters: "It keeps semantic concept proposal quality reviewable before product writes.",
        scope: "operational_process" as const,
        confidence: 0.82,
        aliasesSuggested: ["Semantic proposal review dashboard"],
        supportingQuotes: packet.evidence.slice(0, 3).map((item) => ({ quote: item.text.slice(0, 500), evidenceWindowId: item.id })),
        packetIds: [packet.packet.packetId],
      }))
      .slice(0, input.maxProposals);
  }
}

class ConfidenceGateTestProvider {
  metadata = { provider: "test-local", model: "confidence-gate-test", temperature: 0 };

  synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    const packet = input.packets.find((item) => item.actions.length + item.decisions.length > 0 && item.evidence.length > 0) ?? input.packets[0];
    if (!packet) return [];
    const base = {
      definition: "Review semantic proposal confidence with strict audit and evidence gates.",
      whyItMatters: "It prevents unsupported proposals from entering Mission Control review.",
      scope: "operational_process" as const,
      aliasesSuggested: [],
      supportingQuotes: packet.evidence.slice(0, 1).map((item) => ({ quote: item.text.slice(0, 120), evidenceWindowId: item.id })),
      packetIds: [packet.packet.packetId],
    };
    return [
      { ...base, canonicalLabelSuggestion: "Missing Confidence Proposal", confidence: undefined },
      { ...base, canonicalLabelSuggestion: "Null Confidence Proposal", confidence: null },
      { ...base, canonicalLabelSuggestion: "Junk Confidence Proposal", confidence: "0.8" },
      { ...base, canonicalLabelSuggestion: "Zero Confidence Proposal", confidence: 0 },
      { ...base, canonicalLabelSuggestion: "Negative Confidence Proposal", confidence: -0.1 },
      { ...base, canonicalLabelSuggestion: "Unknown Packet Proposal", confidence: 0.9, packetIds: ["packet:missing"] },
      { ...base, canonicalLabelSuggestion: "Mismatched Quote Evidence Proposal", confidence: 0.88, supportingQuotes: [{ quote: "not in the selected packet", evidenceWindowId: "evidence:missing" }] },
      { ...base, canonicalLabelSuggestion: "Mission Control Audit Gate", confidence: 82 },
    ];
  }
}

class ContextAwareTestProvider {
  metadata = { provider: "test-local", model: "context-aware-test", temperature: 0 };

  synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    const packet = input.packets.find((item) => item.evidence.some((evidence) => evidence.contextText?.includes("improve the semantic calibration dashboard")));
    assert.ok(packet, "synthesis input should include bounded source context around evidence, not only quoted evidence");
    assert.ok(packet.domainSignals.salientTerms.includes("semantic"));
    const evidence = packet.evidence.find((item) => item.contextText?.includes("improve the semantic calibration dashboard"))!;
    return [{
      canonicalLabelSuggestion: "Semantic Calibration Dashboard",
      definition: "Improve semantic calibration dashboard precision and coverage before review.",
      whyItMatters: "The source context links dashboard work to proposal quality control.",
      scope: "operational_process" as const,
      confidence: 0.8,
      aliasesSuggested: [],
      supportingQuotes: [{ quote: evidence.text.slice(0, 160), evidenceWindowId: evidence.id }],
      packetIds: [packet.packet.packetId],
    }];
  }
}

class GenericCrossDomainProvider {
  metadata = { provider: "test-local", model: "generic-cross-domain-test", temperature: 0 };

  synthesize(input: ConceptSynthesisInput): RawConceptSynthesis[] {
    const packets = input.packets.filter((packet) => packet.actions.length + packet.decisions.length > 0 && packet.evidence.length > 0).slice(0, 2);
    return [{
      canonicalLabelSuggestion: "Stakeholder readiness and dependency clearing",
      definition: "Coordinate follow-up readiness and clear dependencies across external stakeholders.",
      whyItMatters: "It keeps operational follow-up moving.",
      scope: "operational_process" as const,
      confidence: 0.9,
      aliasesSuggested: [],
      supportingQuotes: packets.map((packet) => ({ quote: packet.evidence[0].text.slice(0, 160), evidenceWindowId: packet.evidence[0].id })),
      packetIds: packets.map((packet) => packet.packet.packetId),
    }];
  }
}

function bundles() {
  const fixtures = writeSemanticNoteFixtures();
  return fixtures.files.map((file) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(file, { allowedRoots: [fixtures.root] })));
}

function crossDomainBundles() {
  const root = mkdtempSync(path.join(os.tmpdir(), "semantic-cross-domain-"));
  const files = [
    {
      name: "custody.md",
      body: `---
meeting_title: Custody CIMA Filing
meeting_date: 2026-06-02T09:00:00Z
participants:
  - Legal Alice
  - Compliance Bob
source: fathom
---
# Custody CIMA Filing
<!-- FATHOM:SECTION participants:start -->
## Participants
- Legal Alice
- Compliance Bob
<!-- FATHOM:SECTION participants:end -->
<!-- FATHOM:SECTION actions:start -->
## Actions
### CIMA application deck
Legal Alice to prepare CIMA custody license application materials with auditor evidence.

\`\`\`text
[00:01:00] Legal Alice: CIMA wants the custody application deck, auditor option, DASP filing timeline, and regulator-facing narrative.
\`\`\`
<!-- FATHOM:SECTION actions:end -->`,
    },
    {
      name: "trading.md",
      body: `---
meeting_title: Trading Platform Roadmap
meeting_date: 2026-06-09T09:00:00Z
participants:
  - Trading Cara
  - Product Dan
source: fathom
---
# Trading Platform Roadmap
<!-- FATHOM:SECTION participants:start -->
## Participants
- Trading Cara
- Product Dan
<!-- FATHOM:SECTION participants:end -->
<!-- FATHOM:SECTION actions:start -->
## Actions
### Fiat trading roadmap
Product Dan to replace manual Perpolis and RockWallet fiat trading flows with platform reporting.

\`\`\`text
[00:02:00] Trading Cara: manual trading is blocking fiat roadmap progress; Perpolis, RockWallet, and reporting ownership need platform automation.
\`\`\`
<!-- FATHOM:SECTION actions:end -->`,
    },
  ].map((fixture) => {
    const file = path.join(root, fixture.name);
    writeFileSync(file, fixture.body, "utf8");
    return file;
  });
  return { root, files };
}

function dbPath() {
  return path.join(os.tmpdir(), `semantic-rag-${Date.now()}-${Math.random().toString(16).slice(2)}.sqlite`);
}

test("builds RAG evidence packets over actions, decisions, evidence, people, and notes", async () => {
  const testBundles = bundles();
  const file = dbPath();
  const db = openSemanticStore(file);
  try {
    const provider = new TestEmbeddingProvider();
    const index = await buildSemanticIndex(db, testBundles, provider);
    const packet = await buildSemanticEvidencePacket(db, testBundles, { reason: "test", text: "semantic calibration dashboard precision" }, { indexVersion: index.indexVersionId, limit: 8, provider });
    assert.equal(packet.contractVersion, SEMANTIC_CONTRACT_VERSION);
    assert.ok(packet.includedActionIds.length >= 1);
    assert.ok(packet.evidenceWindowIds.length >= 1);
    assert.ok(packet.meetingIds.length >= 1);
    assert.ok(packet.peopleEntityRefs.length >= 1);
    assert.ok(packet.retrievalScores.length >= 1);
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("canonicalizes concepts against registry labels and aliases", () => {
  const snapshot = buildConceptRegistrySnapshot([
    {
      conceptId: "concept:semantic-calibration-dashboard",
      canonicalLabel: "Semantic calibration dashboard",
      definition: "Precision and coverage review for semantic concept proposals.",
      scope: "operational_process",
      aliases: ["Semantic proposal review dashboard"],
      status: "accepted",
    },
  ]);
  assert.equal(canonicalizeConceptAgainstRegistry({ label: "Semantic proposal review dashboard" }, snapshot).registryAction, "map_existing");
  assert.equal(canonicalizeConceptAgainstRegistry({ label: "Calibration dashboard precision", minMapScore: 0.9 }, snapshot).registryAction, "add_alias");
  assert.equal(canonicalizeConceptAgainstRegistry({ label: "Vendor contract risk" }, snapshot).registryAction, "propose_new");
});

test("canonicalization ignores exact aliases on inactive registry entries", () => {
  const snapshot = buildConceptRegistrySnapshot([
    {
      conceptId: "concept:old-dashboard",
      canonicalLabel: "Old dashboard concept",
      definition: "Merged historical concept.",
      scope: "operational_process",
      aliases: ["Semantic dashboard alias"],
      status: "merged",
    },
  ]);
  assert.notEqual(canonicalizeConceptAgainstRegistry({ label: "Semantic dashboard alias" }, snapshot).registryAction, "map_existing");
});

test("generates schema-valid semantic proposal runs with explicit test provider", async () => {
  const testBundles = bundles();
  const registry: ConceptRegistrySnapshot = buildConceptRegistrySnapshot([
    {
      conceptId: "concept:semantic-layer-independence",
      canonicalLabel: "Semantic layer independence",
      definition: "Semantic contracts remain outside Mission Control product writes.",
      scope: "operational_process",
      aliases: ["MC semantic boundary"],
      status: "accepted",
    },
  ]);
  const run = await generateSemanticConceptProposalRun(testBundles, { registrySnapshot: registry, generatedAt: "2026-06-18T10:00:00Z", maxProposals: 8, provider: new TestConceptSynthesisProvider() });
  assert.equal(run.contractVersion, SEMANTIC_CONTRACT_VERSION);
  assert.ok(run.evidencePackets.length >= 1);
  assert.ok(run.proposals.length >= 1);
  assert.ok(run.proposals.every((proposal) => proposal.supportingQuotes.length > 0));
  assert.ok(run.proposals.every((proposal) => proposal.linkedActionIds.length + proposal.linkedDecisionIds.length > 0));
});

test("proposal synthesis input includes bounded source context and autonomous domain signals", async () => {
  const run = await generateSemanticConceptProposalRun(bundles(), { generatedAt: "2026-06-20T09:00:00Z", maxProposals: 1, provider: new ContextAwareTestProvider() });
  assert.equal(run.proposals.length, 1);
  assert.ok(run.proposals[0].diagnostics.some((diagnostic) => diagnostic.startsWith("domain_coherence:")));
});

test("generic cross-domain process proposals are suppressed before review import", async () => {
  const fixtures = crossDomainBundles();
  try {
    const testBundles = fixtures.files.map((file) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(file, { allowedRoots: [fixtures.root] })));
    const run = await generateSemanticConceptProposalRun(testBundles, { generatedAt: "2026-06-20T09:10:00Z", maxProposals: 4, provider: new GenericCrossDomainProvider() });
    assert.equal(run.proposals.length, 0);
    assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("suppress_recommended")));
    assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("split_recommended")));
  } finally {
    rmSync(fixtures.root, { recursive: true, force: true });
  }
});

test("confidence parsing fails closed instead of coercing invalid values to zero", () => {
  for (const value of [undefined, null, "0.8", "junk", Number.NaN] as unknown[]) {
    const parsed = parseConceptConfidence(value);
    assert.equal(parsed.ok, false);
    assert.ok(parsed.diagnostics.some((diagnostic) => diagnostic.includes("confidence_invalid")));
  }
  assert.deepEqual(parseConceptConfidence(0), { ok: false, diagnostics: ["confidence_true_zero_suppressed"], suppress: true });
  assert.equal(parseConceptConfidence(-0.1).ok, false);
  const percent = parseConceptConfidence(82);
  assert.equal(percent.ok, true);
  if (percent.ok) {
    assert.equal(percent.value, 0.82);
    assert.deepEqual(percent.diagnostics, ["confidence_normalized_from_percent"]);
  }
});

test("OpenAI synthesis parser validates local schema and records diagnostics", () => {
  const parsed = parseOpenAIConceptSynthesisContent(JSON.stringify({
    proposals: [
      {
        canonicalLabelSuggestion: "Mission Control Audit Gate",
        definition: "Review semantic proposal confidence with strict audit and evidence gates.",
        whyItMatters: "It prevents unsupported proposals from entering Mission Control review.",
        scope: "operational_process",
        confidence: 82,
        aliasesSuggested: [],
        supportingQuotes: [{ quote: "strict confidence audit", evidenceWindowId: "evidence:1" }],
        packetIds: ["packet:1"],
      },
      {
        canonicalLabelSuggestion: "Malformed Extra Property",
        definition: "This proposal has an extra property and must fail local validation.",
        whyItMatters: "Malformed provider output should not be silently accepted.",
        scope: "operational_process",
        confidence: 0.8,
        aliasesSuggested: [],
        supportingQuotes: [{ quote: "strict confidence audit", evidenceWindowId: "evidence:1" }],
        packetIds: ["packet:1"],
        unexpected: true,
      },
      {
        canonicalLabelSuggestion: "Missing Confidence Proposal",
        definition: "This proposal is missing confidence and must be dropped.",
        whyItMatters: "Missing confidence cannot be converted to zero.",
        scope: "operational_process",
        aliasesSuggested: [],
        supportingQuotes: [{ quote: "strict confidence audit", evidenceWindowId: "evidence:1" }],
        packetIds: ["packet:1"],
      },
    ],
  }));
  assert.equal(parsed.proposals.length, 1);
  assert.equal(parsed.proposals[0].confidence, 0.82);
  assert.equal(parsed.parsedRows.length, 3);
  assert.ok(parsed.diagnostics.some((diagnostic) => diagnostic.includes("invalid_extra_property_unexpected")));
  assert.ok(parsed.diagnostics.some((diagnostic) => diagnostic.includes("confidence_invalid_missing")));
});

test("proposal generation gates invalid confidence, missing packet links, and stores audit", async () => {
  const run = await generateSemanticConceptProposalRun(bundles(), { generatedAt: "2026-06-20T08:00:00Z", maxProposals: 8, provider: new ConfidenceGateTestProvider() });
  assert.deepEqual(run.proposals.map((proposal) => proposal.canonicalLabelSuggestion), ["Mission Control Audit Gate"]);
  assert.equal(run.proposals[0].confidence, 0.82);
  assert.ok(run.proposals[0].diagnostics.includes("confidence_normalized_from_percent"));
  assert.ok(run.audit?.provider);
  assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("confidence_invalid_missing")));
  assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("confidence_true_zero_suppressed")));
  assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("unknown packetIds")));
  assert.ok(run.audit?.droppedProposals?.some((diagnostic) => diagnostic.includes("supporting quote evidenceWindowIds outside selected packets")));
});

test("OpenAI provider requests strict schema output and preserves raw audit payload", async () => {
  const originalFetch = globalThis.fetch;
  const requestBodies: Record<string, unknown>[] = [];
  try {
    globalThis.fetch = (async (_url: string | URL | Request, init?: RequestInit) => {
      const requestBody = JSON.parse(String(init?.body ?? "{}")) as Record<string, unknown>;
      requestBodies.push(requestBody);
      const packetId = (JSON.parse(String(((requestBody.messages as Array<{ content: string }>)[1]).content)) as { packets: Array<{ packetId: string; evidence: Array<{ id: string; text: string }> }> }).packets[0].packetId;
      const evidenceWindowId = (JSON.parse(String(((requestBody.messages as Array<{ content: string }>)[1]).content)) as { packets: Array<{ packetId: string; evidence: Array<{ id: string; text: string }> }> }).packets[0].evidence[0].id;
      return new Response(JSON.stringify({
        choices: [{
          message: {
            content: JSON.stringify({
              proposals: [{
                canonicalLabelSuggestion: "Mission Control Audit Gate",
                definition: "Review semantic proposal confidence with strict audit and evidence gates.",
                whyItMatters: "It prevents unsupported proposals from entering Mission Control review.",
                scope: "operational_process",
                confidence: 0.83,
                aliasesSuggested: ["Semantic audit gate"],
                supportingQuotes: [{ quote: "semantic proposal quality reviewable", evidenceWindowId }],
                packetIds: [packetId],
              }],
            }),
          },
        }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    }) as typeof fetch;
    const provider = new OpenAIConceptSynthesisProvider({ apiKey: "test-key", model: "gpt-test" });
    const run = await generateSemanticConceptProposalRun(bundles(), { generatedAt: "2026-06-20T08:30:00Z", maxProposals: 1, provider });
    const requestBody = requestBodies[0];
    assert.ok(requestBody);
    assert.equal((requestBody?.response_format as { type?: string } | undefined)?.type, "json_schema");
    assert.equal(((requestBody?.response_format as { json_schema?: { strict?: boolean } } | undefined)?.json_schema)?.strict, true);
    assert.equal(run.proposals.length, 1);
    assert.equal(run.audit?.provider?.responseFormat, "json_schema");
    assert.equal(run.audit?.provider?.provider, "openai");
    assert.equal(run.audit?.provider?.rawMessageContent?.includes("Mission Control Audit Gate"), true);
    assert.equal(run.audit?.provider?.parsedRows?.length, 1);
    assert.equal(typeof run.audit?.provider?.requestHash, "string");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("OpenAI provider fails closed when strict schema response format is rejected", async () => {
  const originalFetch = globalThis.fetch;
  const requestBodies: Record<string, unknown>[] = [];
  try {
    globalThis.fetch = (async (_url: string | URL | Request, init?: RequestInit) => {
      const requestBody = JSON.parse(String(init?.body ?? "{}")) as Record<string, unknown>;
      requestBodies.push(requestBody);
      return new Response(JSON.stringify({ error: { message: "response_format json_schema is unsupported by this model" } }), { status: 400, headers: { "content-type": "application/json" } });
    }) as typeof fetch;
    const provider = new OpenAIConceptSynthesisProvider({ apiKey: "test-key", model: "legacy-json-only" });
    await assert.rejects(
      () => generateSemanticConceptProposalRun(bundles(), { generatedAt: "2026-06-20T08:35:00Z", maxProposals: 1, provider }),
      /requires strict json_schema response_format/u,
    );
    assert.equal(requestBodies.length, 1, "must not retry with json_object fallback");
    assert.equal((requestBodies[0]?.response_format as { type?: string } | undefined)?.type, "json_schema");
    assert.ok(provider.lastSynthesisAudit?.parseDiagnostics?.some((diagnostic) => diagnostic.includes("failed_closed")));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("evaluation harness reports deterministic gates over fixture corpora", async () => {
  const testBundles = bundles();
  const file = path.join(os.tmpdir(), `semantic-eval-${Date.now()}.jsonl`);
  await import("node:fs").then((fs) => fs.writeFileSync(file, extractionBundlesToJsonl(testBundles), "utf8"));
  try {
    const report = await evaluateSemanticConceptProposalRun({ fixturesJsonl: file, maxMeetings: 3 }, { generatedAt: "2026-06-18T10:00:00Z", provider: new TestConceptSynthesisProvider() });
    assert.equal(report.meetingCount, 3);
    assert.ok(report.proposalCount >= 1);
    assert.equal(report.citedProposalRatio, 1);
    assert.ok(report.coverageProbes.some((probe) => probe.kind === "domain_term" && probe.label === "semantic"));
    assert.ok(report.coverageProbes.some((probe) => probe.kind === "people_cohort"));
  } finally {
    try { unlinkSync(file); } catch {}
  }
});

test("evaluation useful ratio does not count rejected reviews with missing usefulness scores", async () => {
  const testBundles = bundles();
  const file = path.join(os.tmpdir(), `semantic-eval-rejected-${Date.now()}.jsonl`);
  await import("node:fs").then((fs) => fs.writeFileSync(file, extractionBundlesToJsonl(testBundles), "utf8"));
  try {
    const report = await evaluateSemanticConceptProposalRun(
      { fixturesJsonl: file, maxMeetings: 3 },
      {
        generatedAt: "2026-06-18T10:00:00Z",
        provider: new TestConceptSynthesisProvider(),
        reviewEvaluations: [
          {
            contractVersion: SEMANTIC_CONTRACT_VERSION,
            proposalId: "proposal:rejected",
            reviewedAt: "2026-06-18T10:00:00Z",
            decision: "reject",
            usefulnessScore: null,
            reasons: ["not useful"],
          },
        ],
      },
    );
    assert.equal(report.usefulAcceptedRatio, 0);
    assert.equal(report.pass, false);
  } finally {
    try { unlinkSync(file); } catch {}
  }
});
