import test from "node:test";
import assert from "node:assert/strict";
import { extractSemanticMeetingNote } from "./extraction.js";
import { parseSemanticMeetingNote, parseSemanticMeetingNoteFile } from "./note-reader.js";
import { writeSemanticNoteFixtures } from "./test-support.js";

test("extracts assertion, evidence, and person candidates from curated note", () => {
  const { root, files } = writeSemanticNoteFixtures();
  const note = parseSemanticMeetingNoteFile(files[0], { allowedRoots: [root] });
  const bundle = extractSemanticMeetingNote(note);

  assert.equal(bundle.personEntities.length, 2);
  assert.equal(bundle.assertionCandidates.length, 4);
  assert.equal(bundle.evidenceWindows.length, 4);
  assert.equal(bundle.assertionCandidates.every((candidate) => candidate.source === "meeting_assistant_existing_extraction"), true);
  assert.equal(bundle.evidenceWindows.every((evidence) => evidence.offsets?.startTimestamp), true);
  assert.equal(bundle.assertionCandidates.some((candidate) => candidate.participantEntityIds.length > 0), true);
});

test("suppresses duplicate candidates within a note", () => {
  const markdown = `# Duplicate\n<!-- FATHOM:SECTION participants:start -->\n## Participants\n- Alice Example\n<!-- FATHOM:SECTION participants:end -->\n<!-- FATHOM:SECTION actions:start -->\n## Actions\n### C1\nAlice Example to build the dashboard\n\n\`\`\`text\n[00:00:01] Alice Example: build dashboard\n\`\`\`\n### C2\nAlice Example to build the dashboard\n\n\`\`\`text\n[00:00:02] Alice Example: build dashboard again\n\`\`\`\n<!-- FATHOM:SECTION actions:end -->`;
  const bundle = extractSemanticMeetingNote(parseSemanticMeetingNote(markdown));
  assert.equal(bundle.assertionCandidates.length, 1);
  assert.equal(bundle.extraction.diagnostics.some((item) => item.includes("suppressed duplicate")), true);
});

test("missing action and decision sections degrade gracefully", () => {
  const bundle = extractSemanticMeetingNote(parseSemanticMeetingNote("# Empty\n## Participants\n- Alice Example\n"));
  assert.equal(bundle.assertionCandidates.length, 0);
  assert.equal(bundle.personEntities.length, 1);
  assert.equal(bundle.extraction.diagnostics.includes("no action/decision candidates extracted from note sections"), true);
});
