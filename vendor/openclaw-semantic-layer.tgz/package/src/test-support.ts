import { mkdtempSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";

export function semanticNoteMarkdown(index: 1 | 2 | 3) {
  const dates = {
    1: "2026-06-01T09:00:00Z",
    2: "2026-06-08T09:00:00Z",
    3: "2026-06-15T09:00:00Z",
  } as const;
  const titles = {
    1: "Semantic Calibration Kickoff",
    2: "Semantic Calibration Follow-up",
    3: "Semantic Calibration Review",
  } as const;
  const recording = `sem-00${index}`;
  const dashboardEvidence = index === 1 ? "proposal precision and coverage" : index === 2 ? "proposal precision metrics" : "proposal precision review";
  const localEvidence = index === 1 ? "local test fallback" : index === 2 ? "degraded fallback index" : "local test degraded mode";
  const oneOff = index === 1 ? "Alice Example to order lunch for the workshop" : index === 2 ? "Bob Example to share meeting notes after the call" : null;

  return `---
meeting_title: ${titles[index]}
meeting_date: ${dates[index]}
recording_id: ${recording}
participants:
  - Alice Example
  - Bob Example
source: fathom
---
# ${titles[index]}

<!-- FATHOM:SECTION participants:start -->
## Participants
- Alice Example
- Bob Example
<!-- FATHOM:SECTION participants:end -->

<!-- FATHOM:SECTION actions:start -->
## Actions
### Semantic calibration dashboard
Alice Example to improve the semantic calibration dashboard with ${dashboardEvidence}.

\`\`\`text
[00:01:0${index}] Alice Example: the semantic calibration dashboard needs ${dashboardEvidence} before Mission Control review.
\`\`\`

### Local degraded indexing
Bob Example to keep local test degraded indexing available for offline evaluation.

\`\`\`text
[00:02:0${index}] Bob Example: keep the ${localEvidence} so semantic indexing works without external providers.
\`\`\`
${oneOff ? `
### One off logistics
${oneOff}.

\`\`\`text
[00:03:0${index}] Alice Example: ${oneOff}.
\`\`\`
` : ""}
<!-- FATHOM:SECTION actions:end -->

<!-- FATHOM:SECTION decisions:start -->
## Decisions
### Semantic layer independence
The team decided the semantic layer remains independent from Mission Control product writes.

\`\`\`text
[00:04:0${index}] Bob Example: semantic contracts stay in the semantic layer and Mission Control only consumes artifacts later.
\`\`\`
<!-- FATHOM:SECTION decisions:end -->

<!-- FATHOM:SECTION transcript:start -->
## Transcript
Alice Example discussed precision and coverage for semantic proposal runs.
Bob Example confirmed local test fallback behavior for indexing.
<!-- FATHOM:SECTION transcript:end -->
`;
}

export function writeSemanticNoteFixtures() {
  const root = mkdtempSync(path.join(os.tmpdir(), "semantic-fixtures-"));
  const files = [1, 2, 3].map((index) => {
    const file = path.join(root, `semantic-calibration-${index}.md`);
    writeFileSync(file, semanticNoteMarkdown(index as 1 | 2 | 3), "utf8");
    return file;
  });
  return { root, files };
}
