import { existsSync, readFileSync } from "node:fs";
import { collectMarkdownInputs, parseSemanticMeetingNoteFile } from "./note-reader.js";
import { extractSemanticMeetingNote, parseExtractionBundlesJsonl, type SemanticExtractionBundle } from "./extraction.js";
import { generateSemanticConceptProposalRun, type SemanticProposalRunOptions } from "./llm.js";
import type { SemanticConceptEvaluation, SemanticConceptProposal, SemanticConceptProposalRun, SemanticEvidencePacket } from "./contracts.js";
import { deriveAutonomousCoverageProbes, type SemanticCoverageProbe } from "./domain-coherence.js";

export type SemanticEvaluationSpec = {
  fixturesJsonl?: string;
  noteRoots?: string[];
  noteInputs?: string[];
  maxMeetings?: number;
  expectedUsefulRatio?: number;
  requireActionOrDecisionCandidates?: boolean;
};

type NumericDistribution = {
  min: number;
  median: number;
  max: number;
};

export type SemanticPacketSizeDistribution = {
  actions: NumericDistribution;
  decisions: NumericDistribution;
  evidenceWindows: NumericDistribution;
  meetings: NumericDistribution;
  totalAssertions: NumericDistribution;
};

export type SemanticConfidenceBand = "weak" | "plausible" | "strong" | "veryStrong";

export type SemanticReviewFeedbackSummary = {
  reviewCount: number;
  acceptedUsefulCount: number;
  rejectedOrNeedsEvidenceCount: number;
  highConfidenceNegativeReviewCount: number;
  usefulnessByConfidenceBand: Record<SemanticConfidenceBand, { count: number; averageUsefulness: number | null }>;
};

export type SemanticEvaluationReport = {
  generatedAt: string;
  meetingCount: number;
  proposalCount: number;
  skippedSuppressedCount: number;
  packetsCount: number;
  conceptsPerMeetingMedian: number;
  citedProposalRatio: number;
  usefulAcceptedRatio: number | null;
  duplicateRiskHighCount: number;
  duplicateConflictCount: number;
  packetSizeDistribution: SemanticPacketSizeDistribution;
  sourceKindDistribution: Record<string, number>;
  confidenceBandDistribution: Record<SemanticConfidenceBand, number>;
  qualityGateCounts: {
    specificityFailures: number;
    evidenceAlignmentFailures: number;
    packetCoherenceFailures: number;
    duplicateConflictFailures: number;
    confidenceCalibrationFailures: number;
  };
  reviewFeedback: SemanticReviewFeedbackSummary;
  coverageProbes: SemanticCoverageProbe[];
  pass: boolean;
  diagnostics: string[];
  proposalRun: SemanticConceptProposalRun;
};

const CONFIDENCE_BANDS: Record<SemanticConfidenceBand, { min: number; max: number }> = {
  weak: { min: 0.0000001, max: 0.3999999 },
  plausible: { min: 0.4, max: 0.6999999 },
  strong: { min: 0.7, max: 0.8499999 },
  veryStrong: { min: 0.85, max: 1 },
};

const GENERIC_LABEL_TERMS = new Set([
  "action",
  "actions",
  "area",
  "areas",
  "concept",
  "concepts",
  "discussion",
  "discussions",
  "follow",
  "generic",
  "item",
  "items",
  "meeting",
  "meetings",
  "misc",
  "next",
  "note",
  "notes",
  "other",
  "people",
  "person",
  "review",
  "step",
  "steps",
  "team",
  "theme",
  "themes",
  "topic",
  "topics",
  "update",
  "updates",
  "work",
]);

const OPERATIONAL_LABEL_TERMS = new Set([
  "accountability",
  "alignment",
  "architecture",
  "audit",
  "backfill",
  "boundary",
  "cadence",
  "calibration",
  "compliance",
  "confidence",
  "contract",
  "control",
  "coverage",
  "custody",
  "dashboard",
  "delivery",
  "evidence",
  "feedback",
  "gate",
  "governance",
  "handoff",
  "import",
  "index",
  "integration",
  "legal",
  "migration",
  "operations",
  "pipeline",
  "precision",
  "proposal",
  "quality",
  "registry",
  "retrieval",
  "review",
  "risk",
  "schema",
  "semantic",
  "smoke",
  "stewardship",
  "synthesis",
  "vendor",
  "workflow",
]);

function median(values: number[]) {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((left, right) => left - right);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[middle - 1] + sorted[middle]) / 2 : sorted[middle];
}

function numericDistribution(values: number[]): NumericDistribution {
  if (values.length === 0) return { min: 0, median: 0, max: 0 };
  return { min: Math.min(...values), median: median(values), max: Math.max(...values) };
}

function labelTokens(label: string) {
  return label.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/gu, "").match(/[a-z0-9]{3,}/gu) ?? [];
}

function looksLikePersonNameCluster(label: string) {
  const trimmed = label.trim();
  if (!trimmed) return false;
  const name = "[A-Z][a-z]+(?:[-'][A-Z]?[a-z]+)?";
  const fullName = `${name}(?:\\s+${name}){1,2}`;
  const connector = "(?:\\s*(?:,|&|/|and)\\s*)";
  return new RegExp(`^${fullName}(?:${connector}${fullName})*$`, "u").test(trimmed);
}

export function isOperationallySpecificConceptLabel(label: string) {
  const trimmed = label.trim();
  if (!trimmed) return false;
  if (/^(generic|misc|other|meeting|discussion|follow[-\s]?up|next steps?|team|people|person)$/iu.test(trimmed)) return false;
  const tokens = labelTokens(trimmed).filter((token) => !GENERIC_LABEL_TERMS.has(token));
  if (tokens.length < 2) return false;
  const hasOperationalTerm = tokens.some((token) => OPERATIONAL_LABEL_TERMS.has(token));
  if (looksLikePersonNameCluster(trimmed) && !hasOperationalTerm) return false;
  return hasOperationalTerm || tokens.length >= 3;
}

function confidenceBand(confidence: number): SemanticConfidenceBand | null {
  for (const [band, range] of Object.entries(CONFIDENCE_BANDS) as Array<[SemanticConfidenceBand, { min: number; max: number }]>) {
    if (confidence >= range.min && confidence <= range.max) return band;
  }
  return null;
}

function packetSetKey(packetIds: string[]) {
  return [...new Set(packetIds)].sort().join("|");
}

function jaccard(left: string[], right: string[]) {
  const leftSet = new Set(left);
  const rightSet = new Set(right);
  const union = new Set([...leftSet, ...rightSet]);
  if (union.size === 0) return 0;
  const intersection = [...leftSet].filter((value) => rightSet.has(value)).length;
  return intersection / union.size;
}

function selectedPackets(proposal: SemanticConceptProposal, run: SemanticConceptProposalRun) {
  const packetIds = new Set(proposal.retrieval.evidencePacketIds);
  return run.evidencePackets.filter((packet) => packetIds.has(packet.packetId));
}

function hasAlignedActionOrDecisionAndQuoteInSamePacket(proposal: SemanticConceptProposal, packets: SemanticEvidencePacket[]) {
  const linkedAssertions = new Set([...proposal.linkedActionIds, ...proposal.linkedDecisionIds]);
  const quoteEvidenceIds = new Set(proposal.supportingQuotes.map((quote) => quote.evidenceWindowId).filter((id): id is string => typeof id === "string" && id.length > 0));
  if (linkedAssertions.size === 0 || quoteEvidenceIds.size === 0) return false;
  for (const packet of packets) {
    const packetAssertions = [...packet.includedActionIds, ...packet.includedDecisionIds];
    const assertionAligned = packetAssertions.some((id) => linkedAssertions.has(id));
    const quoteAligned = packet.evidenceWindowIds.some((id) => quoteEvidenceIds.has(id));
    if (assertionAligned && quoteAligned) return true;
  }
  return false;
}

function packetLooksCoherent(proposal: SemanticConceptProposal, packets: SemanticEvidencePacket[]) {
  const actionDecisionCount = proposal.linkedActionIds.length + proposal.linkedDecisionIds.length;
  const evidenceCount = proposal.linkedEvidenceWindowIds.length;
  const meetingCount = new Set(packets.flatMap((packet) => packet.meetingIds)).size;
  if (!hasAlignedActionOrDecisionAndQuoteInSamePacket(proposal, packets)) return false;
  if (actionDecisionCount > 8 || evidenceCount > 12 || meetingCount > 4) return false;
  return !packets.some((packet) => packet.diagnostics?.some((diagnostic) => /unrelated|fallback_all_meeting|coarse_meeting_bundle/iu.test(diagnostic)));
}

function skippedSuppressedCount(run: SemanticConceptProposalRun) {
  const dropped = run.audit?.droppedProposals?.length ?? 0;
  const diagnostics = run.diagnostics.filter((diagnostic) => /\b(dropped|suppressed|skipped)\b/iu.test(diagnostic)).length;
  return Math.max(dropped, diagnostics);
}

function duplicateConflictCount(run: SemanticConceptProposalRun) {
  let count = run.diagnostics.filter((diagnostic) => /duplicate packet-set|conflicting labels?|near-identical evidence/iu.test(diagnostic)).length;
  const proposals = run.proposals;
  for (let leftIndex = 0; leftIndex < proposals.length; leftIndex += 1) {
    for (let rightIndex = leftIndex + 1; rightIndex < proposals.length; rightIndex += 1) {
      const left = proposals[leftIndex];
      const right = proposals[rightIndex];
      const samePacketSet = packetSetKey(left.retrieval.evidencePacketIds) === packetSetKey(right.retrieval.evidencePacketIds);
      const nearIdenticalPackets = jaccard(left.retrieval.evidencePacketIds, right.retrieval.evidencePacketIds) >= 0.8;
      const sameEvidence = jaccard(left.linkedEvidenceWindowIds, right.linkedEvidenceWindowIds) >= 0.8;
      const differentLabel = left.canonicalLabelSuggestion.toLowerCase() !== right.canonicalLabelSuggestion.toLowerCase();
      if (differentLabel && (samePacketSet || (nearIdenticalPackets && sameEvidence))) count += 1;
    }
  }
  return count;
}

function confidenceBandDistribution(proposals: SemanticConceptProposal[]) {
  const distribution: Record<SemanticConfidenceBand, number> = { weak: 0, plausible: 0, strong: 0, veryStrong: 0 };
  for (const proposal of proposals) {
    const band = confidenceBand(proposal.confidence);
    if (band) distribution[band] += 1;
  }
  return distribution;
}

function packetSizeDistribution(packets: SemanticEvidencePacket[]): SemanticPacketSizeDistribution {
  return {
    actions: numericDistribution(packets.map((packet) => packet.includedActionIds.length)),
    decisions: numericDistribution(packets.map((packet) => packet.includedDecisionIds.length)),
    evidenceWindows: numericDistribution(packets.map((packet) => packet.evidenceWindowIds.length)),
    meetings: numericDistribution(packets.map((packet) => packet.meetingIds.length)),
    totalAssertions: numericDistribution(packets.map((packet) => packet.includedActionIds.length + packet.includedDecisionIds.length)),
  };
}

function sourceKindDistribution(packets: SemanticEvidencePacket[]) {
  const distribution: Record<string, number> = {};
  for (const packet of packets) {
    for (const score of packet.retrievalScores) {
      distribution[score.sourceKind] = (distribution[score.sourceKind] ?? 0) + 1;
    }
    // Evaluation can run over fixture JSONL without an indexed DB. In that smoke path,
    // packets are still meaningful, so expose source-kind counts from packet links too.
    if (packet.retrievalScores.length === 0) {
      distribution.assertion_candidate = (distribution.assertion_candidate ?? 0) + packet.includedActionIds.length + packet.includedDecisionIds.length;
      distribution.evidence_window = (distribution.evidence_window ?? 0) + packet.evidenceWindowIds.length;
      distribution.meeting_note = (distribution.meeting_note ?? 0) + packet.meetingIds.length;
    }
  }
  return distribution;
}

function reviewFeedbackSummary(proposals: SemanticConceptProposal[], reviews: SemanticConceptEvaluation[]): SemanticReviewFeedbackSummary {
  const byProposalId = new Map(proposals.map((proposal) => [proposal.proposalId, proposal]));
  const usefulScoresByBand: Record<SemanticConfidenceBand, number[]> = { weak: [], plausible: [], strong: [], veryStrong: [] };
  let acceptedUsefulCount = 0;
  let rejectedOrNeedsEvidenceCount = 0;
  let highConfidenceNegativeReviewCount = 0;
  for (const review of reviews) {
    const proposal = byProposalId.get(review.proposalId);
    const band = proposal ? confidenceBand(proposal.confidence) : null;
    if (band && typeof review.usefulnessScore === "number" && Number.isFinite(review.usefulnessScore)) usefulScoresByBand[band].push(review.usefulnessScore);
    if (review.decision === "accept" && (review.usefulnessScore == null || review.usefulnessScore >= 0.7)) acceptedUsefulCount += 1;
    if (review.decision === "reject" || review.decision === "needs_more_evidence") rejectedOrNeedsEvidenceCount += 1;
    const negative = review.decision === "reject" || review.decision === "needs_more_evidence" || (review.usefulnessScore != null && review.usefulnessScore < 0.5) || (review.evidenceSupportScore != null && review.evidenceSupportScore < 0.5) || review.duplicateRisk === "high";
    if (proposal && proposal.confidence >= 0.7 && negative) highConfidenceNegativeReviewCount += 1;
  }
  return {
    reviewCount: reviews.length,
    acceptedUsefulCount,
    rejectedOrNeedsEvidenceCount,
    highConfidenceNegativeReviewCount,
    usefulnessByConfidenceBand: Object.fromEntries(
      (Object.keys(usefulScoresByBand) as SemanticConfidenceBand[]).map((band) => {
        const scores = usefulScoresByBand[band];
        return [band, { count: scores.length, averageUsefulness: scores.length ? scores.reduce((sum, score) => sum + score, 0) / scores.length : null }];
      }),
    ) as Record<SemanticConfidenceBand, { count: number; averageUsefulness: number | null }>,
  };
}

function confidenceCalibrationFailures(proposals: SemanticConceptProposal[], reviews: SemanticConceptEvaluation[]) {
  let failures = 0;
  const byProposalId = new Map(proposals.map((proposal) => [proposal.proposalId, proposal]));
  for (const proposal of proposals) {
    if (!Number.isFinite(proposal.confidence) || proposal.confidence <= 0 || proposal.confidence > 1) failures += 1;
  }
  if (reviews.length === 0) return failures;
  for (const review of reviews) {
    const proposal = byProposalId.get(review.proposalId);
    if (!proposal) continue;
    const negative = review.decision === "reject" || review.decision === "needs_more_evidence" || (review.usefulnessScore != null && review.usefulnessScore < 0.5) || (review.evidenceSupportScore != null && review.evidenceSupportScore < 0.5) || review.duplicateRisk === "high";
    if (proposal.confidence >= 0.7 && negative) failures += 1;
    const positive = review.decision === "accept" && (review.usefulnessScore == null || review.usefulnessScore >= 0.8) && (review.evidenceSupportScore == null || review.evidenceSupportScore >= 0.8);
    if (proposal.confidence < 0.4 && positive) failures += 1;
  }
  return failures;
}

export function evaluateSemanticProposalRunQuality(run: SemanticConceptProposalRun, reviews: SemanticConceptEvaluation[] = []) {
  const diagnostics: string[] = [];
  let specificityFailures = 0;
  let evidenceAlignmentFailures = 0;
  let packetCoherenceFailures = 0;
  for (const proposal of run.proposals) {
    if (!isOperationallySpecificConceptLabel(proposal.canonicalLabelSuggestion)) {
      specificityFailures += 1;
      diagnostics.push(`proposal ${proposal.proposalId} failed specificity gate: ${proposal.canonicalLabelSuggestion}`);
    }
    const packets = selectedPackets(proposal, run);
    if (!hasAlignedActionOrDecisionAndQuoteInSamePacket(proposal, packets)) {
      evidenceAlignmentFailures += 1;
      diagnostics.push(`proposal ${proposal.proposalId} failed evidence alignment gate`);
    }
    if (!packetLooksCoherent(proposal, packets)) {
      packetCoherenceFailures += 1;
      diagnostics.push(`proposal ${proposal.proposalId} failed packet coherence gate`);
    }
  }
  const duplicateConflictFailures = duplicateConflictCount(run);
  if (duplicateConflictFailures > 0) diagnostics.push(`duplicate/conflict gate detected ${duplicateConflictFailures} duplicate or conflicting packet-set proposal(s)`);
  const confidenceFailures = confidenceCalibrationFailures(run.proposals, reviews);
  if (confidenceFailures > 0) diagnostics.push(`confidence calibration gate detected ${confidenceFailures} invalid or review-miscalibrated proposal(s)`);
  return {
    diagnostics,
    skippedSuppressedCount: skippedSuppressedCount(run),
    duplicateConflictCount: duplicateConflictFailures,
    packetSizeDistribution: packetSizeDistribution(run.evidencePackets),
    sourceKindDistribution: sourceKindDistribution(run.evidencePackets),
    confidenceBandDistribution: confidenceBandDistribution(run.proposals),
    qualityGateCounts: {
      specificityFailures,
      evidenceAlignmentFailures,
      packetCoherenceFailures,
      duplicateConflictFailures,
      confidenceCalibrationFailures: confidenceFailures,
    },
    reviewFeedback: reviewFeedbackSummary(run.proposals, reviews),
  };
}

export function loadEvaluationBundles(spec: SemanticEvaluationSpec): SemanticExtractionBundle[] {
  const requireCandidates = spec.requireActionOrDecisionCandidates ?? true;
  const limit = spec.maxMeetings;
  const select = (bundles: SemanticExtractionBundle[]) => {
    const eligible = requireCandidates ? bundles.filter((bundle) => bundle.assertionCandidates.length > 0) : bundles;
    return limit == null ? eligible : eligible.slice(0, limit);
  };
  if (spec.fixturesJsonl) {
    return select(parseExtractionBundlesJsonl(readFileSync(spec.fixturesJsonl, "utf8")));
  }
  if (!spec.noteRoots?.length || !spec.noteInputs?.length) return [];
  const inputs = collectMarkdownInputs(spec.noteInputs, spec.noteRoots);
  return select(inputs.map((inputPath) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(inputPath, { allowedRoots: spec.noteRoots! }))));
}

export async function evaluateSemanticConceptProposalRun(
  spec: SemanticEvaluationSpec,
  options: SemanticProposalRunOptions & { reviewEvaluations?: SemanticConceptEvaluation[] } = {},
): Promise<SemanticEvaluationReport> {
  const generatedAt = options.generatedAt ?? new Date().toISOString();
  const bundles = loadEvaluationBundles(spec);
  const proposalRun = await generateSemanticConceptProposalRun(bundles, { ...options, generatedAt });
  const proposalsByMeeting = new Map<string, number>();
  for (const meetingId of proposalRun.sourceWindow.meetingIds) proposalsByMeeting.set(meetingId, 0);
  for (const proposal of proposalRun.proposals) {
    const packetMeetingIds = new Set(proposalRun.evidencePackets.filter((packet) => proposal.retrieval.evidencePacketIds.includes(packet.packetId)).flatMap((packet) => packet.meetingIds));
    for (const meetingId of packetMeetingIds) proposalsByMeeting.set(meetingId, (proposalsByMeeting.get(meetingId) ?? 0) + 1);
  }
  const cited = proposalRun.proposals.filter((proposal) => hasAlignedActionOrDecisionAndQuoteInSamePacket(proposal, selectedPackets(proposal, proposalRun))).length;
  const reviews = options.reviewEvaluations ?? [];
  const useful = reviews.filter((review) => review.decision === "accept" && (review.usefulnessScore == null || review.usefulnessScore >= 0.7)).length;
  const usefulAcceptedRatio = reviews.length ? useful / reviews.length : null;
  const duplicateRiskHighCount = reviews.filter((review) => review.duplicateRisk === "high").length;
  const quality = evaluateSemanticProposalRunQuality(proposalRun, reviews);
  const coverageProbes = deriveAutonomousCoverageProbes(bundles, proposalRun);
  const coverageDiagnostics = coverageProbes
    .filter((probe) => probe.status === "missing")
    .map((probe) => `coverage_probe_missing:${probe.kind}:${probe.label}:${probe.supportCount}`);
  const diagnostics: string[] = [...proposalRun.diagnostics, ...quality.diagnostics, ...coverageDiagnostics];
  const conceptsPerMeetingMedian = median([...proposalsByMeeting.values()]);
  const citedProposalRatio = proposalRun.proposals.length ? cited / proposalRun.proposals.length : 0;
  const expectedUsefulRatio = spec.expectedUsefulRatio ?? 0.7;
  if (bundles.length === 0) diagnostics.push("no evaluation bundles loaded");
  if (proposalRun.proposals.length === 0) diagnostics.push("no proposals generated");
  if (citedProposalRatio < 1) diagnostics.push("some proposals are missing action/decision/evidence support");
  if (usefulAcceptedRatio != null && usefulAcceptedRatio < expectedUsefulRatio) diagnostics.push(`useful accepted ratio ${usefulAcceptedRatio.toFixed(2)} below target ${expectedUsefulRatio}`);
  const qualityPass = Object.values(quality.qualityGateCounts).every((count) => count === 0);
  const pass = bundles.length > 0 && proposalRun.proposals.length > 0 && citedProposalRatio === 1 && qualityPass && (usefulAcceptedRatio == null || usefulAcceptedRatio >= expectedUsefulRatio);
  return {
    generatedAt,
    meetingCount: bundles.length,
    proposalCount: proposalRun.proposals.length,
    skippedSuppressedCount: quality.skippedSuppressedCount,
    packetsCount: proposalRun.evidencePackets.length,
    conceptsPerMeetingMedian,
    citedProposalRatio,
    usefulAcceptedRatio,
    duplicateRiskHighCount,
    duplicateConflictCount: quality.duplicateConflictCount,
    packetSizeDistribution: quality.packetSizeDistribution,
    sourceKindDistribution: quality.sourceKindDistribution,
    confidenceBandDistribution: quality.confidenceBandDistribution,
    qualityGateCounts: quality.qualityGateCounts,
    reviewFeedback: quality.reviewFeedback,
    coverageProbes,
    pass,
    diagnostics,
    proposalRun,
  };
}

export function maybeRealMeetingEvaluationSpec(paths: { fixturesJsonl?: string; noteRoot?: string; noteGlobOrPath?: string }): SemanticEvaluationSpec | null {
  if (paths.fixturesJsonl && existsSync(paths.fixturesJsonl)) return { fixturesJsonl: paths.fixturesJsonl, maxMeetings: 10 };
  if (paths.noteRoot && paths.noteGlobOrPath && existsSync(paths.noteRoot)) return { noteRoots: [paths.noteRoot], noteInputs: [paths.noteGlobOrPath], maxMeetings: 10 };
  return null;
}
