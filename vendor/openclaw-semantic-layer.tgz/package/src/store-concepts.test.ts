import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtempSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { calibrateConceptProposals, type CalibrationSpec } from "./calibration.js";
import { generateConceptProposalRun } from "./concepts.js";
import { extractSemanticMeetingNote } from "./extraction.js";
import { parseSemanticMeetingNoteFile } from "./note-reader.js";
import { buildSemanticIndex, openSemanticStore, retrieveSemanticNeighbors, semanticIndexStatus } from "./store.js";
import { writeSemanticNoteFixtures } from "./test-support.js";

class TestEmbeddingProvider {
  provider = "test-local";
  model = "hash-bow-test";
  dimensions = 64;
  degraded = true;

  embed(texts: string[]) {
    return texts.map((text) => {
      const vector = Array.from({ length: this.dimensions }, () => 0);
      for (const token of text.toLowerCase().match(/[a-z0-9]{3,}/gu) ?? []) {
        const hash = createHash("sha256").update(token).digest();
        const index = hash.readUInt32BE(0) % this.dimensions;
        vector[index] += hash.readUInt8(4) % 2 === 0 ? 1 : -1;
      }
      const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
      return magnitude > 0 ? vector.map((value) => value / magnitude) : vector;
    });
  }
}

function fixtureBundles() {
  const { root, files } = writeSemanticNoteFixtures();
  return files.map((file) => extractSemanticMeetingNote(parseSemanticMeetingNoteFile(file, { allowedRoots: [root] })));
}

test("builds idempotent local degraded index and retrieves hybrid neighbors", async () => {
  const dbPath = path.join(mkdtempSync(path.join(os.tmpdir(), "semantic-db-")), "semantic.sqlite");
  const db = openSemanticStore(dbPath);
  const bundles = fixtureBundles();

  const provider = new TestEmbeddingProvider();
  const first = await buildSemanticIndex(db, bundles, provider);
  const second = await buildSemanticIndex(db, bundles, provider);
  const status = semanticIndexStatus(db);
  const results = await retrieveSemanticNeighbors(db, "semantic calibration dashboard proposal precision", { limit: 3, provider });

  assert.equal(first.status, "degraded");
  assert.equal(second.chunkCount, first.chunkCount);
  assert.equal(status.notes, 3);
  assert.equal(status.candidates, 11);
  assert.equal(status.chunks, first.chunkCount);
  assert.match(results[0].chunk.text, /semantic calibration dashboard|proposal precision/iu);
  db.close();
});

test("generates recurring evidence-supported concept proposals and excludes one-offs", () => {
  const run = generateConceptProposalRun(fixtureBundles(), { similarityThreshold: 0.28 });

  assert.equal(run.degraded, true);
  assert.equal(run.candidates.some((candidate) => candidate.summarySuggestion?.toLowerCase().includes("semantic calibration dashboard")), true);
  assert.equal(run.candidates.some((candidate) => candidate.summarySuggestion?.includes("order lunch")), false);
  assert.equal(run.candidates.every((candidate) => candidate.meetingCount >= 2 && candidate.evidenceWindowCount >= 2), true);
});

test("calibration reports precision, coverage, duplicate rate, and degraded mode", () => {
  const spec: CalibrationSpec = {
    goldenConcepts: [
      { label: "Semantic calibration dashboard", requiredTextIncludes: ["semantic calibration dashboard", "proposal precision metrics"] },
      { label: "Local degraded indexing", requiredTextIncludes: ["local test", "degraded indexing"] },
    ],
    negativeTextIncludes: ["order lunch", "meeting notes after the call"],
  };
  const report = calibrateConceptProposals(fixtureBundles(), spec);
  const best = report.sweeps.find((sweep) => JSON.stringify(sweep.thresholds) === JSON.stringify(report.recommendation.thresholds));

  assert.equal(report.degraded, true);
  assert.ok(best);
  assert.ok(best!.precisionAtK >= 0.5);
  assert.ok(best!.coverage >= 0.5);
  assert.ok(best!.duplicateRate >= 0);
});
