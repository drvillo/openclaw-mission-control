import { createHash } from "node:crypto";

export const SEMANTIC_CONTRACT_VERSION = "semantic-contracts/v1" as const;

export const SEMANTIC_CONTRACT_SCHEMA_IDS = {
  sourceRef: "openclaw.semantic.SemanticSourceRef.v1",
  evidencePacket: "openclaw.semantic.SemanticEvidencePacket.v1",
  conceptProposal: "openclaw.semantic.SemanticConceptProposal.v1",
  conceptSynthesisOutput: "openclaw.semantic.ConceptSynthesisOutput.v1",
  conceptProposalRun: "openclaw.semantic.SemanticConceptProposalRun.v1",
  conceptRegistryEntry: "openclaw.semantic.ConceptRegistryEntry.v1",
  conceptAliasMapping: "openclaw.semantic.ConceptAliasMapping.v1",
  conceptRegistrySnapshot: "openclaw.semantic.ConceptRegistrySnapshot.v1",
  conceptEvaluation: "openclaw.semantic.SemanticConceptEvaluation.v1",
} as const;

export type SemanticContractVersion = typeof SEMANTIC_CONTRACT_VERSION;

export type SemanticSourceRef = {
  sourceSystem: string;
  sourceType: "meeting_note" | string;
  sourceId: string;
  canonicalSourcePath?: string | null;
  contentHash?: string | null;
  recordingId?: string | null;
  meetingAssistantRunId?: string | null;
  missionControlId?: string | null;
};

export type SemanticActionRef = {
  refType: "action";
  actionId: string;
  sourceRef: SemanticSourceRef;
  candidateId?: string | null;
};

export type SemanticDecisionRef = {
  refType: "decision";
  decisionId: string;
  sourceRef: SemanticSourceRef;
  candidateId?: string | null;
};

export type SemanticEvidenceRef = {
  refType: "evidence_window";
  evidenceWindowId: string;
  sourceRef: SemanticSourceRef;
  contentHash?: string | null;
};

export type SemanticCitationRef = SemanticActionRef | SemanticDecisionRef | SemanticEvidenceRef;

export type SemanticRetrievalScore = {
  sourceId: string;
  sourceKind: "action" | "decision" | "evidence_window" | "meeting_note" | "registry_entry" | string;
  score: number;
  rank?: number | null;
  lexicalScore?: number | null;
  vectorScore?: number | null;
  combinedScore?: number | null;
  textLength?: number | null;
  sectionName?: string | null;
  sourceKindWeight?: number | null;
  diagnostics?: string[];
  exclusionReason?: string | null;
  downrankReason?: string | null;
};

export type SemanticEvidencePacket = {
  contractVersion: SemanticContractVersion;
  packetId: string;
  query: {
    reason: string;
    text?: string | null;
    seedRefs?: SemanticCitationRef[];
  };
  includedActionIds: string[];
  includedDecisionIds: string[];
  evidenceWindowIds: string[];
  meetingIds: string[];
  noteRefs: SemanticSourceRef[];
  peopleEntityRefs: string[];
  retrievalScores: SemanticRetrievalScore[];
  diagnostics?: string[];
  generatedAt: string;
  indexVersion: string;
};

export type SemanticPromptVersion = {
  promptId: string;
  version: string;
  contractVersion: SemanticContractVersion;
};

export type SemanticModelMetadata = {
  provider: string;
  model: string;
  modelVersion?: string | null;
  temperature?: number | null;
  maxOutputTokens?: number | null;
};

export type SemanticPromptMetadata = {
  promptVersion: SemanticPromptVersion;
  model: SemanticModelMetadata;
  inputHash?: string | null;
  outputSchemaId: string;
};

export type SemanticProviderAudit = {
  provider: string;
  model: string;
  modelMetadata?: SemanticModelMetadata | null;
  promptVersion: SemanticPromptVersion;
  outputSchemaId: string;
  requestHash?: string | null;
  responseFormat?: string | null;
  responsePayload?: unknown;
  rawMessageContent?: string | null;
  parsedRows?: unknown[];
  parseDiagnostics: string[];
};

export type SemanticConceptScope =
  | "personal"
  | "team"
  | "company"
  | "project"
  | "client_vendor"
  | "security_compliance"
  | "operational_process"
  | "strategic_commercial";

export type SemanticRegistryAction = "map_existing" | "add_alias" | "propose_new" | "reject";

export type SemanticSupportingQuote = {
  quote: string;
  sourceRef: SemanticSourceRef;
  evidenceWindowId?: string | null;
};

export type SemanticConceptProposal = {
  contractVersion: SemanticContractVersion;
  proposalId: string;
  proposalRunId: string;
  canonicalLabelSuggestion: string;
  definition: string;
  whyItMatters: string;
  scope: SemanticConceptScope;
  confidence: number;
  registryAction: SemanticRegistryAction;
  existingConceptId?: string | null;
  aliasesSuggested: string[];
  linkedActionIds: string[];
  linkedDecisionIds: string[];
  linkedEvidenceWindowIds: string[];
  supportingQuotes: SemanticSupportingQuote[];
  rejectionReason?: string | null;
  prompt: SemanticPromptMetadata;
  retrieval: {
    indexVersion: string;
    evidencePacketIds: string[];
  };
  diagnostics: string[];
  rawJson?: Record<string, unknown>;
};

export type SemanticConceptProposalRun = {
  contractVersion: SemanticContractVersion;
  proposalRunId: string;
  sourceWindow: {
    meetingIds: string[];
    dateRange?: { from?: string | null; to?: string | null } | null;
    filter?: string | null;
  };
  indexVersion: string;
  registrySnapshotVersion: string;
  promptVersion: SemanticPromptVersion;
  generatedAt: string;
  evidencePackets: SemanticEvidencePacket[];
  proposals: SemanticConceptProposal[];
  diagnostics: string[];
  audit?: {
    provider?: SemanticProviderAudit | null;
    droppedProposals?: string[];
  };
};

export type ConceptRegistryEntryStatus = "accepted" | "merged" | "deprecated" | "candidate";

export type ConceptRegistryEntry = {
  contractVersion: SemanticContractVersion;
  conceptId: string;
  canonicalLabel: string;
  definition: string;
  scope: SemanticConceptScope;
  aliases: string[];
  status: ConceptRegistryEntryStatus;
  createdAt: string;
  updatedAt: string;
  sourceRefs: SemanticSourceRef[];
};

export type ConceptAliasMapping = {
  contractVersion: SemanticContractVersion;
  alias: string;
  normalizedAlias: string;
  conceptId: string;
  source: "registry" | "proposal" | "manual" | string;
  confidence: number;
};

export type ConceptRegistrySnapshot = {
  contractVersion: SemanticContractVersion;
  registrySnapshotVersion: string;
  generatedAt: string;
  entries: ConceptRegistryEntry[];
  aliases: ConceptAliasMapping[];
};

export type SemanticConceptReviewDecision = "accept" | "reject" | "merge" | "add_alias" | "needs_more_evidence";

export type SemanticConceptEvaluation = {
  contractVersion: SemanticContractVersion;
  proposalId: string;
  reviewerRef?: string | null;
  reviewedAt: string;
  decision: SemanticConceptReviewDecision;
  usefulnessScore?: number | null;
  evidenceSupportScore?: number | null;
  duplicateRisk?: "low" | "medium" | "high" | null;
  reasons: string[];
  targetConceptId?: string | null;
  aliasesAccepted?: string[];
};

export type SemanticValidationIssue = {
  path: string;
  code: string;
  message: string;
};

export type SemanticValidationResult<T> =
  | { ok: true; value: T; issues: [] }
  | { ok: false; issues: SemanticValidationIssue[] };

function sha256Hex(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function stableCanonicalize(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableCanonicalize).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>)
    .filter(([, entryValue]) => entryValue !== undefined)
    .sort(([left], [right]) => left.localeCompare(right));
  return `{${entries.map(([key, entryValue]) => `${JSON.stringify(key)}:${stableCanonicalize(entryValue)}`).join(",")}}`;
}

export function semanticContentHash(value: unknown) {
  return sha256Hex(stableCanonicalize(value));
}

export function stableSemanticId(prefix: string, ...parts: unknown[]) {
  return `${prefix}:${sha256Hex(parts.map(stableCanonicalize).join("\0")).slice(0, 32)}`;
}

export function semanticEvidencePacketId(input: Pick<SemanticEvidencePacket, "query" | "includedActionIds" | "includedDecisionIds" | "evidenceWindowIds" | "meetingIds" | "indexVersion">) {
  return stableSemanticId("evidence-packet", {
    query: input.query,
    includedActionIds: [...input.includedActionIds].sort(),
    includedDecisionIds: [...input.includedDecisionIds].sort(),
    evidenceWindowIds: [...input.evidenceWindowIds].sort(),
    meetingIds: [...input.meetingIds].sort(),
    indexVersion: input.indexVersion,
  });
}

export function semanticConceptProposalId(input: Pick<SemanticConceptProposal, "proposalRunId" | "canonicalLabelSuggestion" | "scope" | "linkedActionIds" | "linkedDecisionIds" | "linkedEvidenceWindowIds">) {
  return stableSemanticId("concept-proposal", {
    proposalRunId: input.proposalRunId,
    canonicalLabelSuggestion: input.canonicalLabelSuggestion,
    scope: input.scope,
    linkedActionIds: [...input.linkedActionIds].sort(),
    linkedDecisionIds: [...input.linkedDecisionIds].sort(),
    linkedEvidenceWindowIds: [...input.linkedEvidenceWindowIds].sort(),
  });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0;
}

function isOptionalString(value: unknown): value is string | null | undefined {
  return value === undefined || value === null || typeof value === "string";
}

function isNumberInRange(value: unknown, min = 0, max = 1): value is number {
  return typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

function issue(path: string, code: string, message: string): SemanticValidationIssue {
  return { path, code, message };
}

function validateContractVersion(value: Record<string, unknown>, issues: SemanticValidationIssue[], path = "contractVersion") {
  if (value.contractVersion !== SEMANTIC_CONTRACT_VERSION) {
    issues.push(issue(path, "invalid_contract_version", `Expected ${SEMANTIC_CONTRACT_VERSION}.`));
  }
}

function validateStringField(value: Record<string, unknown>, key: string, issues: SemanticValidationIssue[], path = key) {
  if (!isString(value[key])) issues.push(issue(path, "required_string", `${key} must be a non-empty string.`));
}

function validateStringArrayField(value: Record<string, unknown>, key: string, issues: SemanticValidationIssue[], path = key) {
  if (!isStringArray(value[key])) issues.push(issue(path, "required_string_array", `${key} must be an array of strings.`));
}

function validateSourceRefShape(value: unknown, issues: SemanticValidationIssue[], path: string) {
  if (!isRecord(value)) {
    issues.push(issue(path, "required_object", "SemanticSourceRef must be an object."));
    return;
  }
  validateStringField(value, "sourceSystem", issues, `${path}.sourceSystem`);
  validateStringField(value, "sourceType", issues, `${path}.sourceType`);
  validateStringField(value, "sourceId", issues, `${path}.sourceId`);
  for (const key of ["canonicalSourcePath", "contentHash", "recordingId", "meetingAssistantRunId", "missionControlId"] as const) {
    if (!isOptionalString(value[key])) issues.push(issue(`${path}.${key}`, "optional_string", `${key} must be a string, null, or omitted.`));
  }
}

export function validateSemanticSourceRef(value: unknown): SemanticValidationResult<SemanticSourceRef> {
  const issues: SemanticValidationIssue[] = [];
  validateSourceRefShape(value, issues, "$sourceRef");
  return issues.length === 0 ? { ok: true, value: value as SemanticSourceRef, issues: [] } : { ok: false, issues };
}

export function isSemanticSourceRef(value: unknown): value is SemanticSourceRef {
  return validateSemanticSourceRef(value).ok;
}

function validatePromptVersion(value: unknown, issues: SemanticValidationIssue[], path: string) {
  if (!isRecord(value)) {
    issues.push(issue(path, "required_object", "promptVersion must be an object."));
    return;
  }
  validateStringField(value, "promptId", issues, `${path}.promptId`);
  validateStringField(value, "version", issues, `${path}.version`);
  validateContractVersion(value, issues, `${path}.contractVersion`);
}

function validatePromptMetadata(value: unknown, issues: SemanticValidationIssue[], path: string) {
  if (!isRecord(value)) {
    issues.push(issue(path, "required_object", "prompt metadata must be an object."));
    return;
  }
  validatePromptVersion(value.promptVersion, issues, `${path}.promptVersion`);
  if (!isRecord(value.model)) {
    issues.push(issue(`${path}.model`, "required_object", "model metadata must be an object."));
  } else {
    validateStringField(value.model, "provider", issues, `${path}.model.provider`);
    validateStringField(value.model, "model", issues, `${path}.model.model`);
  }
  validateStringField(value, "outputSchemaId", issues, `${path}.outputSchemaId`);
}

function validateRetrievalScores(value: unknown, issues: SemanticValidationIssue[], path: string) {
  if (!Array.isArray(value)) {
    issues.push(issue(path, "required_array", "retrievalScores must be an array."));
    return;
  }
  value.forEach((score, index) => {
    if (!isRecord(score)) {
      issues.push(issue(`${path}[${index}]`, "required_object", "retrieval score must be an object."));
      return;
    }
    validateStringField(score, "sourceId", issues, `${path}[${index}].sourceId`);
    validateStringField(score, "sourceKind", issues, `${path}[${index}].sourceKind`);
    if (!isNumberInRange(score.score, 0, Number.POSITIVE_INFINITY)) issues.push(issue(`${path}[${index}].score`, "required_number", "score must be a non-negative number."));
  });
}

export function validateSemanticEvidencePacket(value: unknown): SemanticValidationResult<SemanticEvidencePacket> {
  const issues: SemanticValidationIssue[] = [];
  if (!isRecord(value)) return { ok: false, issues: [issue("$packet", "required_object", "SemanticEvidencePacket must be an object.")] };
  validateContractVersion(value, issues);
  validateStringField(value, "packetId", issues);
  validateStringField(value, "generatedAt", issues);
  validateStringField(value, "indexVersion", issues);
  if (!isRecord(value.query)) {
    issues.push(issue("query", "required_object", "query must be an object."));
  } else {
    validateStringField(value.query, "reason", issues, "query.reason");
  }
  for (const key of ["includedActionIds", "includedDecisionIds", "evidenceWindowIds", "meetingIds", "peopleEntityRefs"] as const) {
    validateStringArrayField(value, key, issues);
  }
  if (!Array.isArray(value.noteRefs)) {
    issues.push(issue("noteRefs", "required_array", "noteRefs must be an array."));
  } else {
    value.noteRefs.forEach((ref, index) => validateSourceRefShape(ref, issues, `noteRefs[${index}]`));
  }
  validateRetrievalScores(value.retrievalScores, issues, "retrievalScores");
  return issues.length === 0 ? { ok: true, value: value as SemanticEvidencePacket, issues: [] } : { ok: false, issues };
}

export function isSemanticEvidencePacket(value: unknown): value is SemanticEvidencePacket {
  return validateSemanticEvidencePacket(value).ok;
}

export function validateSemanticConceptProposal(value: unknown): SemanticValidationResult<SemanticConceptProposal> {
  const issues: SemanticValidationIssue[] = [];
  if (!isRecord(value)) return { ok: false, issues: [issue("$proposal", "required_object", "SemanticConceptProposal must be an object.")] };
  validateContractVersion(value, issues);
  for (const key of ["proposalId", "proposalRunId", "canonicalLabelSuggestion", "definition", "whyItMatters"] as const) {
    validateStringField(value, key, issues);
  }
  if (!["personal", "team", "company", "project", "client_vendor", "security_compliance", "operational_process", "strategic_commercial"].includes(String(value.scope))) {
    issues.push(issue("scope", "invalid_scope", "scope is not a supported semantic concept scope."));
  }
  if (!["map_existing", "add_alias", "propose_new", "reject"].includes(String(value.registryAction))) {
    issues.push(issue("registryAction", "invalid_registry_action", "registryAction is not supported."));
  }
  if (!isNumberInRange(value.confidence)) issues.push(issue("confidence", "confidence_range", "confidence must be between 0 and 1."));
  for (const key of ["aliasesSuggested", "linkedActionIds", "linkedDecisionIds", "linkedEvidenceWindowIds", "diagnostics"] as const) {
    validateStringArrayField(value, key, issues);
  }
  if (value.registryAction === "reject" && !isString(value.rejectionReason)) {
    issues.push(issue("rejectionReason", "required_for_reject", "rejectionReason is required when registryAction is reject."));
  }
  if ((value.registryAction === "map_existing" || value.registryAction === "add_alias") && !isString(value.existingConceptId)) {
    issues.push(issue("existingConceptId", "required_for_existing", "existingConceptId is required when mapping to an existing concept."));
  }
  if (!Array.isArray(value.supportingQuotes)) {
    issues.push(issue("supportingQuotes", "required_array", "supportingQuotes must be an array."));
  } else {
    value.supportingQuotes.forEach((quote, index) => {
      if (!isRecord(quote)) {
        issues.push(issue(`supportingQuotes[${index}]`, "required_object", "supporting quote must be an object."));
        return;
      }
      validateStringField(quote, "quote", issues, `supportingQuotes[${index}].quote`);
      validateSourceRefShape(quote.sourceRef, issues, `supportingQuotes[${index}].sourceRef`);
    });
  }
  validatePromptMetadata(value.prompt, issues, "prompt");
  if (!isRecord(value.retrieval)) {
    issues.push(issue("retrieval", "required_object", "retrieval must be an object."));
  } else {
    validateStringField(value.retrieval, "indexVersion", issues, "retrieval.indexVersion");
    validateStringArrayField(value.retrieval, "evidencePacketIds", issues, "retrieval.evidencePacketIds");
  }
  return issues.length === 0 ? { ok: true, value: value as SemanticConceptProposal, issues: [] } : { ok: false, issues };
}

export function isSemanticConceptProposal(value: unknown): value is SemanticConceptProposal {
  return validateSemanticConceptProposal(value).ok;
}

export function validateSemanticConceptProposalRun(value: unknown): SemanticValidationResult<SemanticConceptProposalRun> {
  const issues: SemanticValidationIssue[] = [];
  if (!isRecord(value)) return { ok: false, issues: [issue("$proposalRun", "required_object", "SemanticConceptProposalRun must be an object.")] };
  validateContractVersion(value, issues);
  validateStringField(value, "proposalRunId", issues);
  validateStringField(value, "indexVersion", issues);
  validateStringField(value, "registrySnapshotVersion", issues);
  validateStringField(value, "generatedAt", issues);
  if (!isRecord(value.sourceWindow)) {
    issues.push(issue("sourceWindow", "required_object", "sourceWindow must be an object."));
  } else {
    validateStringArrayField(value.sourceWindow, "meetingIds", issues, "sourceWindow.meetingIds");
  }
  validatePromptVersion(value.promptVersion, issues, "promptVersion");
  if (!Array.isArray(value.evidencePackets)) {
    issues.push(issue("evidencePackets", "required_array", "evidencePackets must be an array."));
  } else {
    value.evidencePackets.forEach((packet, index) => {
      const result = validateSemanticEvidencePacket(packet);
      if (!result.ok) issues.push(...result.issues.map((packetIssue) => ({ ...packetIssue, path: `evidencePackets[${index}].${packetIssue.path}` })));
    });
  }
  if (!Array.isArray(value.proposals)) {
    issues.push(issue("proposals", "required_array", "proposals must be an array."));
  } else {
    value.proposals.forEach((proposal, index) => {
      const result = validateSemanticConceptProposal(proposal);
      if (!result.ok) issues.push(...result.issues.map((proposalIssue) => ({ ...proposalIssue, path: `proposals[${index}].${proposalIssue.path}` })));
    });
  }
  validateStringArrayField(value, "diagnostics", issues);
  return issues.length === 0 ? { ok: true, value: value as SemanticConceptProposalRun, issues: [] } : { ok: false, issues };
}

export function isSemanticConceptProposalRun(value: unknown): value is SemanticConceptProposalRun {
  return validateSemanticConceptProposalRun(value).ok;
}

export function validateConceptRegistrySnapshot(value: unknown): SemanticValidationResult<ConceptRegistrySnapshot> {
  const issues: SemanticValidationIssue[] = [];
  if (!isRecord(value)) return { ok: false, issues: [issue("$registrySnapshot", "required_object", "ConceptRegistrySnapshot must be an object.")] };
  validateContractVersion(value, issues);
  validateStringField(value, "registrySnapshotVersion", issues);
  validateStringField(value, "generatedAt", issues);
  if (!Array.isArray(value.entries)) {
    issues.push(issue("entries", "required_array", "entries must be an array."));
  } else {
    value.entries.forEach((entry, index) => {
      if (!isRecord(entry)) {
        issues.push(issue(`entries[${index}]`, "required_object", "registry entry must be an object."));
        return;
      }
      validateContractVersion(entry, issues, `entries[${index}].contractVersion`);
      for (const key of ["conceptId", "canonicalLabel", "definition", "scope", "status", "createdAt", "updatedAt"] as const) {
        validateStringField(entry, key, issues, `entries[${index}].${key}`);
      }
      validateStringArrayField(entry, "aliases", issues, `entries[${index}].aliases`);
    });
  }
  if (!Array.isArray(value.aliases)) {
    issues.push(issue("aliases", "required_array", "aliases must be an array."));
  } else {
    value.aliases.forEach((alias, index) => {
      if (!isRecord(alias)) {
        issues.push(issue(`aliases[${index}]`, "required_object", "alias mapping must be an object."));
        return;
      }
      validateContractVersion(alias, issues, `aliases[${index}].contractVersion`);
      for (const key of ["alias", "normalizedAlias", "conceptId", "source"] as const) {
        validateStringField(alias, key, issues, `aliases[${index}].${key}`);
      }
      if (!isNumberInRange(alias.confidence)) issues.push(issue(`aliases[${index}].confidence`, "confidence_range", "confidence must be between 0 and 1."));
    });
  }
  return issues.length === 0 ? { ok: true, value: value as ConceptRegistrySnapshot, issues: [] } : { ok: false, issues };
}

export function isConceptRegistrySnapshot(value: unknown): value is ConceptRegistrySnapshot {
  return validateConceptRegistrySnapshot(value).ok;
}

export function assertValidSemanticEvidencePacket(value: unknown): asserts value is SemanticEvidencePacket {
  const result = validateSemanticEvidencePacket(value);
  if (!result.ok) throw new Error(`Invalid SemanticEvidencePacket: ${result.issues.map((item) => `${item.path} ${item.message}`).join("; ")}`);
}

export function assertValidSemanticConceptProposal(value: unknown): asserts value is SemanticConceptProposal {
  const result = validateSemanticConceptProposal(value);
  if (!result.ok) throw new Error(`Invalid SemanticConceptProposal: ${result.issues.map((item) => `${item.path} ${item.message}`).join("; ")}`);
}

export function assertValidSemanticConceptProposalRun(value: unknown): asserts value is SemanticConceptProposalRun {
  const result = validateSemanticConceptProposalRun(value);
  if (!result.ok) throw new Error(`Invalid SemanticConceptProposalRun: ${result.issues.map((item) => `${item.path} ${item.message}`).join("; ")}`);
}
