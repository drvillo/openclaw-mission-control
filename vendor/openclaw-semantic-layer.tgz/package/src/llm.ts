import type { DatabaseSync } from "node:sqlite";
import {
  SEMANTIC_CONTRACT_SCHEMA_IDS,
  SEMANTIC_CONTRACT_VERSION,
  semanticConceptProposalId,
  semanticContentHash,
  stableSemanticId,
  validateSemanticConceptProposal,
  validateSemanticConceptProposalRun,
  type ConceptRegistrySnapshot,
  type SemanticConceptProposal,
  type SemanticConceptProposalRun,
  type SemanticConceptScope,
  type SemanticEvidencePacket,
  type SemanticModelMetadata,
  type SemanticProviderAudit,
  type SemanticPromptMetadata,
  type SemanticPromptVersion,
  type SemanticSupportingQuote,
} from "./contracts.js";
import type { SemanticExtractionBundle } from "./extraction.js";
import { defaultEvidencePacketSeeds, buildSemanticEvidencePackets, type EvidencePacketSeed } from "./recall.js";
import { canonicalizeConceptAgainstRegistry, emptyConceptRegistrySnapshot } from "./registry.js";
import { assertConceptRetrievalIndexReady, type EmbeddingProvider } from "./store.js";
import { packetDomainSignals, scoreProposalDomainCoherence, sourceContextForEvidenceWindow, type PacketDomainSignals } from "./domain-coherence.js";

export const SEMANTIC_CONCEPT_SYNTHESIS_PROMPT_VERSION: SemanticPromptVersion = {
  promptId: "semantic-concept-synthesis",
  version: "2026-06-20.phase1-confidence-schema-audit",
  contractVersion: SEMANTIC_CONTRACT_VERSION,
};

export type EvidencePacketText = {
  packet: SemanticEvidencePacket;
  actions: Array<{ id: string; text: string }>;
  decisions: Array<{ id: string; text: string }>;
  evidence: Array<{ id: string; text: string; contextText?: string | null; contextLineStart?: number | null; contextLineEnd?: number | null }>;
  meetingContext: Array<{ id: string; title?: string | null; meetingDate?: string | null }>;
  domainSignals: PacketDomainSignals;
};

export type ConceptSynthesisInput = {
  proposalRunId: string;
  packets: EvidencePacketText[];
  registrySnapshot: ConceptRegistrySnapshot;
  prompt: SemanticPromptMetadata;
  maxProposals: number;
};

export type RawConceptSynthesis = {
  canonicalLabelSuggestion: string;
  definition: string;
  whyItMatters: string;
  scope: SemanticConceptScope;
  confidence: unknown;
  aliasesSuggested?: string[];
  supportingQuotes?: Array<{ quote: string; evidenceWindowId?: string | null }>;
  packetIds: string[];
  diagnostics?: string[];
  rawProviderRow?: unknown;
};

export type ConceptSynthesisProvider = {
  metadata: SemanticModelMetadata;
  lastSynthesisAudit?: SemanticProviderAudit | null;
  synthesize(input: ConceptSynthesisInput): Promise<RawConceptSynthesis[]> | RawConceptSynthesis[];
};

function unique<T>(values: T[]) {
  return [...new Set(values)];
}

function lookupText(bundles: SemanticExtractionBundle[]) {
  const actions = new Map<string, string>();
  const decisions = new Map<string, string>();
  const evidence = new Map<string, { text: string; sourceRef: SemanticExtractionBundle["note"]["sourceRef"] }>();
  const notes = new Map<string, SemanticExtractionBundle["note"]>();
  const evidenceWindows = new Map<string, SemanticExtractionBundle["evidenceWindows"][number]>();
  for (const bundle of bundles) {
    notes.set(bundle.note.semanticNoteId, bundle.note);
    for (const candidate of bundle.assertionCandidates) {
      if (candidate.kind === "decision") decisions.set(candidate.candidateId, candidate.text);
      else actions.set(candidate.candidateId, candidate.text);
    }
    for (const window of bundle.evidenceWindows) {
      evidence.set(window.evidenceWindowId, { text: window.text, sourceRef: window.sourceRef });
      evidenceWindows.set(window.evidenceWindowId, window);
    }
  }
  return { actions, decisions, evidence, evidenceWindows, notes };
}

function packetText(packet: SemanticEvidencePacket, bundles: SemanticExtractionBundle[]): EvidencePacketText {
  const lookup = lookupText(bundles);
  const text = {
    packet,
    actions: packet.includedActionIds.map((id) => ({ id, text: lookup.actions.get(id) ?? id })),
    decisions: packet.includedDecisionIds.map((id) => ({ id, text: lookup.decisions.get(id) ?? id })),
    evidence: packet.evidenceWindowIds.map((id) => {
      const window = lookup.evidenceWindows.get(id);
      const context = window ? sourceContextForEvidenceWindow(window, bundles, 10) : null;
      return {
        id,
        text: lookup.evidence.get(id)?.text ?? id,
        contextText: context?.contextText ?? null,
        contextLineStart: context?.contextLineStart ?? null,
        contextLineEnd: context?.contextLineEnd ?? null,
      };
    }),
    meetingContext: packet.meetingIds.map((id) => ({ id, title: lookup.notes.get(id)?.title ?? null, meetingDate: lookup.notes.get(id)?.meetingDate ?? null })),
    domainSignals: undefined as unknown as PacketDomainSignals,
  };
  return { ...text, domainSignals: packetDomainSignals(packet, text, bundles) };
}

function supportingQuotesFor(raw: RawConceptSynthesis, packetTexts: EvidencePacketText[], bundles: SemanticExtractionBundle[]): SemanticSupportingQuote[] {
  const lookup = lookupText(bundles);
  const allowedEvidenceIds = new Set(packetTexts.flatMap((packet) => packet.packet.evidenceWindowIds));
  return (raw.supportingQuotes ?? []).flatMap((rawQuote) => {
    const evidenceWindowId = typeof rawQuote.evidenceWindowId === "string" ? rawQuote.evidenceWindowId : null;
    if (!evidenceWindowId || !allowedEvidenceIds.has(evidenceWindowId)) return [];
    const evidence = lookup.evidence.get(evidenceWindowId);
    if (!evidence) return [];
    const quote = typeof rawQuote.quote === "string" ? rawQuote.quote.trim() : "";
    if (!quote) return [];
    return {
      quote,
      sourceRef: evidence.sourceRef,
      evidenceWindowId,
    };
  });
}

function parseConfidence(value: unknown): { ok: true; value: number; diagnostics: string[] } | { ok: false; diagnostics: string[]; suppress?: boolean } {
  if (value === undefined) return { ok: false, diagnostics: ["confidence_invalid_missing"] };
  if (value === null) return { ok: false, diagnostics: ["confidence_invalid_null"] };
  if (typeof value !== "number") return { ok: false, diagnostics: ["confidence_invalid_non_numeric"] };
  if (!Number.isFinite(value)) return { ok: false, diagnostics: ["confidence_invalid_non_finite"] };
  if (value < 0) return { ok: false, diagnostics: ["confidence_invalid_negative"] };
  if (value <= 0) return { ok: false, diagnostics: ["confidence_true_zero_suppressed"], suppress: true };
  if (value > 1 && value <= 100) return { ok: true, value: value / 100, diagnostics: ["confidence_normalized_from_percent"] };
  if (value > 1) return { ok: false, diagnostics: ["confidence_invalid_above_100_percent"] };
  return { ok: true, value, diagnostics: [] };
}

const GENERIC_LABEL_TERMS = new Set([
  "action",
  "actions",
  "concept",
  "discussion",
  "follow",
  "generic",
  "meeting",
  "meetings",
  "next",
  "note",
  "notes",
  "review",
  "step",
  "steps",
  "team",
  "theme",
  "update",
  "work",
]);

function labelTokens(label: string) {
  return label.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/gu, "").match(/[a-z0-9]{3,}/gu) ?? [];
}

function isGenericOrEmptyLabel(label: string) {
  const trimmed = label.trim();
  if (!trimmed) return true;
  const tokens = labelTokens(trimmed).filter((token) => !GENERIC_LABEL_TERMS.has(token));
  if (tokens.length === 0) return true;
  if (/^(generic|misc|other|meeting|discussion|follow[-\s]?up|next steps?)$/iu.test(trimmed)) return true;
  return tokens.length === 1 && trimmed.split(/\s+/u).length <= 2;
}

function packetSetKey(packetIds: string[]) {
  return [...new Set(packetIds)].sort().join("|");
}

export type SemanticProposalRunOptions = {
  db?: DatabaseSync | null;
  indexVersion?: string;
  registrySnapshot?: ConceptRegistrySnapshot;
  provider?: ConceptSynthesisProvider;
  embeddingProvider?: EmbeddingProvider;
  seeds?: EvidencePacketSeed[];
  generatedAt?: string;
  maxPackets?: number;
  maxProposals?: number;
  dateRange?: { from?: string | null; to?: string | null } | null;
  filter?: string | null;
};

function promptMetadata(provider: ConceptSynthesisProvider): SemanticPromptMetadata {
  return {
    promptVersion: SEMANTIC_CONCEPT_SYNTHESIS_PROMPT_VERSION,
    model: provider.metadata,
    outputSchemaId: SEMANTIC_CONTRACT_SCHEMA_IDS.conceptSynthesisOutput,
  };
}

function sourceWindow(bundles: SemanticExtractionBundle[], options: SemanticProposalRunOptions) {
  return {
    meetingIds: bundles.map((bundle) => bundle.note.semanticNoteId).sort(),
    dateRange: options.dateRange ?? null,
    filter: options.filter ?? null,
  };
}

export async function generateSemanticConceptProposalRun(bundles: SemanticExtractionBundle[], options: SemanticProposalRunOptions = {}): Promise<SemanticConceptProposalRun> {
  const generatedAt = options.generatedAt ?? new Date().toISOString();
  const registrySnapshot = options.registrySnapshot ?? emptyConceptRegistrySnapshot(generatedAt);
  if (!options.provider) throw new Error("generateSemanticConceptProposalRun requires an explicit ConceptSynthesisProvider.");
  const provider = options.provider;
  if (options.db) assertConceptRetrievalIndexReady(options.db);
  const indexVersion = options.indexVersion ?? stableSemanticId("index-version", bundles.map((bundle) => bundle.note.provenance.contentHash).join("|"));
  const seeds = (options.seeds ?? defaultEvidencePacketSeeds(bundles)).slice(0, options.maxPackets ?? 20);
  const evidencePackets = await buildSemanticEvidencePackets(options.db ?? null, bundles, seeds, {
    indexVersion,
    generatedAt,
    limit: 12,
    provider: options.embeddingProvider,
    registrySnapshot,
    includeRegistryContext: true,
  });
  const proposalRunId = stableSemanticId("proposal-run", { generatedAt, indexVersion, registrySnapshotVersion: registrySnapshot.registrySnapshotVersion, packets: evidencePackets.map((packet) => packet.packetId) });
  const packetTexts = evidencePackets.map((packet) => packetText(packet, bundles));
  const prompt = {
    ...promptMetadata(provider),
    inputHash: semanticContentHash({ proposalRunId, indexVersion, registrySnapshotVersion: registrySnapshot.registrySnapshotVersion, packets: packetTexts, maxProposals: options.maxProposals ?? 12 }),
  };
  const rawProposals = await provider.synthesize({ proposalRunId, packets: packetTexts, registrySnapshot, prompt, maxProposals: options.maxProposals ?? 12 });
  const proposals: SemanticConceptProposal[] = [];
  const diagnostics: string[] = [];
  const droppedProposals: string[] = [];
  const packetIdsInRun = new Set(packetTexts.map((packet) => packet.packet.packetId));
  const eligible: Array<{ raw: RawConceptSynthesis; confidence: number; rawDiagnostics: string[]; relevantPackets: EvidencePacketText[]; linkedActionIds: string[]; linkedDecisionIds: string[]; linkedEvidenceWindowIds: string[]; supportingQuotes: SemanticSupportingQuote[] }> = [];

  for (const raw of rawProposals) {
    const rawDiagnostics = [...(raw.diagnostics ?? [])];
    const confidence = parseConfidence(raw.confidence);
    rawDiagnostics.push(...confidence.diagnostics);
    if (!confidence.ok) {
      const reason = `${confidence.suppress ? "suppressed" : "dropped"} confidence-invalid proposal ${String(raw.canonicalLabelSuggestion ?? "unknown")}: ${confidence.diagnostics.join(",")}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    if (isGenericOrEmptyLabel(raw.canonicalLabelSuggestion)) {
      const reason = `dropped generic-label proposal ${String(raw.canonicalLabelSuggestion ?? "unknown")}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    const unknownPacketIds = raw.packetIds.filter((packetId) => !packetIdsInRun.has(packetId));
    if (unknownPacketIds.length > 0) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: unknown packetIds ${unknownPacketIds.join(",")}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    const relevantPackets = packetTexts.filter((packet) => raw.packetIds.includes(packet.packet.packetId));
    const coherence = scoreProposalDomainCoherence({
      label: raw.canonicalLabelSuggestion,
      definition: raw.definition,
      whyItMatters: raw.whyItMatters,
      packetSignals: relevantPackets.map((packet) => packet.domainSignals),
    });
    rawDiagnostics.push(...coherence.diagnostics);
    if (coherence.suppressRecommended) {
      const reason = `suppressed proposal ${raw.canonicalLabelSuggestion}: ${coherence.diagnostics.join(",")}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    const adjustedConfidence = Math.max(0.01, confidence.value - coherence.confidencePenalty);
    const linkedActionIds = unique(relevantPackets.flatMap((packet) => packet.packet.includedActionIds)).sort();
    const linkedDecisionIds = unique(relevantPackets.flatMap((packet) => packet.packet.includedDecisionIds)).sort();
    const linkedEvidenceWindowIds = unique(relevantPackets.flatMap((packet) => packet.packet.evidenceWindowIds)).sort();
    const rawSupportingQuotes = raw.supportingQuotes?.filter((quote) => typeof quote.quote === "string" && quote.quote.trim() && quote.evidenceWindowId) ?? [];
    const allowedEvidenceWindowIds = new Set(linkedEvidenceWindowIds);
    const invalidQuoteEvidenceWindowIds = rawSupportingQuotes
      .map((quote) => quote.evidenceWindowId)
      .filter((evidenceWindowId): evidenceWindowId is string => typeof evidenceWindowId === "string" && !allowedEvidenceWindowIds.has(evidenceWindowId));
    const supportingQuotes = supportingQuotesFor(raw, relevantPackets, bundles);
    if (linkedActionIds.length + linkedDecisionIds.length === 0) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: no linked action or decision IDs`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    if (linkedEvidenceWindowIds.length === 0) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: no linked evidence windows`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    if (invalidQuoteEvidenceWindowIds.length > 0) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: supporting quote evidenceWindowIds outside selected packets ${invalidQuoteEvidenceWindowIds.join(",")}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    if (rawSupportingQuotes.length === 0 || supportingQuotes.length === 0) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: no supporting quotes`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    if (supportingQuotes.length !== rawSupportingQuotes.length) {
      const reason = `dropped proposal ${raw.canonicalLabelSuggestion}: unresolved supporting quote evidenceWindowIds`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
      continue;
    }
    eligible.push({ raw, confidence: adjustedConfidence, rawDiagnostics, relevantPackets, linkedActionIds, linkedDecisionIds, linkedEvidenceWindowIds, supportingQuotes });
  }

  const byPacketSet = new Map<string, typeof eligible[number]>();
  for (const item of eligible) {
    const key = packetSetKey(item.raw.packetIds);
    const existing = byPacketSet.get(key);
    if (!existing || item.confidence > existing.confidence || (item.confidence === existing.confidence && item.supportingQuotes.length > existing.supportingQuotes.length)) {
      if (existing) {
        const reason = `dropped duplicate packet-set proposal ${existing.raw.canonicalLabelSuggestion}: superseded by ${item.raw.canonicalLabelSuggestion}`;
        diagnostics.push(reason);
        droppedProposals.push(reason);
      }
      byPacketSet.set(key, item);
    } else {
      const reason = `dropped duplicate packet-set proposal ${item.raw.canonicalLabelSuggestion}: weaker than ${existing.raw.canonicalLabelSuggestion}`;
      diagnostics.push(reason);
      droppedProposals.push(reason);
    }
  }

  for (const item of byPacketSet.values()) {
    const { raw, confidence, rawDiagnostics, linkedActionIds, linkedDecisionIds, linkedEvidenceWindowIds, supportingQuotes } = item;
    const canonical = canonicalizeConceptAgainstRegistry({ label: raw.canonicalLabelSuggestion, definition: raw.definition, aliases: raw.aliasesSuggested, scope: raw.scope }, registrySnapshot);
    const base = {
      proposalRunId,
      canonicalLabelSuggestion: raw.canonicalLabelSuggestion,
      scope: raw.scope,
      linkedActionIds,
      linkedDecisionIds,
      linkedEvidenceWindowIds,
    };
    const proposal: SemanticConceptProposal = {
      contractVersion: SEMANTIC_CONTRACT_VERSION,
      proposalId: semanticConceptProposalId(base),
      ...base,
      definition: raw.definition,
      whyItMatters: raw.whyItMatters,
      confidence,
      registryAction: canonical.registryAction,
      existingConceptId: canonical.existingConceptId ?? null,
      aliasesSuggested: canonical.aliasesSuggested,
      supportingQuotes,
      rejectionReason: canonical.registryAction === "reject" ? canonical.diagnostics.join("; ") : null,
      prompt,
      retrieval: { indexVersion, evidencePacketIds: raw.packetIds },
      diagnostics: [...rawDiagnostics, ...canonical.diagnostics],
      rawJson: {
        providerRow: raw.rawProviderRow ?? null,
        parseDiagnostics: rawDiagnostics,
      },
    };
    const validation = validateSemanticConceptProposal(proposal);
    if (validation.ok) proposals.push(proposal);
    else diagnostics.push(`dropped invalid proposal ${raw.canonicalLabelSuggestion}: ${validation.issues.map((issue) => `${issue.path}:${issue.code}`).join(", ")}`);
  }

  const run: SemanticConceptProposalRun = {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    proposalRunId,
    sourceWindow: sourceWindow(bundles, options),
    indexVersion,
    registrySnapshotVersion: registrySnapshot.registrySnapshotVersion,
    promptVersion: SEMANTIC_CONCEPT_SYNTHESIS_PROMPT_VERSION,
    generatedAt,
    evidencePackets,
    proposals: proposals.sort((left, right) => right.confidence - left.confidence || left.canonicalLabelSuggestion.localeCompare(right.canonicalLabelSuggestion)),
    diagnostics,
    audit: {
      provider: provider.lastSynthesisAudit ?? {
        provider: provider.metadata.provider,
        model: provider.metadata.model,
        modelMetadata: provider.metadata,
        promptVersion: SEMANTIC_CONCEPT_SYNTHESIS_PROMPT_VERSION,
        outputSchemaId: prompt.outputSchemaId,
        requestHash: prompt.inputHash ?? null,
        parseDiagnostics: [],
      },
      droppedProposals,
    },
  };
  const validation = validateSemanticConceptProposalRun(run);
  if (!validation.ok) throw new Error(`Invalid semantic proposal run: ${validation.issues.map((issue) => `${issue.path} ${issue.message}`).join("; ")}`);
  return run;
}
