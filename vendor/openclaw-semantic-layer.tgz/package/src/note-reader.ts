import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync, realpathSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";
import type { SemanticSourceRef } from "./contracts.js";

export const SEMANTIC_NOTE_PARSER_VERSION = "semantic-note-reader/v1";

export type FrontmatterValue = string | string[];

export type SemanticParseDiagnostic = {
  severity: "warning" | "error";
  code: string;
  message: string;
  recoverable: true;
  line?: number | null;
};

export type SemanticMeetingNoteMetadata = {
  frontmatter: Record<string, FrontmatterValue>;
  recordingId?: string | null;
  meetingAssistantRunId?: string | null;
  source?: string | null;
};

export type SemanticMeetingNote = {
  semanticNoteId: string;
  sourceRef: SemanticSourceRef;
  title: string | null;
  meetingDate: string | null;
  rawMarkdown: string;
  sections: Record<string, string>;
  metadata: SemanticMeetingNoteMetadata;
  provenance: {
    contentHash: string;
    parsedAt: string | null;
    parserVersion: string;
  };
  diagnostics: SemanticParseDiagnostic[];
};

export type ParseSemanticMeetingNoteOptions = {
  sourceSystem?: string;
  canonicalSourcePath?: string | null;
  parsedAt?: string | null;
};

export type ParseSemanticMeetingNoteFileOptions = ParseSemanticMeetingNoteOptions & {
  allowedRoots: string[];
};

export type ExportSemanticNotesJsonlOptions = ParseSemanticMeetingNoteFileOptions & {
  outPath?: string | null;
};

type ParsedFrontmatter = {
  values: Map<string, FrontmatterValue>;
  bodyStartIndex: number;
  diagnostics: SemanticParseDiagnostic[];
};

function sha256Hex(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function stableId(prefix: string, value: string) {
  return `${prefix}:${sha256Hex(value).slice(0, 32)}`;
}

function stripWrappedQuotes(value: string) {
  return value.replace(/^['"](.*)['"]$/u, "$1").trim();
}

function toRecord(map: Map<string, FrontmatterValue>) {
  return Object.fromEntries(map.entries());
}

function getString(map: Map<string, FrontmatterValue>, key: string) {
  const value = map.get(key);
  return typeof value === "string" && value.length > 0 ? value : null;
}

function diagnostic(code: string, message: string, line?: number | null): SemanticParseDiagnostic {
  return { severity: "warning", code, message, recoverable: true, line };
}

export function parseFrontmatter(markdown: string): ParsedFrontmatter {
  if (!markdown.startsWith("---")) {
    return { values: new Map(), bodyStartIndex: 0, diagnostics: [] };
  }

  const closingMatch = markdown.match(/^---\s*\r?\n([\s\S]*?)\r?\n---\s*(?:\r?\n|$)/u);
  if (!closingMatch || closingMatch.index !== 0) {
    return {
      values: new Map(),
      bodyStartIndex: 0,
      diagnostics: [diagnostic("frontmatter_unclosed", "Frontmatter starts with --- but no closing delimiter was found.", 1)],
    };
  }

  const values = new Map<string, FrontmatterValue>();
  let currentArrayKey: string | null = null;

  for (const [index, rawLine] of closingMatch[1].split(/\r?\n/u).entries()) {
    const keyMatch = rawLine.match(/^([A-Za-z0-9_-]+):\s*(.*)$/u);
    if (keyMatch) {
      const [, key, rawValue] = keyMatch;
      const value = rawValue.trim();
      if (!value) {
        values.set(key, []);
        currentArrayKey = key;
      } else {
        values.set(key, stripWrappedQuotes(value));
        currentArrayKey = null;
      }
      continue;
    }

    const arrayMatch = rawLine.match(/^\s*-\s*(.*)$/u);
    if (arrayMatch && currentArrayKey) {
      const current = values.get(currentArrayKey);
      if (Array.isArray(current)) {
        current.push(stripWrappedQuotes(arrayMatch[1].trim()));
      }
      continue;
    }

    if (rawLine.trim()) {
      currentArrayKey = null;
      values.set(`__unparsed_line_${index + 1}`, rawLine.trim());
    }
  }

  return {
    values,
    bodyStartIndex: closingMatch[0].length,
    diagnostics: [],
  };
}

export function parseBulletMetadata(text: string) {
  const metadata = new Map<string, string>();
  for (const line of text.split(/\r?\n/u)) {
    const match = line.match(/^-\s*([A-Za-z0-9_ -]+):\s*(.*)$/u);
    if (match) {
      metadata.set(match[1].trim().toLowerCase().replace(/\s+/gu, "_"), match[2].trim());
    }
  }
  return metadata;
}

function slugifyHeading(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[`*_~[\]().,!?:;'"/\\]+/gu, "")
    .replace(/&/gu, "and")
    .replace(/\s+/gu, "-")
    .replace(/^-+|-+$/gu, "") || "untitled-section";
}

function stripLeadingHeading(section: string) {
  return section.replace(/^#{1,6}\s+.*(?:\r?\n|$)/u, "").trim();
}

function lineNumberAt(markdown: string, index: number) {
  return markdown.slice(0, index).split(/\r?\n/u).length;
}

export function parseSections(markdown: string, bodyStartIndex = 0) {
  const sections: Record<string, string> = {};
  const diagnostics: SemanticParseDiagnostic[] = [];
  const managedPattern = /<!--\s*FATHOM:SECTION\s+([A-Za-z0-9_-]+):start\s*-->([\s\S]*?)<!--\s*FATHOM:SECTION\s+\1:end\s*-->/gu;
  const managedRanges: Array<{ start: number; end: number }> = [];

  for (const match of markdown.matchAll(managedPattern)) {
    const sectionName = match[1];
    const key = slugifyHeading(sectionName);
    sections[key] = stripLeadingHeading(match[2]);
    managedRanges.push({ start: match.index, end: match.index + match[0].length });
  }

  for (const startMatch of markdown.matchAll(/<!--\s*FATHOM:SECTION\s+([A-Za-z0-9_-]+):start\s*-->/gu)) {
    const name = startMatch[1];
    const closePattern = new RegExp(`<!--\\s*FATHOM:SECTION\\s+${name}:end\\s*-->`, "u");
    const rest = markdown.slice(startMatch.index + startMatch[0].length);
    if (!closePattern.test(rest)) {
      diagnostics.push(
        diagnostic(
          "managed_section_unclosed",
          `Managed section '${name}' starts but no matching end marker was found.`,
          lineNumberAt(markdown, startMatch.index),
        ),
      );
    }
  }

  const body = markdown.slice(bodyStartIndex);
  const headings = [...body.matchAll(/^(#{1,6})\s+(.+?)\s*$/gmu)].filter((match) => {
    const absoluteIndex = bodyStartIndex + match.index;
    return !managedRanges.some((range) => absoluteIndex >= range.start && absoluteIndex < range.end);
  });

  for (const [index, match] of headings.entries()) {
    const level = match[1].length;
    const start = bodyStartIndex + match.index + match[0].length;
    let end = markdown.length;
    for (const next of headings.slice(index + 1)) {
      if (next[1].length <= level) {
        end = bodyStartIndex + next.index;
        break;
      }
    }
    const key = slugifyHeading(match[2]);
    if (!(key in sections)) {
      sections[key] = markdown.slice(start, end).trim();
    }
  }

  return { sections, diagnostics };
}

function resolveMetadata(frontmatter: Map<string, FrontmatterValue>, sections: Record<string, string>) {
  const metadata = parseBulletMetadata(sections.metadata ?? "");
  const provenance = parseBulletMetadata(sections.provenance ?? sections["processing-provenance"] ?? "");
  const meetingDate = getString(frontmatter, "meeting_date") ?? metadata.get("meeting_date") ?? null;
  const title =
    getString(frontmatter, "meeting_title") ??
    getString(frontmatter, "title") ??
    metadata.get("meeting_title") ??
    null;
  return {
    title,
    meetingDate,
    recordingId: getString(frontmatter, "recording_id") ?? metadata.get("recording_id") ?? provenance.get("recording_id") ?? null,
    meetingAssistantRunId: provenance.get("run_id") ?? null,
    source: getString(frontmatter, "source") ?? metadata.get("source") ?? null,
  };
}

function titleFromHeading(markdown: string) {
  return markdown.match(/^#\s+(.+)$/mu)?.[1]?.trim() ?? null;
}

export function parseSemanticMeetingNote(markdown: string, options: ParseSemanticMeetingNoteOptions = {}): SemanticMeetingNote {
  const sourceSystem = options.sourceSystem ?? "obsidian";
  const contentHash = sha256Hex(markdown);
  const frontmatter = parseFrontmatter(markdown);
  const parsedSections = parseSections(markdown, frontmatter.bodyStartIndex);
  const metadata = resolveMetadata(frontmatter.values, parsedSections.sections);
  const sourceIdentity = options.canonicalSourcePath ?? contentHash;
  const semanticNoteId = stableId("semantic-note", `${sourceSystem}\0${sourceIdentity}`);

  return {
    semanticNoteId,
    sourceRef: {
      sourceSystem,
      sourceType: "meeting_note",
      sourceId: semanticNoteId,
      canonicalSourcePath: options.canonicalSourcePath ?? null,
      contentHash,
      recordingId: metadata.recordingId,
      meetingAssistantRunId: metadata.meetingAssistantRunId,
      missionControlId: null,
    },
    title: metadata.title ?? titleFromHeading(markdown),
    meetingDate: metadata.meetingDate,
    rawMarkdown: markdown,
    sections: parsedSections.sections,
    metadata: {
      frontmatter: toRecord(frontmatter.values),
      recordingId: metadata.recordingId,
      meetingAssistantRunId: metadata.meetingAssistantRunId,
      source: metadata.source,
    },
    provenance: {
      contentHash,
      parsedAt: options.parsedAt ?? null,
      parserVersion: SEMANTIC_NOTE_PARSER_VERSION,
    },
    diagnostics: [...frontmatter.diagnostics, ...parsedSections.diagnostics],
  };
}

function ensureInsideRoot(filePath: string, rootPath: string) {
  const relative = path.relative(rootPath, filePath);
  return relative === "" || (!!relative && !relative.startsWith("..") && !path.isAbsolute(relative));
}

export function resolveAllowedMarkdownPath(filePath: string, allowedRoots: string[]) {
  if (allowedRoots.length === 0) {
    throw new Error("At least one allowed root is required to read semantic notes.");
  }

  const canonicalFilePath = realpathSync(filePath);
  const canonicalRoots = allowedRoots.map((root) => realpathSync(root));
  if (!canonicalRoots.some((root) => ensureInsideRoot(canonicalFilePath, root))) {
    throw new Error(`Refusing to read '${filePath}' because it is outside the configured semantic note roots.`);
  }
  if (!canonicalFilePath.toLowerCase().endsWith(".md")) {
    throw new Error(`Refusing to read '${filePath}' because semantic note inputs must be Markdown files.`);
  }
  return canonicalFilePath;
}

export function parseSemanticMeetingNoteFile(filePath: string, options: ParseSemanticMeetingNoteFileOptions): SemanticMeetingNote {
  const canonicalSourcePath = resolveAllowedMarkdownPath(filePath, options.allowedRoots);
  const rawMarkdown = readFileSync(canonicalSourcePath, "utf8");
  return parseSemanticMeetingNote(rawMarkdown, { ...options, canonicalSourcePath });
}

export function discoverMarkdownNotes(roots: string[]) {
  const discovered: string[] = [];
  const canonicalRoots = roots.map((root) => realpathSync(root));

  function visit(entryPath: string, root: string) {
    const canonicalPath = realpathSync(entryPath);
    if (!ensureInsideRoot(canonicalPath, root)) {
      return;
    }

    const stat = statSync(canonicalPath);
    if (stat.isDirectory()) {
      for (const child of readdirSync(canonicalPath)) {
        if (child === "node_modules" || child === ".git") {
          continue;
        }
        visit(path.join(canonicalPath, child), root);
      }
      return;
    }

    if (stat.isFile() && canonicalPath.toLowerCase().endsWith(".md")) {
      discovered.push(canonicalPath);
    }
  }

  for (const root of canonicalRoots) {
    if (!existsSync(root)) {
      throw new Error(`Semantic note root does not exist: ${root}`);
    }
    visit(root, root);
  }

  return [...new Set(discovered)].sort();
}

export function collectMarkdownInputs(inputs: string[], allowedRoots: string[]) {
  const paths: string[] = [];
  const canonicalAllowedRoots = allowedRoots.map((root) => realpathSync(root));
  for (const input of inputs) {
    const canonicalInput = realpathSync(input);
    const stat = statSync(canonicalInput);
    if (stat.isDirectory()) {
      if (!canonicalAllowedRoots.some((root) => ensureInsideRoot(canonicalInput, root))) {
        throw new Error(`Refusing to discover '${input}' because it is outside the configured semantic note roots.`);
      }
      paths.push(...discoverMarkdownNotes([canonicalInput]));
    } else if (stat.isFile()) {
      paths.push(resolveAllowedMarkdownPath(canonicalInput, allowedRoots));
    }
  }
  return [...new Set(paths)].sort();
}

export function exportSemanticMeetingNotesJsonl(inputPaths: string[], options: ExportSemanticNotesJsonlOptions) {
  const records = collectMarkdownInputs(inputPaths, options.allowedRoots).map((inputPath) => parseSemanticMeetingNoteFile(inputPath, options));
  const jsonl = `${records.map((record) => JSON.stringify(record)).join("\n")}${records.length > 0 ? "\n" : ""}`;
  if (options.outPath) {
    writeFileSync(options.outPath, jsonl, "utf8");
  }
  return { records, jsonl };
}
