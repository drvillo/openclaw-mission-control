import {
  SEMANTIC_CONTRACT_VERSION,
  semanticContentHash,
  stableSemanticId,
  type ConceptAliasMapping,
  type ConceptRegistryEntry,
  type ConceptRegistrySnapshot,
  type SemanticConceptProposal,
  type SemanticConceptScope,
  type SemanticRegistryAction,
  type SemanticSourceRef,
} from "./contracts.js";

const STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "into", "is", "it", "of", "on", "or", "the", "to", "with",
  "action", "actions", "decision", "decisions", "meeting", "next", "review", "update", "work",
]);

export type RegistryCanonicalizationDecision = {
  registryAction: SemanticRegistryAction;
  existingConceptId?: string | null;
  aliasesSuggested: string[];
  confidence: number;
  diagnostics: string[];
};

export type CanonicalizationInput = {
  label: string;
  definition?: string | null;
  aliases?: string[];
  scope?: SemanticConceptScope | null;
  minMapScore?: number;
  minAliasScore?: number;
};

export function normalizeConceptLabel(value: string) {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/gu, "")
    .replace(/[^a-z0-9]+/gu, " ")
    .replace(/\s+/gu, " ")
    .trim();
}

function tokens(value: string) {
  return new Set(normalizeConceptLabel(value).split(" ").filter((token) => token.length > 2 && !STOP_WORDS.has(token)));
}

function tokenSimilarity(left: string, right: string) {
  const leftTokens = tokens(left);
  const rightTokens = tokens(right);
  if (leftTokens.size === 0 || rightTokens.size === 0) return 0;
  const overlap = [...leftTokens].filter((token) => rightTokens.has(token)).length;
  return overlap / Math.max(leftTokens.size, rightTokens.size);
}

export function buildConceptRegistrySnapshot(
  entries: Array<Omit<ConceptRegistryEntry, "contractVersion" | "createdAt" | "updatedAt" | "aliases" | "sourceRefs"> & Partial<Pick<ConceptRegistryEntry, "createdAt" | "updatedAt" | "aliases" | "sourceRefs">>>,
  options: { generatedAt?: string; snapshotVersionSeed?: string } = {},
): ConceptRegistrySnapshot {
  const generatedAt = options.generatedAt ?? new Date().toISOString();
  const normalizedEntries: ConceptRegistryEntry[] = entries.map((entry) => ({
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    conceptId: entry.conceptId,
    canonicalLabel: entry.canonicalLabel,
    definition: entry.definition,
    scope: entry.scope,
    aliases: [...new Set(entry.aliases ?? [])].sort((left, right) => left.localeCompare(right)),
    status: entry.status,
    createdAt: entry.createdAt ?? generatedAt,
    updatedAt: entry.updatedAt ?? generatedAt,
    sourceRefs: entry.sourceRefs ?? [],
  }));
  const aliases: ConceptAliasMapping[] = [];
  for (const entry of normalizedEntries) {
    for (const alias of [entry.canonicalLabel, ...entry.aliases]) {
      aliases.push({
        contractVersion: SEMANTIC_CONTRACT_VERSION,
        alias,
        normalizedAlias: normalizeConceptLabel(alias),
        conceptId: entry.conceptId,
        source: alias === entry.canonicalLabel ? "registry" : "manual",
        confidence: 1,
      });
    }
  }
  const registrySnapshotVersion = stableSemanticId("registry-snapshot", options.snapshotVersionSeed ?? semanticContentHash({ entries: normalizedEntries, aliases }));
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    registrySnapshotVersion,
    generatedAt,
    entries: normalizedEntries.sort((left, right) => left.canonicalLabel.localeCompare(right.canonicalLabel)),
    aliases: aliases.sort((left, right) => left.normalizedAlias.localeCompare(right.normalizedAlias)),
  };
}

export function emptyConceptRegistrySnapshot(generatedAt = new Date().toISOString()): ConceptRegistrySnapshot {
  return buildConceptRegistrySnapshot([], { generatedAt, snapshotVersionSeed: "empty" });
}

export function conceptRegistryEntryFromProposal(
  proposal: SemanticConceptProposal,
  options: { conceptId?: string; now?: string; sourceRefs?: SemanticSourceRef[] } = {},
): ConceptRegistryEntry {
  const now = options.now ?? new Date().toISOString();
  return {
    contractVersion: SEMANTIC_CONTRACT_VERSION,
    conceptId: options.conceptId ?? stableSemanticId("concept", normalizeConceptLabel(proposal.canonicalLabelSuggestion)),
    canonicalLabel: proposal.canonicalLabelSuggestion,
    definition: proposal.definition,
    scope: proposal.scope,
    aliases: proposal.aliasesSuggested,
    status: "candidate",
    createdAt: now,
    updatedAt: now,
    sourceRefs: options.sourceRefs ?? proposal.supportingQuotes.map((quote) => quote.sourceRef),
  };
}

export function canonicalizeConceptAgainstRegistry(input: CanonicalizationInput, snapshot: ConceptRegistrySnapshot): RegistryCanonicalizationDecision {
  const normalizedLabel = normalizeConceptLabel(input.label);
  const aliases = [...new Set((input.aliases ?? []).map((alias) => alias.trim()).filter(Boolean))];
  const diagnostics: string[] = [];
  if (!normalizedLabel || normalizedLabel.split(" ").length < 2) {
    return { registryAction: "reject", aliasesSuggested: aliases, confidence: 0.2, diagnostics: ["label is too short or generic"] };
  }
  const activeEntries = snapshot.entries.filter((entry) => entry.status === "accepted" || entry.status === "candidate");
  const activeConceptIds = new Set(activeEntries.map((entry) => entry.conceptId));
  const exactAlias = snapshot.aliases.find((alias) => activeConceptIds.has(alias.conceptId) && alias.normalizedAlias === normalizedLabel);
  if (exactAlias) {
    return { registryAction: "map_existing", existingConceptId: exactAlias.conceptId, aliasesSuggested: aliases, confidence: 0.98, diagnostics };
  }
  let best: { entry: ConceptRegistryEntry; score: number } | null = null;
  for (const entry of activeEntries) {
    const values = [entry.canonicalLabel, entry.definition, ...entry.aliases];
    const score = Math.max(...values.map((value) => tokenSimilarity(input.label, value)));
    if (!best || score > best.score) best = { entry, score };
  }
  const minMapScore = input.minMapScore ?? 0.82;
  const minAliasScore = input.minAliasScore ?? 0.62;
  if (best && best.score >= minMapScore) {
    return { registryAction: "map_existing", existingConceptId: best.entry.conceptId, aliasesSuggested: aliases, confidence: best.score, diagnostics: [`matched existing concept ${best.entry.conceptId}`] };
  }
  if (best && best.score >= minAliasScore) {
    return { registryAction: "add_alias", existingConceptId: best.entry.conceptId, aliasesSuggested: [...new Set([input.label, ...aliases])], confidence: best.score, diagnostics: [`label looks like an alias for ${best.entry.conceptId}`] };
  }
  diagnostics.push(activeEntries.length === 0 ? "registry is empty" : "no sufficiently similar registry entry found");
  return { registryAction: "propose_new", aliasesSuggested: aliases, confidence: Math.max(0.55, best?.score ?? 0.55), diagnostics };
}
