import type { SemanticExtractionBundle } from "./extraction.js";
import { generateConceptProposalRun, type ConceptProposalThresholds, type SemanticConceptCandidate, type SemanticProposalRun } from "./concepts.js";

export type GoldenConcept = {
  label: string;
  requiredTextIncludes: string[];
};

export type CalibrationSpec = {
  goldenConcepts: GoldenConcept[];
  negativeTextIncludes?: string[];
};

export type CalibrationReport = {
  generatedAt: string;
  degraded: boolean;
  providerMode: "legacy-local";
  sweeps: Array<{
    thresholds: ConceptProposalThresholds;
    proposalCount: number;
    truePositiveCount: number;
    falsePositiveCount: number;
    precisionAtK: number;
    coverage: number;
    duplicateRate: number;
    falsePositiveSamples: string[];
    matchedGoldenLabels: string[];
    proposalRun: SemanticProposalRun;
  }>;
  recommendation: {
    thresholds: ConceptProposalThresholds;
    reason: string;
  };
};

function memberTexts(proposal: SemanticConceptCandidate, bundles: SemanticExtractionBundle[]) {
  const candidateById = new Map(bundles.flatMap((bundle) => bundle.assertionCandidates.map((candidate) => [candidate.candidateId, candidate] as const)));
  return proposal.memberAssertionCandidateIds.map((candidateId) => candidateById.get(candidateId)?.text ?? "");
}

function proposalMatchesGolden(proposal: SemanticConceptCandidate, golden: GoldenConcept, bundles: SemanticExtractionBundle[]) {
  const texts = memberTexts(proposal, bundles).join("\n").toLowerCase();
  return golden.requiredTextIncludes.every((needle) => texts.includes(needle.toLowerCase()));
}

function proposalContainsNegative(proposal: SemanticConceptCandidate, negativeTextIncludes: string[], bundles: SemanticExtractionBundle[]) {
  const texts = memberTexts(proposal, bundles).join("\n").toLowerCase();
  return negativeTextIncludes.some((needle) => texts.includes(needle.toLowerCase()));
}

function duplicateRate(proposals: SemanticConceptCandidate[]) {
  if (proposals.length <= 1) return 0;
  const labels = proposals.map((proposal) => proposal.labelSuggestion.toLowerCase());
  return 1 - new Set(labels).size / labels.length;
}

export function calibrateConceptProposals(bundles: SemanticExtractionBundle[], spec: CalibrationSpec): CalibrationReport {
  const thresholdSweep: ConceptProposalThresholds[] = [
    { minCandidateCount: 2, minMeetingCount: 2, similarityThreshold: 0.28, minEvidenceWindowCount: 2, maxProposals: 20 },
    { minCandidateCount: 2, minMeetingCount: 2, similarityThreshold: 0.34, minEvidenceWindowCount: 2, maxProposals: 20 },
    { minCandidateCount: 3, minMeetingCount: 2, similarityThreshold: 0.28, minEvidenceWindowCount: 3, maxProposals: 20 },
    { minCandidateCount: 2, minMeetingCount: 3, similarityThreshold: 0.28, minEvidenceWindowCount: 2, maxProposals: 20 },
  ];

  const sweeps = thresholdSweep.map((thresholds) => {
    const proposalRun = generateConceptProposalRun(bundles, thresholds);
    const matchedGoldenLabels = new Set<string>();
    const falsePositiveSamples: string[] = [];
    let truePositiveCount = 0;
    let falsePositiveCount = 0;

    for (const proposal of proposalRun.candidates) {
      const match = spec.goldenConcepts.find((golden) => proposalMatchesGolden(proposal, golden, bundles));
      const negative = proposalContainsNegative(proposal, spec.negativeTextIncludes ?? [], bundles);
      if (match && !negative) {
        truePositiveCount += 1;
        matchedGoldenLabels.add(match.label);
      } else {
        falsePositiveCount += 1;
        falsePositiveSamples.push(proposal.labelSuggestion);
      }
    }

    const proposalCount = proposalRun.candidates.length;
    return {
      thresholds,
      proposalCount,
      truePositiveCount,
      falsePositiveCount,
      precisionAtK: proposalCount === 0 ? 0 : truePositiveCount / proposalCount,
      coverage: spec.goldenConcepts.length === 0 ? 1 : matchedGoldenLabels.size / spec.goldenConcepts.length,
      duplicateRate: duplicateRate(proposalRun.candidates),
      falsePositiveSamples,
      matchedGoldenLabels: [...matchedGoldenLabels].sort(),
      proposalRun,
    };
  });

  const best = [...sweeps].sort((a, b) => b.precisionAtK - a.precisionAtK || b.coverage - a.coverage || a.proposalCount - b.proposalCount)[0];
  return {
    generatedAt: new Date().toISOString(),
    degraded: true,
    providerMode: "legacy-local",
    sweeps,
    recommendation: {
      thresholds: best.thresholds,
      reason: "Selected highest precision, then coverage, then fewer proposals. Degraded=true because this legacy calibration path uses local Jaccard clustering.",
    },
  };
}
