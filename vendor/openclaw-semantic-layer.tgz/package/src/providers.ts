import type { EmbeddingProvider, EmbeddingVector } from "./store.js";
import type { ConceptSynthesisInput, ConceptSynthesisProvider, RawConceptSynthesis } from "./llm.js";
import { SEMANTIC_CONTRACT_SCHEMA_IDS } from "./contracts.js";
import type { SemanticConceptScope, SemanticModelMetadata, SemanticProviderAudit } from "./contracts.js";

export type OpenAIProviderOptions = {
  apiKey: string;
  baseUrl?: string;
  model?: string;
};

function requireApiKey(apiKey: string) {
  const value = apiKey.trim();
  if (!value) throw new Error("OpenAI provider requires a non-empty API key");
  return value;
}

function openAiBaseUrl(value?: string) {
  return (value?.trim() || "https://api.openai.com/v1").replace(/\/+$/u, "");
}

async function postOpenAiJson<T>(options: OpenAIProviderOptions, path: string, body: Record<string, unknown>): Promise<T> {
  const response = await fetch(`${openAiBaseUrl(options.baseUrl)}${path}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${requireApiKey(options.apiKey)}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const message = typeof payload.error === "object" && payload.error && "message" in payload.error
      ? String((payload.error as { message?: unknown }).message)
      : `OpenAI request failed with HTTP ${response.status}`;
    throw new Error(message);
  }
  return payload as T;
}

export class OpenAIEmbeddingProvider implements EmbeddingProvider {
  provider = "openai";
  model: string;
  dimensions: number;
  degraded = false;
  private readonly options: OpenAIProviderOptions;
  private readonly maxInputsPerBatch: number;
  private readonly maxCharsPerBatch: number;
  private readonly maxCharsPerInput: number;

  constructor(options: OpenAIProviderOptions & { dimensions?: number; maxInputsPerBatch?: number; maxCharsPerBatch?: number; maxCharsPerInput?: number }) {
    this.options = options;
    this.model = options.model ?? "text-embedding-3-small";
    this.dimensions = options.dimensions ?? 1536;
    this.maxInputsPerBatch = options.maxInputsPerBatch ?? 96;
    this.maxCharsPerBatch = options.maxCharsPerBatch ?? 180_000;
    this.maxCharsPerInput = options.maxCharsPerInput ?? 20_000;
  }

  async embed(texts: string[]): Promise<EmbeddingVector[]> {
    if (texts.length === 0) return [];
    const vectors: EmbeddingVector[] = [];
    let batch: string[] = [];
    let batchChars = 0;
    const flush = async () => {
      if (batch.length === 0) return;
      const batchVectors = await this.embedBatch(batch);
      vectors.push(...batchVectors);
      batch = [];
      batchChars = 0;
    };
    for (const rawText of texts) {
      const text = rawText.length > this.maxCharsPerInput ? rawText.slice(0, this.maxCharsPerInput) : rawText;
      const chars = text.length;
      if (batch.length > 0 && (batch.length >= this.maxInputsPerBatch || batchChars + chars > this.maxCharsPerBatch)) {
        await flush();
      }
      batch.push(text);
      batchChars += chars;
    }
    await flush();
    return vectors;
  }

  private async embedBatch(texts: string[]): Promise<EmbeddingVector[]> {
    type EmbeddingResponse = { data?: Array<{ embedding?: number[] }> };
    const payload = await postOpenAiJson<EmbeddingResponse>(this.options, "/embeddings", {
      model: this.model,
      input: texts,
    });
    const vectors = payload.data?.map((item) => item.embedding ?? []) ?? [];
    if (vectors.length !== texts.length || vectors.some((vector) => vector.length === 0)) {
      throw new Error("OpenAI embedding response did not include one vector per input text");
    }
    this.dimensions = vectors[0]?.length ?? this.dimensions;
    return vectors;
  }
}

function scoped(value: unknown): SemanticConceptScope {
  return value === "personal" || value === "team" || value === "company" || value === "project" || value === "client_vendor" || value === "security_compliance" || value === "operational_process" || value === "strategic_commercial"
    ? value
    : "operational_process";
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String).map((item) => item.trim()).filter(Boolean) : [];
}

export function parseConceptConfidence(value: unknown): { ok: true; value: number; diagnostics: string[] } | { ok: false; diagnostics: string[]; suppress?: boolean } {
  if (value === undefined) return { ok: false, diagnostics: ["confidence_invalid_missing"] };
  if (value === null) return { ok: false, diagnostics: ["confidence_invalid_null"] };
  if (typeof value !== "number") return { ok: false, diagnostics: ["confidence_invalid_non_numeric"] };
  if (!Number.isFinite(value)) return { ok: false, diagnostics: ["confidence_invalid_non_finite"] };
  if (value < 0) return { ok: false, diagnostics: ["confidence_invalid_negative"] };
  if (value <= 0) return { ok: false, diagnostics: ["confidence_true_zero_suppressed"], suppress: true };
  if (value > 1 && value <= 100) return { ok: true, value: value / 100, diagnostics: ["confidence_normalized_from_percent"] };
  if (value > 1) return { ok: false, diagnostics: ["confidence_invalid_above_100_percent"] };
  return { ok: true, value, diagnostics: [] };
}

const ALLOWED_SYNTHESIS_KEYS = new Set(["canonicalLabelSuggestion", "definition", "whyItMatters", "scope", "confidence", "aliasesSuggested", "supportingQuotes", "packetIds"]);
const ALLOWED_QUOTE_KEYS = new Set(["quote", "evidenceWindowId"]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validateSynthesisRow(row: unknown, index: number): string[] {
  const diagnostics: string[] = [];
  if (!isRecord(row)) return [`row_${index}_invalid_not_object`];
  for (const key of Object.keys(row)) {
    if (!ALLOWED_SYNTHESIS_KEYS.has(key)) diagnostics.push(`row_${index}_invalid_extra_property_${key}`);
  }
  for (const key of ALLOWED_SYNTHESIS_KEYS) {
    if (!(key in row)) diagnostics.push(`row_${index}_invalid_missing_${key}`);
  }
  for (const key of ["canonicalLabelSuggestion", "definition", "whyItMatters"] as const) {
    if (typeof row[key] !== "string" || !row[key].trim()) diagnostics.push(`row_${index}_invalid_${key}`);
    if (typeof row[key] === "string" && row[key].length > (key === "canonicalLabelSuggestion" ? 96 : 600)) diagnostics.push(`row_${index}_invalid_${key}_too_long`);
  }
  if (scoped(row.scope) !== row.scope) diagnostics.push(`row_${index}_invalid_scope`);
  const confidence = parseConceptConfidence(row.confidence);
  diagnostics.push(...confidence.diagnostics.map((item) => `row_${index}_${item}`));
  if (!Array.isArray(row.aliasesSuggested) || row.aliasesSuggested.some((item) => typeof item !== "string" || item.length > 96)) diagnostics.push(`row_${index}_invalid_aliasesSuggested`);
  if (!Array.isArray(row.packetIds) || row.packetIds.length < 1 || row.packetIds.length > 8 || row.packetIds.some((item) => typeof item !== "string" || !item.trim())) diagnostics.push(`row_${index}_invalid_packetIds`);
  if (!Array.isArray(row.supportingQuotes) || row.supportingQuotes.length < 1 || row.supportingQuotes.length > 8) {
    diagnostics.push(`row_${index}_invalid_supportingQuotes`);
  } else {
    row.supportingQuotes.forEach((quote, quoteIndex) => {
      if (!isRecord(quote)) {
        diagnostics.push(`row_${index}_quote_${quoteIndex}_invalid_not_object`);
        return;
      }
      for (const key of Object.keys(quote)) {
        if (!ALLOWED_QUOTE_KEYS.has(key)) diagnostics.push(`row_${index}_quote_${quoteIndex}_invalid_extra_property_${key}`);
      }
      if (typeof quote.quote !== "string" || !quote.quote.trim() || quote.quote.length > 500) diagnostics.push(`row_${index}_quote_${quoteIndex}_invalid_quote`);
      if (typeof quote.evidenceWindowId !== "string" || !quote.evidenceWindowId.trim()) diagnostics.push(`row_${index}_quote_${quoteIndex}_invalid_evidenceWindowId`);
    });
  }
  return diagnostics;
}

export type ConceptSynthesisParseResult = {
  proposals: RawConceptSynthesis[];
  parsedRows: unknown[];
  diagnostics: string[];
};

export function parseOpenAIConceptSynthesisContent(content: string): ConceptSynthesisParseResult {
  let parsed: unknown;
  try {
    parsed = JSON.parse(content) as unknown;
  } catch {
    return { proposals: [], parsedRows: [], diagnostics: ["response_invalid_json"] };
  }
  if (!isRecord(parsed) || !Array.isArray(parsed.proposals)) {
    return { proposals: [], parsedRows: [], diagnostics: ["response_invalid_schema_missing_proposals"] };
  }
  const topLevelExtra = Object.keys(parsed).filter((key) => key !== "proposals");
  if (topLevelExtra.length > 0) {
    return { proposals: [], parsedRows: parsed.proposals, diagnostics: topLevelExtra.map((key) => `response_invalid_extra_property_${key}`) };
  }
  const rows = parsed.proposals;
  const diagnostics: string[] = [];
  const proposals: RawConceptSynthesis[] = [];
  rows.forEach((row, index) => {
    const rowDiagnostics = validateSynthesisRow(row, index);
    diagnostics.push(...rowDiagnostics);
    if (rowDiagnostics.some((item) => item.includes("invalid_"))) return;
    const value = row as Record<string, unknown>;
    const confidence = parseConceptConfidence(value.confidence);
    if (!confidence.ok) return;
    proposals.push({
      canonicalLabelSuggestion: String(value.canonicalLabelSuggestion ?? "").trim(),
      definition: String(value.definition ?? "").trim(),
      whyItMatters: String(value.whyItMatters ?? "").trim(),
      scope: scoped(value.scope),
      confidence: confidence.value,
      aliasesSuggested: stringArray(value.aliasesSuggested),
      supportingQuotes: Array.isArray(value.supportingQuotes)
        ? value.supportingQuotes.map((quote) => {
            const quoted = quote as Record<string, unknown>;
            return { quote: String(quoted.quote ?? "").trim(), evidenceWindowId: typeof quoted.evidenceWindowId === "string" ? quoted.evidenceWindowId : null };
          }).filter((quote) => quote.quote)
        : [],
      packetIds: stringArray(value.packetIds),
      diagnostics: confidence.diagnostics,
      rawProviderRow: row,
    });
  });
  return { proposals, parsedRows: rows, diagnostics };
}

const conceptSynthesisJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["proposals"],
  properties: {
    proposals: {
      type: "array",
      minItems: 0,
      maxItems: 12,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["canonicalLabelSuggestion", "definition", "whyItMatters", "scope", "confidence", "aliasesSuggested", "supportingQuotes", "packetIds"],
        properties: {
          canonicalLabelSuggestion: { type: "string", minLength: 6, maxLength: 96, description: "Specific durable operational theme; not a person-name cluster, generic keyword, or vague meeting topic." },
          definition: { type: "string", minLength: 20, maxLength: 600 },
          whyItMatters: { type: "string", minLength: 20, maxLength: 600 },
          scope: { type: "string", enum: ["personal", "team", "company", "project", "client_vendor", "security_compliance", "operational_process", "strategic_commercial"] },
          confidence: { type: "number", minimum: 0, maximum: 100, description: "Use 0 only by omitting the proposal. Prefer 0.40-1.00; percentage values 1-100 are accepted only for compatibility and are normalized locally." },
          aliasesSuggested: { type: "array", maxItems: 6, items: { type: "string", minLength: 1, maxLength: 96 } },
          supportingQuotes: {
            type: "array",
            minItems: 1,
            maxItems: 8,
            items: {
              type: "object",
              additionalProperties: false,
              required: ["quote", "evidenceWindowId"],
              properties: {
                quote: { type: "string", minLength: 5, maxLength: 500 },
                evidenceWindowId: { type: "string", minLength: 1 },
              },
            },
          },
          packetIds: { type: "array", minItems: 1, maxItems: 8, items: { type: "string", minLength: 1 } },
        },
      },
    },
  },
} as const;

export class OpenAIConceptSynthesisProvider implements ConceptSynthesisProvider {
  metadata: SemanticModelMetadata;
  lastSynthesisAudit: SemanticProviderAudit | null = null;
  private readonly options: OpenAIProviderOptions;

  constructor(options: OpenAIProviderOptions) {
    this.options = options;
    this.metadata = { provider: "openai", model: options.model ?? "gpt-4.1-mini", temperature: 0.1 };
  }

  async synthesize(input: ConceptSynthesisInput): Promise<RawConceptSynthesis[]> {
    type ChatResponse = { choices?: Array<{ message?: { content?: string } }> };
    const packetSummaries = input.packets.map((packet) => ({
      packetId: packet.packet.packetId,
      actions: packet.actions,
      decisions: packet.decisions,
      evidence: packet.evidence.slice(0, 5).map((item) => ({
        id: item.id,
        text: item.text,
        sourceContext: item.contextText ?? item.text,
        contextLineStart: item.contextLineStart ?? null,
        contextLineEnd: item.contextLineEnd ?? null,
      })),
      meetingIds: packet.packet.meetingIds,
      meetings: packet.meetingContext,
      peopleEntityRefs: packet.packet.peopleEntityRefs,
      autonomousDomainSignals: packet.domainSignals,
    }));
    const body = {
      model: this.metadata.model,
      temperature: this.metadata.temperature,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "semantic_concept_synthesis_output_v1",
          strict: true,
          schema: conceptSynthesisJsonSchema,
        },
      },
      messages: [
        {
          role: "system",
          content: [
            "You synthesize operational semantic concepts for Mission Control from evidence packets.",
            "Return only schema-valid JSON: {\"proposals\":[...]}.",
            "Each proposal must include canonicalLabelSuggestion, definition, whyItMatters, scope, confidence, aliasesSuggested, supportingQuotes, packetIds.",
            "Labels must describe durable operational themes, not people-name clusters or arbitrary keywords.",
            "Use each evidence sourceContext (bounded ±10 source lines) to infer the business domain/workstream; assertion labels alone are insufficient.",
            "Prefer labels anchored in autonomous domain signals from recurring terms, people cohorts, meeting titles/dates, and evidence context.",
            "Do not emit generic process buckets such as follow-up, stakeholder readiness, dependency clearing, review hygiene, or external narrative unless the packets also share a clear business-domain anchor.",
            "If packets appear connected only by generic process verbs across unrelated domains, omit the proposal rather than merging them.",
            "Reject weak packets by omitting them. Do not invent evidence. Use concise business language.",
            "Confidence rubric: 0 means do not emit because evidence is insufficient or contradictory; 0.10-0.39 is weak/debug only and must not be emitted in normal runs; 0.40-0.69 is plausible review-only and requires at least one aligned assertion plus quote; 0.70-0.84 is strong with a specific operational theme and multiple aligned evidence points or recurring assertion support; 0.85-1.00 is very strong with repeated/cross-meeting or high-density evidence, clear action/decision alignment, and low duplicate risk.",
            "Base confidence on evidence quality, specificity, action/decision/quote alignment, recurrence, and duplicate risk, not generic model certainty.",
          ].join(" "),
        },
        {
          role: "user",
          content: JSON.stringify({
            maxProposals: input.maxProposals,
            allowedScopes: ["personal", "team", "company", "project", "client_vendor", "security_compliance", "operational_process", "strategic_commercial"],
            registry: input.registrySnapshot.entries.map((entry) => ({ conceptId: entry.conceptId, label: entry.canonicalLabel, definition: entry.definition, aliases: entry.aliases, status: entry.status })),
            packets: packetSummaries,
          }),
        },
      ],
    } satisfies Record<string, unknown>;
    let payload: ChatResponse;
    const responseFormat = "json_schema";
    const parseDiagnostics: string[] = [];
    try {
      payload = await postOpenAiJson<ChatResponse>(this.options, "/chat/completions", body);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/json_schema|response_format|schema/iu.test(message)) {
        this.lastSynthesisAudit = {
          provider: this.metadata.provider,
          model: this.metadata.model,
          modelMetadata: this.metadata,
          promptVersion: input.prompt.promptVersion,
          outputSchemaId: SEMANTIC_CONTRACT_SCHEMA_IDS.conceptSynthesisOutput,
          requestHash: input.prompt.inputHash ?? null,
          responseFormat,
          responsePayload: null,
          rawMessageContent: null,
          parsedRows: [],
          parseDiagnostics: [`schema_response_format_required_failed_closed: ${message}`],
        };
        throw new Error(`OpenAI concept synthesis requires strict json_schema response_format; provider/model rejected schema output: ${message}`);
      }
      throw error;
    }
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw new Error("OpenAI concept synthesis response did not include content");
    const parsed = parseOpenAIConceptSynthesisContent(content);
    parseDiagnostics.push(...parsed.diagnostics);
    this.lastSynthesisAudit = {
      provider: this.metadata.provider,
      model: this.metadata.model,
      modelMetadata: this.metadata,
      promptVersion: input.prompt.promptVersion,
      outputSchemaId: SEMANTIC_CONTRACT_SCHEMA_IDS.conceptSynthesisOutput,
      requestHash: input.prompt.inputHash ?? null,
      responseFormat,
      responsePayload: payload,
      rawMessageContent: content,
      parsedRows: parsed.parsedRows,
      parseDiagnostics,
    };
    return parsed.proposals.slice(0, input.maxProposals);
  }
}
