import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { unlinkSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import type { SemanticExtractionBundle, SemanticAssertionCandidate, SemanticEvidenceWindow, SemanticPersonEntity } from "./extraction.js";
import { parseSemanticMeetingNote } from "./note-reader.js";
import { buildSemanticEvidencePacket, defaultEvidencePacketSeeds } from "./recall.js";
import { CONCEPT_RETRIEVAL_CHUNK_STRATEGY, MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS, assertConceptRetrievalIndexReady, buildSemanticIndex, initializeSemanticStore, openSemanticStore, retrieveSemanticNeighbors, semanticIndexStatus, type EmbeddingProvider } from "./store.js";

class ZeroEmbeddingProvider implements EmbeddingProvider {
  provider = "test-local";
  model = "zero-vector";
  dimensions = 8;
  degraded = true;

  embed(texts: string[]) {
    return texts.map(() => Array.from({ length: this.dimensions }, () => 0));
  }
}

function stableId(prefix: string, value: string) {
  return `${prefix}:${createHash("sha256").update(value).digest("hex").slice(0, 32)}`;
}

function dbPath(name: string) {
  return path.join(os.tmpdir(), `${name}-${Date.now()}-${Math.random().toString(16).slice(2)}.sqlite`);
}

function sourceRef(noteId: string, sourceType: string, sourceId: string) {
  return { sourceSystem: "test", sourceType, sourceId, canonicalSourcePath: null, contentHash: "hash", missionControlId: null };
}

function bundleWithAssertions(config: {
  noteId: string;
  sections?: Record<string, string>;
  actions?: string[];
  decisions?: string[];
  evidenceText?: (text: string, index: number) => string;
}): SemanticExtractionBundle {
  const markdown = `---\nmeeting_title: ${config.noteId}\nmeeting_date: 2026-06-20T08:00:00Z\nparticipants:\n  - Alice Example\n---\n# ${config.noteId}\n`;
  const parsed = parseSemanticMeetingNote(markdown, { sourceSystem: "test", canonicalSourcePath: config.noteId, parsedAt: "2026-06-20T08:00:00Z" });
  const note = { ...parsed, semanticNoteId: config.noteId, sourceRef: sourceRef(config.noteId, "meeting_note", config.noteId), sections: config.sections ?? {} };
  const person: SemanticPersonEntity = { personEntityId: `${config.noteId}:person:alice`, noteId: config.noteId, displayName: "Alice Example", aliases: ["Alice", "Alice Example"], sourceRef: sourceRef(config.noteId, "person_entity", `${config.noteId}:person:alice`), confidence: 0.9 };
  const evidenceWindows: SemanticEvidenceWindow[] = [];
  const assertionCandidates: SemanticAssertionCandidate[] = [];
  for (const [kind, texts] of [["action", config.actions ?? []], ["decision", config.decisions ?? []]] as const) {
    for (const [index, text] of texts.entries()) {
      const candidateId = `${config.noteId}:${kind}:${index}`;
      const evidenceWindowId = `${candidateId}:evidence`;
      const evidenceText = config.evidenceText?.(text, index) ?? `[00:00:0${index}] Alice Example: ${text}`;
      evidenceWindows.push({ evidenceWindowId, noteId: config.noteId, text: evidenceText, sourceRef: sourceRef(config.noteId, "evidence_window", evidenceWindowId), supportsCandidateIds: [candidateId] });
      assertionCandidates.push({ candidateId, noteId: config.noteId, kind, text, normalizedText: text.toLowerCase(), source: "manual_fixture", sourceRef: sourceRef(config.noteId, "assertion_candidate", candidateId), evidenceWindowIds: [evidenceWindowId], participantEntityIds: [person.personEntityId], confidence: 0.9, extractionVersion: "test" });
    }
  }
  return { note, assertionCandidates, evidenceWindows, personEntities: [person], extraction: { extractionVersion: "test", degraded: false, diagnostics: [] } };
}

test("default packet seeds carry assertion candidate IDs and seed collection includes evidence, meeting, and people", async () => {
  const bundle = bundleWithAssertions({
    noteId: "meeting:seeded",
    actions: ["Alice Example to improve semantic proposal precision."],
    decisions: ["The team decided semantic packets stay evidence grounded."],
  });

  const seeds = defaultEvidencePacketSeeds([bundle]);
  const actionSeed = seeds.find((seed) => seed.reason === "meeting_actions");
  assert.deepEqual(actionSeed?.candidateIds, [bundle.assertionCandidates[0].candidateId]);

  const packet = await buildSemanticEvidencePacket(null, [bundle], actionSeed!, { indexVersion: "test-index", generatedAt: "2026-06-20T08:00:00Z" });
  assert.deepEqual(packet.includedActionIds, [bundle.assertionCandidates[0].candidateId]);
  assert.deepEqual(packet.evidenceWindowIds, [bundle.evidenceWindows[0].evidenceWindowId]);
  assert.deepEqual(packet.meetingIds, [bundle.note.semanticNoteId]);
  assert.deepEqual(packet.peopleEntityRefs, [bundle.personEntities[0].personEntityId]);

  const missing = await buildSemanticEvidencePacket(null, [bundle], { reason: "missing_seed_probe", candidateIds: ["candidate:missing"], meetingIds: ["meeting:missing"] }, { indexVersion: "test-index" });
  assert.ok(missing.diagnostics?.includes("missing_seed_candidate_id:candidate:missing"));
  assert.ok(missing.diagnostics?.includes("missing_seed_meeting_id:meeting:missing"));
});

test("note-section-only retrieval hits do not pull unrelated same-meeting assertions into packets", async () => {
  const bundle = bundleWithAssertions({
    noteId: "meeting:note-only",
    sections: { transcript: "orion nebula budget appeared only in this transcript note section." },
    actions: ["Alice Example to update the unrelated launch checklist."],
  });
  const file = dbPath("semantic-note-only");
  const db = openSemanticStore(file);
  try {
    const provider = new ZeroEmbeddingProvider();
    const index = await buildSemanticIndex(db, [bundle], provider);
    const packet = await buildSemanticEvidencePacket(db, [bundle], { reason: "note_only_probe", text: "orion nebula budget" }, { indexVersion: index.indexVersionId, provider, limit: 5 });
    assert.deepEqual(packet.includedActionIds, []);
    assert.deepEqual(packet.includedDecisionIds, []);
    assert.ok(packet.retrievalScores.some((score) => score.sourceKind === "note_section"));
    assert.ok(packet.diagnostics?.some((diagnostic) => diagnostic.includes("retrieval_context_only:note_section")));
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("indexing splits transcript/source-note material before embedding and records the v2 strategy", async () => {
  const giantTranscript = Array.from({ length: 220 }, (_, index) => `[00:${String(index % 60).padStart(2, "0")}] custody stewardship source window ${index}`).join("\n");
  const bundle = bundleWithAssertions({
    noteId: "meeting:bounded-index",
    sections: {
      transcript: giantTranscript,
      participants: "Alice Example\nBob Example",
      frontmatter: "meeting_date: 2026-06-20",
      narrative: `${"bounded narrative context ".repeat(180)}done`,
    },
    actions: ["Alice Example to define custody stewardship escalation."],
  });
  const file = dbPath("semantic-bounded-index");
  const db = openSemanticStore(file);
  const seenLengths: number[] = [];
  class RecordingProvider extends ZeroEmbeddingProvider {
    embed(texts: string[]) {
      seenLengths.push(...texts.map((text) => text.length));
      return super.embed(texts);
    }
  }
  try {
    const provider = new RecordingProvider();
    await buildSemanticIndex(db, [bundle], provider);
    const status = semanticIndexStatus(db);
    assert.equal(status.latestIndexVersion?.chunk_strategy, CONCEPT_RETRIEVAL_CHUNK_STRATEGY);
    assert.equal(status.conceptRetrieval.oversizedChunkCount, 0);
    assert.ok(Math.max(...seenLengths) <= MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS);
    const rows = db.prepare("SELECT source_id as sourceId, LENGTH(text) as len, record_json as recordJson FROM semantic_chunks WHERE source_kind = 'note_section'").all() as Array<{ sourceId: string; len: number; recordJson: string }>;
    assert.ok(rows.some((row) => row.sourceId.startsWith("transcript")), "transcript should be retained only as bounded context windows");
    assert.ok(rows.every((row) => row.len <= MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS));
    assert.ok(rows.every((row) => !["participants", "frontmatter"].includes(String((JSON.parse(row.recordJson) as { metadata: { sectionName: string } }).metadata.sectionName).toLowerCase())));
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("problematic and oversized note sections are downranked below assertion and evidence hits", async () => {
  const repeated = Array.from({ length: 400 }, () => "custody stewardship token overlap").join(" ");
  const bundle = bundleWithAssertions({
    noteId: "meeting:ranking",
    sections: {
      participants: "custody stewardship participants list should not dominate retrieval",
      transcript: repeated,
      metadata: "custody stewardship metadata should not dominate retrieval",
    },
    actions: ["Alice Example to define custody stewardship escalation."],
  });
  const file = dbPath("semantic-ranking");
  const db = openSemanticStore(file);
  try {
    const provider = new ZeroEmbeddingProvider();
    await buildSemanticIndex(db, [bundle], provider);
    const neighbors = await retrieveSemanticNeighbors(db, "custody stewardship", { provider, limit: 10 });
    const firstPrimary = neighbors.find((result) => result.chunk.sourceKind === "assertion_candidate" || result.chunk.sourceKind === "evidence_window");
    const problemNotes = neighbors.filter((result) => result.chunk.sourceKind === "note_section" && ["participants", "transcript", "metadata"].includes(String(result.chunk.metadata.sectionName)));
    assert.ok(firstPrimary, "expected an assertion/evidence hit");
    assert.ok(problemNotes.length >= 1, "expected problematic note section diagnostics");
    for (const note of problemNotes) {
      assert.ok(note.score < firstPrimary!.score, `${note.chunk.sourceId} should be below primary hits`);
      assert.ok(note.exclusionReason || note.downrankReason);
    }
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("lexical normalization preserves rank differences instead of saturating all broad note matches to one", async () => {
  const bundle = bundleWithAssertions({
    noteId: "meeting:lexical",
    sections: {
      alpha: "alpha beta gamma",
      beta: Array.from({ length: 40 }, () => "alpha beta gamma").join(" "),
      gamma: "alpha beta gamma delta epsilon zeta eta theta",
    },
  });
  const file = dbPath("semantic-lexical");
  const db = openSemanticStore(file);
  try {
    const provider = new ZeroEmbeddingProvider();
    await buildSemanticIndex(db, [bundle], provider);
    const noteScores = (await retrieveSemanticNeighbors(db, "alpha beta gamma", { provider, limit: 10 }))
      .filter((result) => result.chunk.sourceKind === "note_section" && result.lexicalScore > 0)
      .map((result) => result.lexicalScore);
    assert.ok(noteScores.length >= 2);
    assert.ok(new Set(noteScores).size > 1, `expected varied lexical scores, got ${noteScores.join(",")}`);
    assert.ok(noteScores.some((score) => score < 1), `expected at least one lexical score below saturation, got ${noteScores.join(",")}`);
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("old or oversized indexes are stale for concept generation", () => {
  const file = dbPath("semantic-stale-index");
  const db = openSemanticStore(file);
  try {
    initializeSemanticStore(db);
    db.prepare(`INSERT INTO semantic_index_versions (index_version_id, created_at, chunk_strategy, embedding_provider, embedding_model, dimensions, degraded, status, notes_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`) 
      .run("index:old", "2026-06-20T08:00:00Z", "note-sections+candidates+evidence/v1", "test", "test", 8, 1, "degraded", "{}");
    db.prepare(`INSERT INTO semantic_chunks (chunk_id, note_id, source_kind, source_id, text, record_json) VALUES (?, ?, ?, ?, ?, ?)`)
      .run("chunk:giant", "note:old", "note_section", "transcript", "x".repeat(MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS + 1), JSON.stringify({ chunkId: "chunk:giant", noteId: "note:old", sourceKind: "note_section", sourceId: "transcript", text: "x".repeat(MAX_CONCEPT_RETRIEVAL_CHUNK_CHARS + 1), metadata: { sectionName: "transcript" } }));
    const status = semanticIndexStatus(db);
    assert.equal(status.conceptRetrieval.staleForConceptGeneration, true);
    assert.throws(() => assertConceptRetrievalIndexReady(db), /stale for concept generation/u);
  } finally {
    db.close();
    try { unlinkSync(file); } catch {}
  }
});

test("packet caps bound included IDs and evidence text size with diagnostics", async () => {
  const bundle = bundleWithAssertions({
    noteId: "meeting:caps",
    actions: ["alpha one", "alpha two", "alpha three"],
    decisions: ["alpha decision one", "alpha decision two"],
    evidenceText: (text, index) => `${text} ${"evidence".repeat(index + 8)}`,
  });
  const packet = await buildSemanticEvidencePacket(
    null,
    [bundle],
    { reason: "cap_probe", text: "alpha", candidateIds: bundle.assertionCandidates.map((candidate) => candidate.candidateId) },
    { indexVersion: "test-index", maxActions: 1, maxDecisions: 1, maxEvidenceWindows: 2, maxMeetings: 1, maxEvidenceCharacters: 80 },
  );

  assert.equal(packet.includedActionIds.length, 1);
  assert.equal(packet.includedDecisionIds.length, 1);
  assert.ok(packet.evidenceWindowIds.length <= 2);
  assert.equal(packet.meetingIds.length, 1);
  const evidenceChars = packet.evidenceWindowIds.reduce((sum, id) => sum + (bundle.evidenceWindows.find((window) => window.evidenceWindowId === id)?.text.length ?? 0), 0);
  assert.ok(evidenceChars <= 80);
  assert.ok(packet.diagnostics?.some((diagnostic) => diagnostic.startsWith("packet_cap_actions_dropped")));
  assert.ok(packet.diagnostics?.some((diagnostic) => diagnostic.startsWith("packet_cap_decisions_dropped")));
  assert.ok(packet.diagnostics?.some((diagnostic) => diagnostic.startsWith("packet_cap_evidence")));
});
