# @openclaw/semantic-layer

Local-first OpenClaw semantic-layer package for curated Obsidian meeting notes, extraction, indexing, and future RAG + LLM concept proposal artifacts.

## Ownership boundary

This package owns semantic contracts and local semantic-layer internals. Mission Control consumes exported artifacts/contracts; it must not duplicate retrieval, prompt/schema versions, or product-write logic here.

## RAG + LLM concept layer

The current concept path is:

1. `recall.ts` assembles `SemanticEvidencePacket` records over indexed actions, decisions, evidence windows, meeting refs, people, and optional registry context.
2. `llm.ts` performs schema-bound concept synthesis through an explicit `ConceptSynthesisProvider` abstraction. Production callers must provide a real provider; tests use local fakes, so CI does not need live model credentials.
3. `registry.ts` canonicalizes labels and aliases against a `ConceptRegistrySnapshot`, returning `map_existing`, `add_alias`, `propose_new`, or `reject`.
4. `evaluation.ts` runs proposal-run quality gates over JSONL fixtures or bounded real note corpora.

CLI additions:

```sh
semantic-layer propose-semantic --fixtures extraction.jsonl [--db semantic.sqlite] [--out semantic-proposals.json] --openai-api-key "$OPENAI_API_KEY"
semantic-layer evaluate-semantic --fixtures extraction.jsonl [--out semantic-evaluation.json] --openai-api-key "$OPENAI_API_KEY"
```

## Stable contracts

Stable RAG + LLM concept-layer contracts live in `src/contracts.ts` and are exported from the package root:

- `SemanticSourceRef`
- `SemanticActionRef`, `SemanticDecisionRef`, `SemanticEvidenceRef`
- `SemanticEvidencePacket`
- `SemanticConceptProposal`
- `SemanticConceptProposalRun`
- `ConceptRegistryEntry`, `ConceptAliasMapping`, `ConceptRegistrySnapshot`
- prompt/model metadata via `SemanticPromptVersion`, `SemanticModelMetadata`, `SemanticPromptMetadata`
- review/evaluation outputs via `SemanticConceptEvaluation`

All new artifacts include `contractVersion: "semantic-contracts/v1"`. Runtime validation guards are dependency-free:

- `validateSemanticEvidencePacket` / `isSemanticEvidencePacket`
- `validateSemanticConceptProposal` / `isSemanticConceptProposal`
- `validateSemanticConceptProposalRun` / `isSemanticConceptProposalRun`
- `validateConceptRegistrySnapshot` / `isConceptRegistrySnapshot`
- assert variants for evidence packets, proposals, and proposal runs

Stable ID helpers are also exported:

- `stableSemanticId`
- `semanticContentHash`
- `semanticEvidencePacketId`
- `semanticConceptProposalId`

## Existing extraction/indexing

The existing parser and extraction flow remains meeting-assistant-compatible:

- `note-reader.ts` parses curated Obsidian/Fathom notes.
- `extraction.ts` extracts action/decision candidates, evidence windows, and people from existing managed note sections.
- `store.ts` builds a local SQLite/FTS index with an explicit embedding provider.

## Legacy concept path

`concepts.ts` and `calibration.ts` are legacy Jaccard utilities kept for compatibility with current CLI tests and local degraded experiments. They are quarantined as **not** the target product path; product proposal runs should use RAG evidence packets plus schema-bound concept synthesis.

## Validation

From this directory:

```sh
pnpm typecheck
pnpm test
```
